package net.minecraft.advancements.critereon;

import com.google.common.collect.ImmutableList;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.phys.Vec3;

public record DamageSourcePredicate(
    List<TagPredicate<DamageType>> f_268608_, Optional<EntityPredicate> f_25429_, Optional<EntityPredicate> f_25430_, Optional<Boolean> f_337324_
) {
    public static final Codec<DamageSourcePredicate> f_290670_ = RecordCodecBuilder.create(
        p_340752_ -> p_340752_.group(
                    TagPredicate.m_295374_(Registries.f_268580_).listOf().optionalFieldOf("tags", List.of()).forGetter(DamageSourcePredicate::f_268608_),
                    EntityPredicate.f_291089_.optionalFieldOf("direct_entity").forGetter(DamageSourcePredicate::f_25429_),
                    EntityPredicate.f_291089_.optionalFieldOf("source_entity").forGetter(DamageSourcePredicate::f_25430_),
                    Codec.BOOL.optionalFieldOf("is_direct").forGetter(DamageSourcePredicate::f_337324_)
                )
                .apply(p_340752_, DamageSourcePredicate::new)
    );

    public boolean m_25448_(ServerPlayer p_25449_, DamageSource p_25450_) {
        return this.m_25444_(p_25449_.m_284548_(), p_25449_.m_20182_(), p_25450_);
    }

    public boolean m_25444_(ServerLevel p_25445_, Vec3 p_25446_, DamageSource p_25447_) {
        for (TagPredicate<DamageType> tagpredicate : this.f_268608_) {
            if (!tagpredicate.m_269475_(p_25447_.m_269150_())) {
                return false;
            }
        }

        if (this.f_25429_.isPresent() && !this.f_25429_.get().m_36607_(p_25445_, p_25446_, p_25447_.m_7640_())) {
            return false;
        } else {
            return this.f_25430_.isPresent() && !this.f_25430_.get().m_36607_(p_25445_, p_25446_, p_25447_.m_7639_())
                ? false
                : !this.f_337324_.isPresent() || this.f_337324_.get() == p_25447_.m_338899_();
        }
    }

    public static class Builder {
        private final ImmutableList.Builder<TagPredicate<DamageType>> f_268703_ = ImmutableList.builder();
        private Optional<EntityPredicate> f_25468_ = Optional.empty();
        private Optional<EntityPredicate> f_25469_ = Optional.empty();
        private Optional<Boolean> f_336874_ = Optional.empty();

        public static DamageSourcePredicate.Builder m_25471_() {
            return new DamageSourcePredicate.Builder();
        }

        public DamageSourcePredicate.Builder m_269507_(TagPredicate<DamageType> p_270455_) {
            this.f_268703_.add(p_270455_);
            return this;
        }

        public DamageSourcePredicate.Builder m_25472_(EntityPredicate.Builder p_25473_) {
            this.f_25468_ = Optional.of(p_25473_.m_36662_());
            return this;
        }

        public DamageSourcePredicate.Builder m_148231_(EntityPredicate.Builder p_148232_) {
            this.f_25469_ = Optional.of(p_148232_.m_36662_());
            return this;
        }

        public DamageSourcePredicate.Builder m_339559_(boolean p_345243_) {
            this.f_336874_ = Optional.of(p_345243_);
            return this;
        }

        public DamageSourcePredicate m_25476_() {
            return new DamageSourcePredicate(this.f_268703_.build(), this.f_25468_, this.f_25469_, this.f_336874_);
        }
    }
}