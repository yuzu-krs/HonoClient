package net.minecraft.advancements.critereon;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.Optional;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.Criterion;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public class EnchantedItemTrigger extends SimpleCriterionTrigger<EnchantedItemTrigger.TriggerInstance> {
    @Override
    public Codec<EnchantedItemTrigger.TriggerInstance> m_5868_() {
        return EnchantedItemTrigger.TriggerInstance.f_302859_;
    }

    public void m_27668_(ServerPlayer p_27669_, ItemStack p_27670_, int p_27671_) {
        this.m_66234_(p_27669_, p_27675_ -> p_27675_.m_27691_(p_27670_, p_27671_));
    }

    public static record TriggerInstance(Optional<ContextAwarePredicate> f_303838_, Optional<ItemPredicate> f_27685_, MinMaxBounds.Ints f_27686_)
        implements SimpleCriterionTrigger.SimpleInstance {
        public static final Codec<EnchantedItemTrigger.TriggerInstance> f_302859_ = RecordCodecBuilder.create(
            p_325204_ -> p_325204_.group(
                        EntityPredicate.f_303210_.optionalFieldOf("player").forGetter(EnchantedItemTrigger.TriggerInstance::m_295156_),
                        ItemPredicate.f_291722_.optionalFieldOf("item").forGetter(EnchantedItemTrigger.TriggerInstance::f_27685_),
                        MinMaxBounds.Ints.f_290636_
                            .optionalFieldOf("levels", MinMaxBounds.Ints.f_55364_)
                            .forGetter(EnchantedItemTrigger.TriggerInstance::f_27686_)
                    )
                    .apply(p_325204_, EnchantedItemTrigger.TriggerInstance::new)
        );

        public static Criterion<EnchantedItemTrigger.TriggerInstance> m_27696_() {
            return CriteriaTriggers.f_10575_
                .m_292665_(new EnchantedItemTrigger.TriggerInstance(Optional.empty(), Optional.empty(), MinMaxBounds.Ints.f_55364_));
        }

        public boolean m_27691_(ItemStack p_27692_, int p_27693_) {
            return this.f_27685_.isPresent() && !this.f_27685_.get().test(p_27692_) ? false : this.f_27686_.m_55390_(p_27693_);
        }

        @Override
        public Optional<ContextAwarePredicate> m_295156_() {
            return this.f_303838_;
        }
    }
}