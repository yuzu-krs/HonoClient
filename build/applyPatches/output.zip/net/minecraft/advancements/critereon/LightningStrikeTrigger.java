package net.minecraft.advancements.critereon;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.Criterion;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.storage.loot.LootContext;

public class LightningStrikeTrigger extends SimpleCriterionTrigger<LightningStrikeTrigger.TriggerInstance> {
    @Override
    public Codec<LightningStrikeTrigger.TriggerInstance> m_5868_() {
        return LightningStrikeTrigger.TriggerInstance.f_303280_;
    }

    public void m_153391_(ServerPlayer p_153392_, LightningBolt p_153393_, List<Entity> p_153394_) {
        List<LootContext> list = p_153394_.stream().map(p_153390_ -> EntityPredicate.m_36616_(p_153392_, p_153390_)).collect(Collectors.toList());
        LootContext lootcontext = EntityPredicate.m_36616_(p_153392_, p_153393_);
        this.m_66234_(p_153392_, p_153402_ -> p_153402_.m_153418_(lootcontext, list));
    }

    public static record TriggerInstance(
        Optional<ContextAwarePredicate> f_303589_, Optional<ContextAwarePredicate> f_153407_, Optional<ContextAwarePredicate> f_153408_
    ) implements SimpleCriterionTrigger.SimpleInstance {
        public static final Codec<LightningStrikeTrigger.TriggerInstance> f_303280_ = RecordCodecBuilder.create(
            p_325228_ -> p_325228_.group(
                        EntityPredicate.f_303210_.optionalFieldOf("player").forGetter(LightningStrikeTrigger.TriggerInstance::m_295156_),
                        EntityPredicate.f_303210_.optionalFieldOf("lightning").forGetter(LightningStrikeTrigger.TriggerInstance::f_153407_),
                        EntityPredicate.f_303210_.optionalFieldOf("bystander").forGetter(LightningStrikeTrigger.TriggerInstance::f_153408_)
                    )
                    .apply(p_325228_, LightningStrikeTrigger.TriggerInstance::new)
        );

        public static Criterion<LightningStrikeTrigger.TriggerInstance> m_293278_(Optional<EntityPredicate> p_301310_, Optional<EntityPredicate> p_299336_) {
            return CriteriaTriggers.f_145089_
                .m_292665_(
                    new LightningStrikeTrigger.TriggerInstance(Optional.empty(), EntityPredicate.m_295302_(p_301310_), EntityPredicate.m_295302_(p_299336_))
                );
        }

        public boolean m_153418_(LootContext p_153419_, List<LootContext> p_153420_) {
            return this.f_153407_.isPresent() && !this.f_153407_.get().m_285831_(p_153419_)
                ? false
                : !this.f_153408_.isPresent() || !p_153420_.stream().noneMatch(this.f_153408_.get()::m_285831_);
        }

        @Override
        public void m_7683_(CriterionValidator p_312134_) {
            SimpleCriterionTrigger.SimpleInstance.super.m_7683_(p_312134_);
            p_312134_.m_307484_(this.f_153407_, ".lightning");
            p_312134_.m_307484_(this.f_153408_, ".bystander");
        }

        @Override
        public Optional<ContextAwarePredicate> m_295156_() {
            return this.f_303589_;
        }
    }
}