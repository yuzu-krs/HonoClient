package net.minecraft.advancements.critereon;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.Optional;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.Criterion;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public class UsingItemTrigger extends SimpleCriterionTrigger<UsingItemTrigger.TriggerInstance> {
    @Override
    public Codec<UsingItemTrigger.TriggerInstance> m_5868_() {
        return UsingItemTrigger.TriggerInstance.f_302252_;
    }

    public void m_163865_(ServerPlayer p_163866_, ItemStack p_163867_) {
        this.m_66234_(p_163866_, p_163870_ -> p_163870_.m_163886_(p_163867_));
    }

    public static record TriggerInstance(Optional<ContextAwarePredicate> f_303433_, Optional<ItemPredicate> f_163879_)
        implements SimpleCriterionTrigger.SimpleInstance {
        public static final Codec<UsingItemTrigger.TriggerInstance> f_302252_ = RecordCodecBuilder.create(
            p_325259_ -> p_325259_.group(
                        EntityPredicate.f_303210_.optionalFieldOf("player").forGetter(UsingItemTrigger.TriggerInstance::m_295156_),
                        ItemPredicate.f_291722_.optionalFieldOf("item").forGetter(UsingItemTrigger.TriggerInstance::f_163879_)
                    )
                    .apply(p_325259_, UsingItemTrigger.TriggerInstance::new)
        );

        public static Criterion<UsingItemTrigger.TriggerInstance> m_163883_(EntityPredicate.Builder p_163884_, ItemPredicate.Builder p_163885_) {
            return CriteriaTriggers.f_145090_
                .m_292665_(new UsingItemTrigger.TriggerInstance(Optional.of(EntityPredicate.m_293222_(p_163884_)), Optional.of(p_163885_.m_45077_())));
        }

        public boolean m_163886_(ItemStack p_163887_) {
            return !this.f_163879_.isPresent() || this.f_163879_.get().test(p_163887_);
        }

        @Override
        public Optional<ContextAwarePredicate> m_295156_() {
            return this.f_303433_;
        }
    }
}