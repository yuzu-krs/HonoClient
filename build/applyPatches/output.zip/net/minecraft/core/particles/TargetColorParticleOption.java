package net.minecraft.core.particles;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.phys.Vec3;

public record TargetColorParticleOption(Vec3 f_346962_, int f_347837_) implements ParticleOptions {
    public static final MapCodec<TargetColorParticleOption> f_348235_ = RecordCodecBuilder.mapCodec(
        p_369728_ -> p_369728_.group(
                    Vec3.f_231074_.fieldOf("target").forGetter(TargetColorParticleOption::f_346962_),
                    ExtraCodecs.f_346958_.fieldOf("color").forGetter(TargetColorParticleOption::f_347837_)
                )
                .apply(p_369728_, TargetColorParticleOption::new)
    );
    public static final StreamCodec<RegistryFriendlyByteBuf, TargetColorParticleOption> f_349269_ = StreamCodec.m_320349_(
        Vec3.f_347932_, TargetColorParticleOption::f_346962_, ByteBufCodecs.f_316612_, TargetColorParticleOption::f_347837_, TargetColorParticleOption::new
    );

    @Override
    public ParticleType<TargetColorParticleOption> m_6012_() {
        return ParticleTypes.f_347333_;
    }
}