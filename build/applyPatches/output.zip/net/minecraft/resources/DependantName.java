package net.minecraft.resources;

@FunctionalInterface
public interface DependantName<T, V> {
    V m_355213_(ResourceKey<T> p_368676_);

    static <T, V> DependantName<T, V> m_352343_(V p_363313_) {
        return p_365225_ -> p_363313_;
    }
}