package net.minecraft.commands;

import com.mojang.brigadier.exceptions.BuiltInExceptionProvider;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import net.minecraft.network.chat.Component;

public class BrigadierExceptions implements BuiltInExceptionProvider {
    private static final Dynamic2CommandExceptionType f_77129_ = new Dynamic2CommandExceptionType(
        (p_308315_, p_308316_) -> Component.m_307043_("argument.double.low", p_308316_, p_308315_)
    );
    private static final Dynamic2CommandExceptionType f_77130_ = new Dynamic2CommandExceptionType(
        (p_308320_, p_308321_) -> Component.m_307043_("argument.double.big", p_308321_, p_308320_)
    );
    private static final Dynamic2CommandExceptionType f_77131_ = new Dynamic2CommandExceptionType(
        (p_308335_, p_308336_) -> Component.m_307043_("argument.float.low", p_308336_, p_308335_)
    );
    private static final Dynamic2CommandExceptionType f_77132_ = new Dynamic2CommandExceptionType(
        (p_308318_, p_308319_) -> Component.m_307043_("argument.float.big", p_308319_, p_308318_)
    );
    private static final Dynamic2CommandExceptionType f_77133_ = new Dynamic2CommandExceptionType(
        (p_308323_, p_308324_) -> Component.m_307043_("argument.integer.low", p_308324_, p_308323_)
    );
    private static final Dynamic2CommandExceptionType f_77134_ = new Dynamic2CommandExceptionType(
        (p_308328_, p_308329_) -> Component.m_307043_("argument.integer.big", p_308329_, p_308328_)
    );
    private static final Dynamic2CommandExceptionType f_77135_ = new Dynamic2CommandExceptionType(
        (p_308325_, p_308326_) -> Component.m_307043_("argument.long.low", p_308326_, p_308325_)
    );
    private static final Dynamic2CommandExceptionType f_77136_ = new Dynamic2CommandExceptionType(
        (p_308337_, p_308338_) -> Component.m_307043_("argument.long.big", p_308338_, p_308337_)
    );
    private static final DynamicCommandExceptionType f_77137_ = new DynamicCommandExceptionType(
        p_308332_ -> Component.m_307043_("argument.literal.incorrect", p_308332_)
    );
    private static final SimpleCommandExceptionType f_77138_ = new SimpleCommandExceptionType(Component.m_237115_("parsing.quote.expected.start"));
    private static final SimpleCommandExceptionType f_77139_ = new SimpleCommandExceptionType(Component.m_237115_("parsing.quote.expected.end"));
    private static final DynamicCommandExceptionType f_77140_ = new DynamicCommandExceptionType(
        p_308322_ -> Component.m_307043_("parsing.quote.escape", p_308322_)
    );
    private static final DynamicCommandExceptionType f_77141_ = new DynamicCommandExceptionType(
        p_308330_ -> Component.m_307043_("parsing.bool.invalid", p_308330_)
    );
    private static final DynamicCommandExceptionType f_77142_ = new DynamicCommandExceptionType(
        p_308327_ -> Component.m_307043_("parsing.int.invalid", p_308327_)
    );
    private static final SimpleCommandExceptionType f_77143_ = new SimpleCommandExceptionType(Component.m_237115_("parsing.int.expected"));
    private static final DynamicCommandExceptionType f_77144_ = new DynamicCommandExceptionType(
        p_308334_ -> Component.m_307043_("parsing.long.invalid", p_308334_)
    );
    private static final SimpleCommandExceptionType f_77145_ = new SimpleCommandExceptionType(Component.m_237115_("parsing.long.expected"));
    private static final DynamicCommandExceptionType f_77146_ = new DynamicCommandExceptionType(
        p_308331_ -> Component.m_307043_("parsing.double.invalid", p_308331_)
    );
    private static final SimpleCommandExceptionType f_77147_ = new SimpleCommandExceptionType(Component.m_237115_("parsing.double.expected"));
    private static final DynamicCommandExceptionType f_77148_ = new DynamicCommandExceptionType(
        p_308339_ -> Component.m_307043_("parsing.float.invalid", p_308339_)
    );
    private static final SimpleCommandExceptionType f_77149_ = new SimpleCommandExceptionType(Component.m_237115_("parsing.float.expected"));
    private static final SimpleCommandExceptionType f_77150_ = new SimpleCommandExceptionType(Component.m_237115_("parsing.bool.expected"));
    private static final DynamicCommandExceptionType f_77151_ = new DynamicCommandExceptionType(p_308333_ -> Component.m_307043_("parsing.expected", p_308333_));
    private static final SimpleCommandExceptionType f_77152_ = new SimpleCommandExceptionType(Component.m_237115_("command.unknown.command"));
    private static final SimpleCommandExceptionType f_77153_ = new SimpleCommandExceptionType(Component.m_237115_("command.unknown.argument"));
    private static final SimpleCommandExceptionType f_77154_ = new SimpleCommandExceptionType(Component.m_237115_("command.expected.separator"));
    private static final DynamicCommandExceptionType f_77128_ = new DynamicCommandExceptionType(
        p_308317_ -> Component.m_307043_("command.exception", p_308317_)
    );

    @Override
    public Dynamic2CommandExceptionType doubleTooLow() {
        return f_77129_;
    }

    @Override
    public Dynamic2CommandExceptionType doubleTooHigh() {
        return f_77130_;
    }

    @Override
    public Dynamic2CommandExceptionType floatTooLow() {
        return f_77131_;
    }

    @Override
    public Dynamic2CommandExceptionType floatTooHigh() {
        return f_77132_;
    }

    @Override
    public Dynamic2CommandExceptionType integerTooLow() {
        return f_77133_;
    }

    @Override
    public Dynamic2CommandExceptionType integerTooHigh() {
        return f_77134_;
    }

    @Override
    public Dynamic2CommandExceptionType longTooLow() {
        return f_77135_;
    }

    @Override
    public Dynamic2CommandExceptionType longTooHigh() {
        return f_77136_;
    }

    @Override
    public DynamicCommandExceptionType literalIncorrect() {
        return f_77137_;
    }

    @Override
    public SimpleCommandExceptionType readerExpectedStartOfQuote() {
        return f_77138_;
    }

    @Override
    public SimpleCommandExceptionType readerExpectedEndOfQuote() {
        return f_77139_;
    }

    @Override
    public DynamicCommandExceptionType readerInvalidEscape() {
        return f_77140_;
    }

    @Override
    public DynamicCommandExceptionType readerInvalidBool() {
        return f_77141_;
    }

    @Override
    public DynamicCommandExceptionType readerInvalidInt() {
        return f_77142_;
    }

    @Override
    public SimpleCommandExceptionType readerExpectedInt() {
        return f_77143_;
    }

    @Override
    public DynamicCommandExceptionType readerInvalidLong() {
        return f_77144_;
    }

    @Override
    public SimpleCommandExceptionType readerExpectedLong() {
        return f_77145_;
    }

    @Override
    public DynamicCommandExceptionType readerInvalidDouble() {
        return f_77146_;
    }

    @Override
    public SimpleCommandExceptionType readerExpectedDouble() {
        return f_77147_;
    }

    @Override
    public DynamicCommandExceptionType readerInvalidFloat() {
        return f_77148_;
    }

    @Override
    public SimpleCommandExceptionType readerExpectedFloat() {
        return f_77149_;
    }

    @Override
    public SimpleCommandExceptionType readerExpectedBool() {
        return f_77150_;
    }

    @Override
    public DynamicCommandExceptionType readerExpectedSymbol() {
        return f_77151_;
    }

    @Override
    public SimpleCommandExceptionType dispatcherUnknownCommand() {
        return f_77152_;
    }

    @Override
    public SimpleCommandExceptionType dispatcherUnknownArgument() {
        return f_77153_;
    }

    @Override
    public SimpleCommandExceptionType dispatcherExpectedArgumentSeparator() {
        return f_77154_;
    }

    @Override
    public DynamicCommandExceptionType dispatcherParseException() {
        return f_77128_;
    }
}