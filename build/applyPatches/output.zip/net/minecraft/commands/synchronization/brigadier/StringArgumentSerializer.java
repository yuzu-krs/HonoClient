package net.minecraft.commands.synchronization.brigadier;

import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType.StringType;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.synchronization.ArgumentTypeInfo;
import net.minecraft.network.FriendlyByteBuf;

public class StringArgumentSerializer implements ArgumentTypeInfo<StringArgumentType, StringArgumentSerializer.Template> {
    public void m_214155_(StringArgumentSerializer.Template p_235616_, FriendlyByteBuf p_235617_) {
        p_235617_.m_130068_(p_235616_.f_235623_);
    }

    public StringArgumentSerializer.Template m_213618_(FriendlyByteBuf p_235619_) {
        StringType stringtype = p_235619_.m_130066_(StringType.class);
        return new StringArgumentSerializer.Template(stringtype);
    }

    public void m_213719_(StringArgumentSerializer.Template p_235613_, JsonObject p_235614_) {
        p_235614_.addProperty("type", switch (p_235613_.f_235623_) {
            case SINGLE_WORD -> "word";
            case QUOTABLE_PHRASE -> "phrase";
            case GREEDY_PHRASE -> "greedy";
        });
    }

    public StringArgumentSerializer.Template m_214163_(StringArgumentType p_235605_) {
        return new StringArgumentSerializer.Template(p_235605_.getType());
    }

    public final class Template implements ArgumentTypeInfo.Template<StringArgumentType> {
        final StringType f_235623_;

        public Template(final StringType p_235626_) {
            this.f_235623_ = p_235626_;
        }

        public StringArgumentType m_213879_(CommandBuildContext p_235629_) {
            return switch (this.f_235623_) {
                case SINGLE_WORD -> StringArgumentType.word();
                case QUOTABLE_PHRASE -> StringArgumentType.string();
                case GREEDY_PHRASE -> StringArgumentType.greedyString();
            };
        }

        @Override
        public ArgumentTypeInfo<StringArgumentType, ?> m_213709_() {
            return StringArgumentSerializer.this;
        }
    }
}