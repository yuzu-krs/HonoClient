package net.minecraft.locale;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;

public record DeprecatedTranslationsInfo(List<String> f_348355_, Map<String, String> f_346567_) {
    private static final Logger f_348795_ = LogUtils.getLogger();
    public static final DeprecatedTranslationsInfo f_347001_ = new DeprecatedTranslationsInfo(List.of(), Map.of());
    public static final Codec<DeprecatedTranslationsInfo> f_348110_ = RecordCodecBuilder.create(
        p_368182_ -> p_368182_.group(
                    Codec.STRING.listOf().fieldOf("removed").forGetter(DeprecatedTranslationsInfo::f_348355_),
                    Codec.unboundedMap(Codec.STRING, Codec.STRING).fieldOf("renamed").forGetter(DeprecatedTranslationsInfo::f_346567_)
                )
                .apply(p_368182_, DeprecatedTranslationsInfo::new)
    );

    public static DeprecatedTranslationsInfo m_352734_(InputStream p_366953_) {
        JsonElement jsonelement = JsonParser.parseReader(new InputStreamReader(p_366953_, StandardCharsets.UTF_8));
        return f_348110_.parse(JsonOps.INSTANCE, jsonelement)
            .getOrThrow(p_370184_ -> new IllegalStateException("Failed to parse deprecated language data: " + p_370184_));
    }

    public static DeprecatedTranslationsInfo m_357384_(String p_369676_) {
        try (InputStream inputstream = Language.class.getResourceAsStream(p_369676_)) {
            return inputstream != null ? m_352734_(inputstream) : f_347001_;
        } catch (Exception exception) {
            f_348795_.error("Failed to read {}", p_369676_, exception);
            return f_347001_;
        }
    }

    public static DeprecatedTranslationsInfo m_353299_() {
        return m_357384_("/assets/minecraft/lang/deprecated.json");
    }

    public void m_353887_(Map<String, String> p_370162_) {
        for (String s : this.f_348355_) {
            p_370162_.remove(s);
        }

        this.f_346567_.forEach((p_363113_, p_364770_) -> {
            String s1 = p_370162_.remove(p_363113_);
            if (s1 == null) {
                f_348795_.warn("Missing translation key for rename: {}", p_363113_);
                p_370162_.remove(p_364770_);
            } else {
                p_370162_.put(p_364770_, s1);
            }
        });
    }
}