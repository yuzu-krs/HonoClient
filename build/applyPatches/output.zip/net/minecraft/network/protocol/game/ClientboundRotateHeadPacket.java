package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

public class ClientboundRotateHeadPacket implements Packet<ClientGamePacketListener> {
    public static final StreamCodec<FriendlyByteBuf, ClientboundRotateHeadPacket> f_315782_ = Packet.m_319422_(
        ClientboundRotateHeadPacket::m_132978_, ClientboundRotateHeadPacket::new
    );
    private final int f_132963_;
    private final byte f_132964_;

    public ClientboundRotateHeadPacket(Entity p_132967_, byte p_132968_) {
        this.f_132963_ = p_132967_.m_19879_();
        this.f_132964_ = p_132968_;
    }

    private ClientboundRotateHeadPacket(FriendlyByteBuf p_179193_) {
        this.f_132963_ = p_179193_.m_130242_();
        this.f_132964_ = p_179193_.readByte();
    }

    private void m_132978_(FriendlyByteBuf p_132979_) {
        p_132979_.m_130130_(this.f_132963_);
        p_132979_.writeByte(this.f_132964_);
    }

    @Override
    public PacketType<ClientboundRotateHeadPacket> m_5779_() {
        return GamePacketTypes.f_316835_;
    }

    public void m_5797_(ClientGamePacketListener p_132976_) {
        p_132976_.m_6176_(this);
    }

    public Entity m_132969_(Level p_132970_) {
        return p_132970_.m_6815_(this.f_132963_);
    }

    public float m_132977_() {
        return Mth.m_355125_(this.f_132964_);
    }
}