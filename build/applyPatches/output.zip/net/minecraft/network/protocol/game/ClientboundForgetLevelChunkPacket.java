package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.ChunkPos;

public record ClientboundForgetLevelChunkPacket(ChunkPos f_290761_) implements Packet<ClientGamePacketListener> {
    public static final StreamCodec<FriendlyByteBuf, ClientboundForgetLevelChunkPacket> f_315427_ = Packet.m_319422_(
        ClientboundForgetLevelChunkPacket::m_132150_, ClientboundForgetLevelChunkPacket::new
    );

    private ClientboundForgetLevelChunkPacket(FriendlyByteBuf p_178858_) {
        this(p_178858_.m_178383_());
    }

    private void m_132150_(FriendlyByteBuf p_132151_) {
        p_132151_.m_178341_(this.f_290761_);
    }

    @Override
    public PacketType<ClientboundForgetLevelChunkPacket> m_5779_() {
        return GamePacketTypes.f_314033_;
    }

    public void m_5797_(ClientGamePacketListener p_132148_) {
        p_132148_.m_5729_(this);
    }
}