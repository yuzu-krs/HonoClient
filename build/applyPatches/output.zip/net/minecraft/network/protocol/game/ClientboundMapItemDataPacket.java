package net.minecraft.network.protocol.game;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.level.saveddata.maps.MapDecoration;
import net.minecraft.world.level.saveddata.maps.MapId;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;

public record ClientboundMapItemDataPacket(
    MapId f_132415_, byte f_132416_, boolean f_132418_, Optional<List<MapDecoration>> f_132419_, Optional<MapItemSavedData.MapPatch> f_178968_
) implements Packet<ClientGamePacketListener> {
    public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundMapItemDataPacket> f_314295_ = StreamCodec.m_319894_(
        MapId.f_315416_,
        ClientboundMapItemDataPacket::f_132415_,
        ByteBufCodecs.f_313954_,
        ClientboundMapItemDataPacket::f_132416_,
        ByteBufCodecs.f_315514_,
        ClientboundMapItemDataPacket::f_132418_,
        MapDecoration.f_314705_.m_321801_(ByteBufCodecs.m_324765_()).m_321801_(ByteBufCodecs::m_319027_),
        ClientboundMapItemDataPacket::f_132419_,
        MapItemSavedData.MapPatch.f_315636_,
        ClientboundMapItemDataPacket::f_178968_,
        ClientboundMapItemDataPacket::new
    );

    public ClientboundMapItemDataPacket(
        MapId p_332536_, byte p_327887_, boolean p_335452_, @Nullable Collection<MapDecoration> p_328950_, @Nullable MapItemSavedData.MapPatch p_329006_
    ) {
        this(p_332536_, p_327887_, p_335452_, p_328950_ != null ? Optional.of(List.copyOf(p_328950_)) : Optional.empty(), Optional.ofNullable(p_329006_));
    }

    @Override
    public PacketType<ClientboundMapItemDataPacket> m_5779_() {
        return GamePacketTypes.f_314260_;
    }

    public void m_5797_(ClientGamePacketListener p_132444_) {
        p_132444_.m_7633_(this);
    }

    public void m_132437_(MapItemSavedData p_132438_) {
        this.f_132419_.ifPresent(p_132438_::m_164801_);
        this.f_178968_.ifPresent(p_326099_ -> p_326099_.m_164832_(p_132438_));
    }
}