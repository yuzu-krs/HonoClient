package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.PositionMoveRotation;

public record ClientboundEntityPositionSyncPacket(int f_346882_, PositionMoveRotation f_348286_, boolean f_349202_) implements Packet<ClientGamePacketListener> {
    public static final StreamCodec<FriendlyByteBuf, ClientboundEntityPositionSyncPacket> f_347436_ = StreamCodec.m_321516_(
        ByteBufCodecs.f_316730_,
        ClientboundEntityPositionSyncPacket::f_346882_,
        PositionMoveRotation.f_346971_,
        ClientboundEntityPositionSyncPacket::f_348286_,
        ByteBufCodecs.f_315514_,
        ClientboundEntityPositionSyncPacket::f_349202_,
        ClientboundEntityPositionSyncPacket::new
    );

    public static ClientboundEntityPositionSyncPacket m_351636_(Entity p_365521_) {
        return new ClientboundEntityPositionSyncPacket(
            p_365521_.m_19879_(),
            new PositionMoveRotation(p_365521_.m_213870_(), p_365521_.m_20184_(), p_365521_.m_146908_(), p_365521_.m_146909_()),
            p_365521_.m_20096_()
        );
    }

    @Override
    public PacketType<ClientboundEntityPositionSyncPacket> m_5779_() {
        return GamePacketTypes.f_346251_;
    }

    public void m_5797_(ClientGamePacketListener p_363663_) {
        p_363663_.m_351980_(this);
    }
}