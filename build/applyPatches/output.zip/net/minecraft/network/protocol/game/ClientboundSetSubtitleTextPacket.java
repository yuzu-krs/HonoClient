package net.minecraft.network.protocol.game;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ClientboundSetSubtitleTextPacket(Component f_179374_) implements Packet<ClientGamePacketListener> {
    public static final StreamCodec<RegistryFriendlyByteBuf, ClientboundSetSubtitleTextPacket> f_315951_ = StreamCodec.m_322204_(
        ComponentSerialization.f_316335_, ClientboundSetSubtitleTextPacket::f_179374_, ClientboundSetSubtitleTextPacket::new
    );

    @Override
    public PacketType<ClientboundSetSubtitleTextPacket> m_5779_() {
        return GamePacketTypes.f_315692_;
    }

    public void m_5797_(ClientGamePacketListener p_179384_) {
        p_179384_.m_141913_(this);
    }
}