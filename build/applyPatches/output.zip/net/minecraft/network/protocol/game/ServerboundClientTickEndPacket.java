package net.minecraft.network.protocol.game;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ServerboundClientTickEndPacket() implements Packet<ServerGamePacketListener> {
    public static final ServerboundClientTickEndPacket f_346337_ = new ServerboundClientTickEndPacket();
    public static final StreamCodec<ByteBuf, ServerboundClientTickEndPacket> f_348144_ = StreamCodec.m_323136_(f_346337_);

    @Override
    public PacketType<ServerboundClientTickEndPacket> m_5779_() {
        return GamePacketTypes.f_349007_;
    }

    public void m_5797_(ServerGamePacketListener p_361876_) {
        p_361876_.m_352855_(this);
    }
}