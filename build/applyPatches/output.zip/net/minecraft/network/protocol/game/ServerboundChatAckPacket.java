package net.minecraft.network.protocol.game;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ServerboundChatAckPacket(int f_244085_) implements Packet<ServerGamePacketListener> {
    public static final StreamCodec<FriendlyByteBuf, ServerboundChatAckPacket> f_314055_ = Packet.m_319422_(
        ServerboundChatAckPacket::m_242013_, ServerboundChatAckPacket::new
    );

    private ServerboundChatAckPacket(FriendlyByteBuf p_242339_) {
        this(p_242339_.m_130242_());
    }

    private void m_242013_(FriendlyByteBuf p_242345_) {
        p_242345_.m_130130_(this.f_244085_);
    }

    @Override
    public PacketType<ServerboundChatAckPacket> m_5779_() {
        return GamePacketTypes.f_316322_;
    }

    public void m_5797_(ServerGamePacketListener p_242391_) {
        p_242391_.m_241885_(this);
    }
}