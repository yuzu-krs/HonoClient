package net.minecraft.network.protocol.game;

import javax.annotation.Nullable;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.resources.ResourceLocation;

public class ClientboundSelectAdvancementsTabPacket implements Packet<ClientGamePacketListener> {
    public static final StreamCodec<FriendlyByteBuf, ClientboundSelectAdvancementsTabPacket> f_315979_ = Packet.m_319422_(
        ClientboundSelectAdvancementsTabPacket::m_133014_, ClientboundSelectAdvancementsTabPacket::new
    );
    @Nullable
    private final ResourceLocation f_133003_;

    public ClientboundSelectAdvancementsTabPacket(@Nullable ResourceLocation p_133006_) {
        this.f_133003_ = p_133006_;
    }

    private ClientboundSelectAdvancementsTabPacket(FriendlyByteBuf p_179198_) {
        this.f_133003_ = p_179198_.m_236868_(FriendlyByteBuf::m_130281_);
    }

    private void m_133014_(FriendlyByteBuf p_133015_) {
        p_133015_.m_321806_(this.f_133003_, FriendlyByteBuf::m_130085_);
    }

    @Override
    public PacketType<ClientboundSelectAdvancementsTabPacket> m_5779_() {
        return GamePacketTypes.f_315708_;
    }

    public void m_5797_(ClientGamePacketListener p_133012_) {
        p_133012_.m_7553_(this);
    }

    @Nullable
    public ResourceLocation m_133013_() {
        return this.f_133003_;
    }
}