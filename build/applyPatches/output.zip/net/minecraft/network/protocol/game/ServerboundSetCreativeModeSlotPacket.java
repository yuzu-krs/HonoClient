package net.minecraft.network.protocol.game;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.world.item.ItemStack;

public record ServerboundSetCreativeModeSlotPacket(short f_134549_, ItemStack f_134550_) implements Packet<ServerGamePacketListener> {
    public static final StreamCodec<RegistryFriendlyByteBuf, ServerboundSetCreativeModeSlotPacket> f_316304_ = StreamCodec.m_320349_(
        ByteBufCodecs.f_315014_,
        ServerboundSetCreativeModeSlotPacket::f_134549_,
        ItemStack.m_319263_(ItemStack.f_314979_),
        ServerboundSetCreativeModeSlotPacket::f_134550_,
        ServerboundSetCreativeModeSlotPacket::new
    );

    public ServerboundSetCreativeModeSlotPacket(int p_134553_, ItemStack p_134554_) {
        this((short)p_134553_, p_134554_);
    }

    @Override
    public PacketType<ServerboundSetCreativeModeSlotPacket> m_5779_() {
        return GamePacketTypes.f_316927_;
    }

    public void m_5797_(ServerGamePacketListener p_134560_) {
        p_134560_.m_5964_(this);
    }
}