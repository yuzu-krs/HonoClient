package net.minecraft.network.protocol.login;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public class ClientboundLoginCompressionPacket implements Packet<ClientLoginPacketListener> {
    public static final StreamCodec<FriendlyByteBuf, ClientboundLoginCompressionPacket> f_314441_ = Packet.m_319422_(
        ClientboundLoginCompressionPacket::m_134807_, ClientboundLoginCompressionPacket::new
    );
    private final int f_134796_;

    public ClientboundLoginCompressionPacket(int p_134799_) {
        this.f_134796_ = p_134799_;
    }

    private ClientboundLoginCompressionPacket(FriendlyByteBuf p_179818_) {
        this.f_134796_ = p_179818_.m_130242_();
    }

    private void m_134807_(FriendlyByteBuf p_134808_) {
        p_134808_.m_130130_(this.f_134796_);
    }

    @Override
    public PacketType<ClientboundLoginCompressionPacket> m_5779_() {
        return LoginPacketTypes.f_315271_;
    }

    public void m_5797_(ClientLoginPacketListener p_134805_) {
        p_134805_.m_5693_(this);
    }

    public int m_134806_() {
        return this.f_134796_;
    }
}