package net.minecraft.network.protocol.status;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;

public record ClientboundStatusResponsePacket(ServerStatus f_134886_) implements Packet<ClientStatusPacketListener> {
    public static final StreamCodec<FriendlyByteBuf, ClientboundStatusResponsePacket> f_316394_ = Packet.m_319422_(
        ClientboundStatusResponsePacket::m_134898_, ClientboundStatusResponsePacket::new
    );

    private ClientboundStatusResponsePacket(FriendlyByteBuf p_179834_) {
        this(p_179834_.m_271872_(ServerStatus.f_271163_));
    }

    private void m_134898_(FriendlyByteBuf p_134899_) {
        p_134899_.m_272073_(ServerStatus.f_271163_, this.f_134886_);
    }

    @Override
    public PacketType<ClientboundStatusResponsePacket> m_5779_() {
        return StatusPacketTypes.f_315020_;
    }

    public void m_5797_(ClientStatusPacketListener p_134896_) {
        p_134896_.m_6440_(this);
    }
}