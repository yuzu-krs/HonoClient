package net.minecraft.network.protocol.status;

import net.minecraft.network.ConnectionProtocol;
import net.minecraft.network.protocol.game.ServerPacketListener;
import net.minecraft.network.protocol.ping.ServerPingPacketListener;

public interface ServerStatusPacketListener extends ServerPacketListener, ServerPingPacketListener {
    @Override
    default ConnectionProtocol m_292716_() {
        return ConnectionProtocol.STATUS;
    }

    void m_6733_(ServerboundStatusRequestPacket p_134987_);
}