package net.minecraft.network.protocol.cookie;

import net.minecraft.network.protocol.game.ServerPacketListener;

public interface ServerCookiePacketListener extends ServerPacketListener {
    void m_320234_(ServerboundCookieResponsePacket p_329158_);
}