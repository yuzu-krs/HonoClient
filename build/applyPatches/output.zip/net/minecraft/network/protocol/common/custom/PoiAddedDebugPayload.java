package net.minecraft.network.protocol.common.custom;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;

public record PoiAddedDebugPayload(BlockPos f_290840_, String f_315076_, int f_290692_) implements CustomPacketPayload {
    public static final StreamCodec<FriendlyByteBuf, PoiAddedDebugPayload> f_315048_ = CustomPacketPayload.m_320054_(
        PoiAddedDebugPayload::m_293671_, PoiAddedDebugPayload::new
    );
    public static final CustomPacketPayload.Type<PoiAddedDebugPayload> f_315969_ = CustomPacketPayload.m_319865_("debug/poi_added");

    private PoiAddedDebugPayload(FriendlyByteBuf p_300736_) {
        this(p_300736_.m_130135_(), p_300736_.m_130277_(), p_300736_.readInt());
    }

    private void m_293671_(FriendlyByteBuf p_298137_) {
        p_298137_.m_130064_(this.f_290840_);
        p_298137_.m_130070_(this.f_315076_);
        p_298137_.writeInt(this.f_290692_);
    }

    @Override
    public CustomPacketPayload.Type<PoiAddedDebugPayload> m_293297_() {
        return f_315969_;
    }
}