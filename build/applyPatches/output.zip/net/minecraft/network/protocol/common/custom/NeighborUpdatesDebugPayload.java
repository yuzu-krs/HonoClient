package net.minecraft.network.protocol.common.custom;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;

public record NeighborUpdatesDebugPayload(long f_291308_, BlockPos f_290702_) implements CustomPacketPayload {
    public static final StreamCodec<FriendlyByteBuf, NeighborUpdatesDebugPayload> f_315097_ = CustomPacketPayload.m_320054_(
        NeighborUpdatesDebugPayload::m_293601_, NeighborUpdatesDebugPayload::new
    );
    public static final CustomPacketPayload.Type<NeighborUpdatesDebugPayload> f_316722_ = CustomPacketPayload.m_319865_("debug/neighbors_update");

    private NeighborUpdatesDebugPayload(FriendlyByteBuf p_301219_) {
        this(p_301219_.m_130258_(), p_301219_.m_130135_());
    }

    private void m_293601_(FriendlyByteBuf p_300822_) {
        p_300822_.m_130103_(this.f_291308_);
        p_300822_.m_130064_(this.f_290702_);
    }

    @Override
    public CustomPacketPayload.Type<NeighborUpdatesDebugPayload> m_293297_() {
        return f_316722_;
    }
}