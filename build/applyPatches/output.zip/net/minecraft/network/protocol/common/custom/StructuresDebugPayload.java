package net.minecraft.network.protocol.common.custom;

import java.util.List;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.BoundingBox;

public record StructuresDebugPayload(ResourceKey<Level> f_291455_, BoundingBox f_291102_, List<StructuresDebugPayload.PieceInfo> f_291713_)
    implements CustomPacketPayload {
    public static final StreamCodec<FriendlyByteBuf, StructuresDebugPayload> f_314526_ = CustomPacketPayload.m_320054_(
        StructuresDebugPayload::m_294561_, StructuresDebugPayload::new
    );
    public static final CustomPacketPayload.Type<StructuresDebugPayload> f_314744_ = CustomPacketPayload.m_319865_("debug/structures");

    private StructuresDebugPayload(FriendlyByteBuf p_301247_) {
        this(p_301247_.m_236801_(Registries.f_256858_), m_295155_(p_301247_), p_301247_.m_236845_(StructuresDebugPayload.PieceInfo::new));
    }

    private void m_294561_(FriendlyByteBuf p_300362_) {
        p_300362_.m_236858_(this.f_291455_);
        m_292876_(p_300362_, this.f_291102_);
        p_300362_.m_236828_(this.f_291713_, (p_300337_, p_299834_) -> p_299834_.m_295379_(p_300362_));
    }

    @Override
    public CustomPacketPayload.Type<StructuresDebugPayload> m_293297_() {
        return f_314744_;
    }

    static BoundingBox m_295155_(FriendlyByteBuf p_297781_) {
        return new BoundingBox(p_297781_.readInt(), p_297781_.readInt(), p_297781_.readInt(), p_297781_.readInt(), p_297781_.readInt(), p_297781_.readInt());
    }

    static void m_292876_(FriendlyByteBuf p_300963_, BoundingBox p_297295_) {
        p_300963_.writeInt(p_297295_.m_162395_());
        p_300963_.writeInt(p_297295_.m_162396_());
        p_300963_.writeInt(p_297295_.m_162398_());
        p_300963_.writeInt(p_297295_.m_162399_());
        p_300963_.writeInt(p_297295_.m_162400_());
        p_300963_.writeInt(p_297295_.m_162401_());
    }

    public static record PieceInfo(BoundingBox f_290604_, boolean f_291404_) {
        public PieceInfo(FriendlyByteBuf p_297915_) {
            this(StructuresDebugPayload.m_295155_(p_297915_), p_297915_.readBoolean());
        }

        public void m_295379_(FriendlyByteBuf p_298576_) {
            StructuresDebugPayload.m_292876_(p_298576_, this.f_290604_);
            p_298576_.writeBoolean(this.f_291404_);
        }
    }
}