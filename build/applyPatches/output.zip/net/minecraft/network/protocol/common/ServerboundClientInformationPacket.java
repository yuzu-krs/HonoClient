package net.minecraft.network.protocol.common;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketType;
import net.minecraft.server.level.ClientInformation;

public record ServerboundClientInformationPacket(ClientInformation f_291402_) implements Packet<ServerCommonPacketListener> {
    public static final StreamCodec<FriendlyByteBuf, ServerboundClientInformationPacket> f_315737_ = Packet.m_319422_(
        ServerboundClientInformationPacket::m_295726_, ServerboundClientInformationPacket::new
    );

    private ServerboundClientInformationPacket(FriendlyByteBuf p_299808_) {
        this(new ClientInformation(p_299808_));
    }

    private void m_295726_(FriendlyByteBuf p_298054_) {
        this.f_291402_.m_293760_(p_298054_);
    }

    @Override
    public PacketType<ServerboundClientInformationPacket> m_5779_() {
        return CommonPacketTypes.f_314731_;
    }

    public void m_5797_(ServerCommonPacketListener p_300686_) {
        p_300686_.m_9844_(this);
    }
}