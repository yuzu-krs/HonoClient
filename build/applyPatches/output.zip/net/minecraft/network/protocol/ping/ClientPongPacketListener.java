package net.minecraft.network.protocol.ping;

import net.minecraft.network.PacketListener;

public interface ClientPongPacketListener extends PacketListener {
    void m_105486_(ClientboundPongResponsePacket p_329136_);
}