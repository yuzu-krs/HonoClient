package net.minecraft.network.syncher;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;

public interface EntityDataSerializer<T> {
    StreamCodec<? super RegistryFriendlyByteBuf, T> m_321181_();

    default EntityDataAccessor<T> m_135021_(int p_135022_) {
        return new EntityDataAccessor<>(p_135022_, this);
    }

    T m_7020_(T p_135023_);

    static <T> EntityDataSerializer<T> m_322970_(StreamCodec<? super RegistryFriendlyByteBuf, T> p_332495_) {
        return (ForValueType<T>)() -> p_332495_;
    }

    public interface ForValueType<T> extends EntityDataSerializer<T> {
        @Override
        default T m_7020_(T p_238112_) {
            return p_238112_;
        }
    }
}
