package net.minecraft.client.particle;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class FlyTowardsPositionParticle extends TextureSheetParticle {
    private final double f_315124_;
    private final double f_315139_;
    private final double f_316468_;
    private final boolean f_315499_;
    private final Particle.LifetimeAlpha f_314137_;

    FlyTowardsPositionParticle(
        ClientLevel p_333327_, double p_328158_, double p_336092_, double p_331009_, double p_335556_, double p_328514_, double p_331083_
    ) {
        this(p_333327_, p_328158_, p_336092_, p_331009_, p_335556_, p_328514_, p_331083_, false, Particle.LifetimeAlpha.f_314120_);
    }

    FlyTowardsPositionParticle(
        ClientLevel p_335275_,
        double p_329537_,
        double p_335588_,
        double p_335971_,
        double p_331161_,
        double p_331135_,
        double p_331015_,
        boolean p_334585_,
        Particle.LifetimeAlpha p_330679_
    ) {
        super(p_335275_, p_329537_, p_335588_, p_335971_);
        this.f_315499_ = p_334585_;
        this.f_314137_ = p_330679_;
        this.m_107271_(p_330679_.f_315806_());
        this.f_107215_ = p_331161_;
        this.f_107216_ = p_331135_;
        this.f_107217_ = p_331015_;
        this.f_315124_ = p_329537_;
        this.f_315139_ = p_335588_;
        this.f_316468_ = p_335971_;
        this.f_107209_ = p_329537_ + p_331161_;
        this.f_107210_ = p_335588_ + p_331135_;
        this.f_107211_ = p_335971_ + p_331015_;
        this.f_107212_ = this.f_107209_;
        this.f_107213_ = this.f_107210_;
        this.f_107214_ = this.f_107211_;
        this.f_107663_ = 0.1F * (this.f_107223_.m_188501_() * 0.5F + 0.2F);
        float f = this.f_107223_.m_188501_() * 0.6F + 0.4F;
        this.f_107227_ = 0.9F * f;
        this.f_107228_ = 0.9F * f;
        this.f_107229_ = f;
        this.f_107219_ = false;
        this.f_107225_ = (int)(Math.random() * 10.0) + 30;
    }

    @Override
    public ParticleRenderType m_7556_() {
        return this.f_314137_.m_320160_() ? ParticleRenderType.f_107430_ : ParticleRenderType.f_107431_;
    }

    @Override
    public void m_6257_(double p_335599_, double p_330355_, double p_329221_) {
        this.m_107259_(this.m_107277_().m_82386_(p_335599_, p_330355_, p_329221_));
        this.m_107275_();
    }

    @Override
    public int m_6355_(float p_334485_) {
        if (this.f_315499_) {
            return 240;
        } else {
            int i = super.m_6355_(p_334485_);
            float f = (float)this.f_107224_ / (float)this.f_107225_;
            f *= f;
            f *= f;
            int j = i & 0xFF;
            int k = i >> 16 & 0xFF;
            k += (int)(f * 15.0F * 16.0F);
            if (k > 240) {
                k = 240;
            }

            return j | k << 16;
        }
    }

    @Override
    public void m_5989_() {
        this.f_107209_ = this.f_107212_;
        this.f_107210_ = this.f_107213_;
        this.f_107211_ = this.f_107214_;
        if (this.f_107224_++ >= this.f_107225_) {
            this.m_107274_();
        } else {
            float f = (float)this.f_107224_ / (float)this.f_107225_;
            f = 1.0F - f;
            float f1 = 1.0F - f;
            f1 *= f1;
            f1 *= f1;
            this.f_107212_ = this.f_315124_ + this.f_107215_ * (double)f;
            this.f_107213_ = this.f_315139_ + this.f_107216_ * (double)f - (double)(f1 * 1.2F);
            this.f_107214_ = this.f_316468_ + this.f_107217_ * (double)f;
        }
    }

    @Override
    public void m_5744_(VertexConsumer p_329880_, Camera p_328408_, float p_328709_) {
        this.m_107271_(this.f_314137_.m_320282_(this.f_107224_, this.f_107225_, p_328709_));
        super.m_5744_(p_329880_, p_328408_, p_328709_);
    }

    @OnlyIn(Dist.CLIENT)
    public static class EnchantProvider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet f_316710_;

        public EnchantProvider(SpriteSet p_333845_) {
            this.f_316710_ = p_333845_;
        }

        public Particle m_6966_(
            SimpleParticleType p_330246_,
            ClientLevel p_334642_,
            double p_331946_,
            double p_331936_,
            double p_330331_,
            double p_330075_,
            double p_332423_,
            double p_336053_
        ) {
            FlyTowardsPositionParticle flytowardspositionparticle = new FlyTowardsPositionParticle(
                p_334642_, p_331946_, p_331936_, p_330331_, p_330075_, p_332423_, p_336053_
            );
            flytowardspositionparticle.m_108335_(this.f_316710_);
            return flytowardspositionparticle;
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class NautilusProvider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet f_316199_;

        public NautilusProvider(SpriteSet p_331980_) {
            this.f_316199_ = p_331980_;
        }

        public Particle m_6966_(
            SimpleParticleType p_327773_,
            ClientLevel p_332234_,
            double p_328567_,
            double p_328371_,
            double p_328714_,
            double p_333049_,
            double p_332373_,
            double p_331353_
        ) {
            FlyTowardsPositionParticle flytowardspositionparticle = new FlyTowardsPositionParticle(
                p_332234_, p_328567_, p_328371_, p_328714_, p_333049_, p_332373_, p_331353_
            );
            flytowardspositionparticle.m_108335_(this.f_316199_);
            return flytowardspositionparticle;
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class VaultConnectionProvider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet f_315002_;

        public VaultConnectionProvider(SpriteSet p_329375_) {
            this.f_315002_ = p_329375_;
        }

        public Particle m_6966_(
            SimpleParticleType p_328352_,
            ClientLevel p_333387_,
            double p_328138_,
            double p_329009_,
            double p_334265_,
            double p_336214_,
            double p_330704_,
            double p_328353_
        ) {
            FlyTowardsPositionParticle flytowardspositionparticle = new FlyTowardsPositionParticle(
                p_333387_, p_328138_, p_329009_, p_334265_, p_336214_, p_330704_, p_328353_, true, new Particle.LifetimeAlpha(0.0F, 0.6F, 0.25F, 1.0F)
            );
            flytowardspositionparticle.m_6569_(1.5F);
            flytowardspositionparticle.m_108335_(this.f_315002_);
            return flytowardspositionparticle;
        }
    }
}