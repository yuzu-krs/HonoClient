package net.minecraft.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class FlyStraightTowardsParticle extends TextureSheetParticle {
    private final double f_316865_;
    private final double f_315147_;
    private final double f_316216_;
    private final int f_316150_;
    private final int f_315653_;

    FlyStraightTowardsParticle(
        ClientLevel p_331392_,
        double p_328454_,
        double p_335936_,
        double p_334729_,
        double p_335747_,
        double p_333574_,
        double p_334122_,
        int p_328231_,
        int p_329614_
    ) {
        super(p_331392_, p_328454_, p_335936_, p_334729_);
        this.f_107215_ = p_335747_;
        this.f_107216_ = p_333574_;
        this.f_107217_ = p_334122_;
        this.f_316865_ = p_328454_;
        this.f_315147_ = p_335936_;
        this.f_316216_ = p_334729_;
        this.f_107209_ = p_328454_ + p_335747_;
        this.f_107210_ = p_335936_ + p_333574_;
        this.f_107211_ = p_334729_ + p_334122_;
        this.f_107212_ = this.f_107209_;
        this.f_107213_ = this.f_107210_;
        this.f_107214_ = this.f_107211_;
        this.f_107663_ = 0.1F * (this.f_107223_.m_188501_() * 0.5F + 0.2F);
        this.f_107219_ = false;
        this.f_107225_ = (int)(Math.random() * 5.0) + 25;
        this.f_316150_ = p_328231_;
        this.f_315653_ = p_329614_;
    }

    @Override
    public ParticleRenderType m_7556_() {
        return ParticleRenderType.f_107430_;
    }

    @Override
    public void m_6257_(double p_328657_, double p_332590_, double p_331282_) {
    }

    @Override
    public int m_6355_(float p_334272_) {
        return 240;
    }

    @Override
    public void m_5989_() {
        this.f_107209_ = this.f_107212_;
        this.f_107210_ = this.f_107213_;
        this.f_107211_ = this.f_107214_;
        if (this.f_107224_++ >= this.f_107225_) {
            this.m_107274_();
        } else {
            float f = (float)this.f_107224_ / (float)this.f_107225_;
            float f1 = 1.0F - f;
            this.f_107212_ = this.f_316865_ + this.f_107215_ * (double)f1;
            this.f_107213_ = this.f_315147_ + this.f_107216_ * (double)f1;
            this.f_107214_ = this.f_316216_ + this.f_107217_ * (double)f1;
            int i = ARGB.m_354608_(f, this.f_316150_, this.f_315653_);
            this.m_107253_((float)ARGB.m_353456_(i) / 255.0F, (float)ARGB.m_353987_(i) / 255.0F, (float)ARGB.m_353181_(i) / 255.0F);
            this.m_107271_((float)ARGB.m_356301_(i) / 255.0F);
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class OminousSpawnProvider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet f_316079_;

        public OminousSpawnProvider(SpriteSet p_327679_) {
            this.f_316079_ = p_327679_;
        }

        public Particle m_6966_(
            SimpleParticleType p_331905_,
            ClientLevel p_330985_,
            double p_334366_,
            double p_328334_,
            double p_330716_,
            double p_333567_,
            double p_329124_,
            double p_335449_
        ) {
            FlyStraightTowardsParticle flystraighttowardsparticle = new FlyStraightTowardsParticle(
                p_330985_, p_334366_, p_328334_, p_330716_, p_333567_, p_329124_, p_335449_, -12210434, -1
            );
            flystraighttowardsparticle.m_6569_(Mth.m_216283_(p_330985_.m_213780_(), 3.0F, 5.0F));
            flystraighttowardsparticle.m_108335_(this.f_316079_);
            return flystraighttowardsparticle;
        }
    }
}