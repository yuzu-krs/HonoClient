package net.minecraft.client.model;

import com.google.common.collect.ImmutableList;
import java.util.List;
import net.minecraft.client.animation.definitions.WardenAnimation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.state.WardenRenderState;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class WardenModel extends EntityModel<WardenRenderState> {
    private static final float f_233504_ = 13.0F;
    private static final float f_233505_ = 1.0F;
    protected final ModelPart f_233493_;
    protected final ModelPart f_233494_;
    protected final ModelPart f_233495_;
    protected final ModelPart f_233496_;
    protected final ModelPart f_233497_;
    protected final ModelPart f_233498_;
    protected final ModelPart f_233499_;
    protected final ModelPart f_233500_;
    protected final ModelPart f_233501_;
    protected final ModelPart f_233502_;
    protected final ModelPart f_233503_;
    private final List<ModelPart> f_233507_;
    private final List<ModelPart> f_233508_;
    private final List<ModelPart> f_233509_;
    private final List<ModelPart> f_233510_;

    public WardenModel(ModelPart p_233512_) {
        super(p_233512_, RenderType::m_110458_);
        this.f_233493_ = p_233512_.m_171324_("bone");
        this.f_233494_ = this.f_233493_.m_171324_("body");
        this.f_233495_ = this.f_233494_.m_171324_("head");
        this.f_233502_ = this.f_233493_.m_171324_("right_leg");
        this.f_233498_ = this.f_233493_.m_171324_("left_leg");
        this.f_233501_ = this.f_233494_.m_171324_("right_arm");
        this.f_233499_ = this.f_233494_.m_171324_("left_arm");
        this.f_233496_ = this.f_233495_.m_171324_("right_tendril");
        this.f_233497_ = this.f_233495_.m_171324_("left_tendril");
        this.f_233503_ = this.f_233494_.m_171324_("right_ribcage");
        this.f_233500_ = this.f_233494_.m_171324_("left_ribcage");
        this.f_233507_ = ImmutableList.of(this.f_233497_, this.f_233496_);
        this.f_233508_ = ImmutableList.of(this.f_233494_);
        this.f_233509_ = ImmutableList.of(this.f_233495_, this.f_233499_, this.f_233501_, this.f_233498_, this.f_233502_);
        this.f_233510_ = ImmutableList.of(this.f_233494_, this.f_233495_, this.f_233499_, this.f_233501_, this.f_233498_, this.f_233502_);
    }

    public static LayerDefinition m_233537_() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.m_171576_();
        PartDefinition partdefinition1 = partdefinition.m_171599_("bone", CubeListBuilder.m_171558_(), PartPose.m_171419_(0.0F, 24.0F, 0.0F));
        PartDefinition partdefinition2 = partdefinition1.m_171599_(
            "body", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-9.0F, -13.0F, -4.0F, 18.0F, 21.0F, 11.0F), PartPose.m_171419_(0.0F, -21.0F, 0.0F)
        );
        partdefinition2.m_171599_(
            "right_ribcage",
            CubeListBuilder.m_171558_().m_171514_(90, 11).m_171481_(-2.0F, -11.0F, -0.1F, 9.0F, 21.0F, 0.0F),
            PartPose.m_171419_(-7.0F, -2.0F, -4.0F)
        );
        partdefinition2.m_171599_(
            "left_ribcage",
            CubeListBuilder.m_171558_().m_171514_(90, 11).m_171480_().m_171481_(-7.0F, -11.0F, -0.1F, 9.0F, 21.0F, 0.0F).m_171555_(false),
            PartPose.m_171419_(7.0F, -2.0F, -4.0F)
        );
        PartDefinition partdefinition3 = partdefinition2.m_171599_(
            "head", CubeListBuilder.m_171558_().m_171514_(0, 32).m_171481_(-8.0F, -16.0F, -5.0F, 16.0F, 16.0F, 10.0F), PartPose.m_171419_(0.0F, -13.0F, 0.0F)
        );
        partdefinition3.m_171599_(
            "right_tendril",
            CubeListBuilder.m_171558_().m_171514_(52, 32).m_171481_(-16.0F, -13.0F, 0.0F, 16.0F, 16.0F, 0.0F),
            PartPose.m_171419_(-8.0F, -12.0F, 0.0F)
        );
        partdefinition3.m_171599_(
            "left_tendril",
            CubeListBuilder.m_171558_().m_171514_(58, 0).m_171481_(0.0F, -13.0F, 0.0F, 16.0F, 16.0F, 0.0F),
            PartPose.m_171419_(8.0F, -12.0F, 0.0F)
        );
        partdefinition2.m_171599_(
            "right_arm",
            CubeListBuilder.m_171558_().m_171514_(44, 50).m_171481_(-4.0F, 0.0F, -4.0F, 8.0F, 28.0F, 8.0F),
            PartPose.m_171419_(-13.0F, -13.0F, 1.0F)
        );
        partdefinition2.m_171599_(
            "left_arm", CubeListBuilder.m_171558_().m_171514_(0, 58).m_171481_(-4.0F, 0.0F, -4.0F, 8.0F, 28.0F, 8.0F), PartPose.m_171419_(13.0F, -13.0F, 1.0F)
        );
        partdefinition1.m_171599_(
            "right_leg",
            CubeListBuilder.m_171558_().m_171514_(76, 48).m_171481_(-3.1F, 0.0F, -3.0F, 6.0F, 13.0F, 6.0F),
            PartPose.m_171419_(-5.9F, -13.0F, 0.0F)
        );
        partdefinition1.m_171599_(
            "left_leg", CubeListBuilder.m_171558_().m_171514_(76, 76).m_171481_(-2.9F, 0.0F, -3.0F, 6.0F, 13.0F, 6.0F), PartPose.m_171419_(5.9F, -13.0F, 0.0F)
        );
        return LayerDefinition.m_171565_(meshdefinition, 128, 128);
    }

    public void m_6973_(WardenRenderState p_366602_) {
        super.m_6973_(p_366602_);
        this.m_233516_(p_366602_.f_349133_, p_366602_.f_347628_);
        this.m_233538_(p_366602_.f_346252_, p_366602_.f_349061_);
        this.m_233514_(p_366602_.f_349307_);
        this.m_233526_(p_366602_, p_366602_.f_349307_);
        this.m_354607_(p_366602_.f_347596_, WardenAnimation.f_232347_, p_366602_.f_349307_);
        this.m_354607_(p_366602_.f_346312_, WardenAnimation.f_232348_, p_366602_.f_349307_);
        this.m_354607_(p_366602_.f_349480_, WardenAnimation.f_232344_, p_366602_.f_349307_);
        this.m_354607_(p_366602_.f_348040_, WardenAnimation.f_232343_, p_366602_.f_349307_);
        this.m_354607_(p_366602_.f_346265_, WardenAnimation.f_232345_, p_366602_.f_349307_);
        this.m_354607_(p_366602_.f_348367_, WardenAnimation.f_232346_, p_366602_.f_349307_);
    }

    private void m_233516_(float p_233517_, float p_233518_) {
        this.f_233495_.f_104203_ = p_233518_ * (float) (Math.PI / 180.0);
        this.f_233495_.f_104204_ = p_233517_ * (float) (Math.PI / 180.0);
    }

    private void m_233514_(float p_233515_) {
        float f = p_233515_ * 0.1F;
        float f1 = Mth.m_14089_(f);
        float f2 = Mth.m_14031_(f);
        this.f_233495_.f_104205_ += 0.06F * f1;
        this.f_233495_.f_104203_ += 0.06F * f2;
        this.f_233494_.f_104205_ += 0.025F * f2;
        this.f_233494_.f_104203_ += 0.025F * f1;
    }

    private void m_233538_(float p_233539_, float p_233540_) {
        float f = Math.min(0.5F, 3.0F * p_233540_);
        float f1 = p_233539_ * 0.8662F;
        float f2 = Mth.m_14089_(f1);
        float f3 = Mth.m_14031_(f1);
        float f4 = Math.min(0.35F, f);
        this.f_233495_.f_104205_ += 0.3F * f3 * f;
        this.f_233495_.f_104203_ = this.f_233495_.f_104203_ + 1.2F * Mth.m_14089_(f1 + (float) (Math.PI / 2)) * f4;
        this.f_233494_.f_104205_ = 0.1F * f3 * f;
        this.f_233494_.f_104203_ = 1.0F * f2 * f4;
        this.f_233498_.f_104203_ = 1.0F * f2 * f;
        this.f_233502_.f_104203_ = 1.0F * Mth.m_14089_(f1 + (float) Math.PI) * f;
        this.f_233499_.f_104203_ = -(0.8F * f2 * f);
        this.f_233499_.f_104205_ = 0.0F;
        this.f_233501_.f_104203_ = -(0.8F * f3 * f);
        this.f_233501_.f_104205_ = 0.0F;
        this.m_233545_();
    }

    private void m_233545_() {
        this.f_233499_.f_104204_ = 0.0F;
        this.f_233499_.f_104202_ = 1.0F;
        this.f_233499_.f_104200_ = 13.0F;
        this.f_233499_.f_104201_ = -13.0F;
        this.f_233501_.f_104204_ = 0.0F;
        this.f_233501_.f_104202_ = 1.0F;
        this.f_233501_.f_104200_ = -13.0F;
        this.f_233501_.f_104201_ = -13.0F;
    }

    private void m_233526_(WardenRenderState p_370212_, float p_233528_) {
        float f = p_370212_.f_346518_ * (float)(Math.cos((double)p_233528_ * 2.25) * Math.PI * 0.1F);
        this.f_233497_.f_104203_ = f;
        this.f_233496_.f_104203_ = -f;
    }

    public List<ModelPart> m_233541_(WardenRenderState p_361179_) {
        return this.f_233507_;
    }

    public List<ModelPart> m_233542_(WardenRenderState p_367277_) {
        return this.f_233508_;
    }

    public List<ModelPart> m_233543_(WardenRenderState p_366811_) {
        return this.f_233509_;
    }

    public List<ModelPart> m_233544_(WardenRenderState p_366755_) {
        return this.f_233510_;
    }
}