package net.minecraft.client.model;

import java.util.Set;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.MeshTransformer;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.entity.state.ChickenRenderState;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ChickenModel extends EntityModel<ChickenRenderState> {
    public static final String f_170484_ = "red_thing";
    public static final MeshTransformer f_346633_ = new BabyModelTransform(Set.of("head", "beak", "red_thing"));
    private final ModelPart f_102381_;
    private final ModelPart f_170485_;
    private final ModelPart f_170486_;
    private final ModelPart f_170487_;
    private final ModelPart f_170488_;
    private final ModelPart f_102387_;
    private final ModelPart f_102388_;

    public ChickenModel(ModelPart p_170490_) {
        super(p_170490_);
        this.f_102381_ = p_170490_.m_171324_("head");
        this.f_102387_ = p_170490_.m_171324_("beak");
        this.f_102388_ = p_170490_.m_171324_("red_thing");
        this.f_170485_ = p_170490_.m_171324_("right_leg");
        this.f_170486_ = p_170490_.m_171324_("left_leg");
        this.f_170487_ = p_170490_.m_171324_("right_wing");
        this.f_170488_ = p_170490_.m_171324_("left_wing");
    }

    public static LayerDefinition m_170491_() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.m_171576_();
        int i = 16;
        partdefinition.m_171599_(
            "head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-2.0F, -6.0F, -2.0F, 4.0F, 6.0F, 3.0F), PartPose.m_171419_(0.0F, 15.0F, -4.0F)
        );
        partdefinition.m_171599_(
            "beak", CubeListBuilder.m_171558_().m_171514_(14, 0).m_171481_(-2.0F, -4.0F, -4.0F, 4.0F, 2.0F, 2.0F), PartPose.m_171419_(0.0F, 15.0F, -4.0F)
        );
        partdefinition.m_171599_(
            "red_thing", CubeListBuilder.m_171558_().m_171514_(14, 4).m_171481_(-1.0F, -2.0F, -3.0F, 2.0F, 2.0F, 2.0F), PartPose.m_171419_(0.0F, 15.0F, -4.0F)
        );
        partdefinition.m_171599_(
            "body",
            CubeListBuilder.m_171558_().m_171514_(0, 9).m_171481_(-3.0F, -4.0F, -3.0F, 6.0F, 8.0F, 6.0F),
            PartPose.m_171423_(0.0F, 16.0F, 0.0F, (float) (Math.PI / 2), 0.0F, 0.0F)
        );
        CubeListBuilder cubelistbuilder = CubeListBuilder.m_171558_().m_171514_(26, 0).m_171481_(-1.0F, 0.0F, -3.0F, 3.0F, 5.0F, 3.0F);
        partdefinition.m_171599_("right_leg", cubelistbuilder, PartPose.m_171419_(-2.0F, 19.0F, 1.0F));
        partdefinition.m_171599_("left_leg", cubelistbuilder, PartPose.m_171419_(1.0F, 19.0F, 1.0F));
        partdefinition.m_171599_(
            "right_wing", CubeListBuilder.m_171558_().m_171514_(24, 13).m_171481_(0.0F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F), PartPose.m_171419_(-4.0F, 13.0F, 0.0F)
        );
        partdefinition.m_171599_(
            "left_wing", CubeListBuilder.m_171558_().m_171514_(24, 13).m_171481_(-1.0F, 0.0F, -3.0F, 1.0F, 4.0F, 6.0F), PartPose.m_171419_(4.0F, 13.0F, 0.0F)
        );
        return LayerDefinition.m_171565_(meshdefinition, 64, 32);
    }

    public void m_6973_(ChickenRenderState p_369602_) {
        super.m_6973_(p_369602_);
        float f = (Mth.m_14031_(p_369602_.f_348811_) + 1.0F) * p_369602_.f_346881_;
        this.f_102381_.f_104203_ = p_369602_.f_347628_ * (float) (Math.PI / 180.0);
        this.f_102381_.f_104204_ = p_369602_.f_349133_ * (float) (Math.PI / 180.0);
        this.f_102387_.f_104203_ = this.f_102381_.f_104203_;
        this.f_102387_.f_104204_ = this.f_102381_.f_104204_;
        this.f_102388_.f_104203_ = this.f_102381_.f_104203_;
        this.f_102388_.f_104204_ = this.f_102381_.f_104204_;
        float f1 = p_369602_.f_349061_;
        float f2 = p_369602_.f_346252_;
        this.f_170485_.f_104203_ = Mth.m_14089_(f2 * 0.6662F) * 1.4F * f1;
        this.f_170486_.f_104203_ = Mth.m_14089_(f2 * 0.6662F + (float) Math.PI) * 1.4F * f1;
        this.f_170487_.f_104205_ = f;
        this.f_170488_.f_104205_ = -f;
    }
}