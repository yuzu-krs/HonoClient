package net.minecraft.client.model;

import java.util.Set;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.MeshTransformer;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.entity.state.SheepRenderState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class SheepModel extends QuadrupedModel<SheepRenderState> {
    public static final MeshTransformer f_347520_ = new BabyModelTransform(false, 8.0F, 4.0F, 2.0F, 2.0F, 24.0F, Set.of("head"));

    public SheepModel(ModelPart p_170903_) {
        super(p_170903_);
    }

    public static LayerDefinition m_170904_() {
        MeshDefinition meshdefinition = QuadrupedModel.m_170864_(12, CubeDeformation.f_171458_);
        PartDefinition partdefinition = meshdefinition.m_171576_();
        partdefinition.m_171599_(
            "head", CubeListBuilder.m_171558_().m_171514_(0, 0).m_171481_(-3.0F, -4.0F, -6.0F, 6.0F, 6.0F, 8.0F), PartPose.m_171419_(0.0F, 6.0F, -8.0F)
        );
        partdefinition.m_171599_(
            "body",
            CubeListBuilder.m_171558_().m_171514_(28, 8).m_171481_(-4.0F, -10.0F, -7.0F, 8.0F, 16.0F, 6.0F),
            PartPose.m_171423_(0.0F, 5.0F, 2.0F, (float) (Math.PI / 2), 0.0F, 0.0F)
        );
        return LayerDefinition.m_171565_(meshdefinition, 64, 32);
    }

    public void m_6973_(SheepRenderState p_364866_) {
        super.m_6973_(p_364866_);
        this.f_103492_.f_104201_ = this.f_103492_.f_104201_ + p_364866_.f_349256_ * 9.0F * p_364866_.f_347476_;
        this.f_103492_.f_104203_ = p_364866_.f_347908_;
    }
}