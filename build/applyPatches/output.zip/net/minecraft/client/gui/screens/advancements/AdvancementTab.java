package net.minecraft.client.gui.screens.advancements;

import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.advancements.AdvancementNode;
import net.minecraft.advancements.DisplayInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class AdvancementTab {
    private final Minecraft f_97126_;
    private final AdvancementsScreen f_97127_;
    private final AdvancementTabType f_97128_;
    private final int f_97129_;
    private final AdvancementNode f_291660_;
    private final DisplayInfo f_97131_;
    private final ItemStack f_97132_;
    private final Component f_97133_;
    private final AdvancementWidget f_97134_;
    private final Map<AdvancementHolder, AdvancementWidget> f_97135_ = Maps.newLinkedHashMap();
    private double f_97136_;
    private double f_97137_;
    private int f_97138_ = Integer.MAX_VALUE;
    private int f_97139_ = Integer.MAX_VALUE;
    private int f_97140_ = Integer.MIN_VALUE;
    private int f_97141_ = Integer.MIN_VALUE;
    private float f_97142_;
    private boolean f_97143_;

    public AdvancementTab(
        Minecraft p_97145_, AdvancementsScreen p_97146_, AdvancementTabType p_97147_, int p_97148_, AdvancementNode p_297568_, DisplayInfo p_97150_
    ) {
        this.f_97126_ = p_97145_;
        this.f_97127_ = p_97146_;
        this.f_97128_ = p_97147_;
        this.f_97129_ = p_97148_;
        this.f_291660_ = p_297568_;
        this.f_97131_ = p_97150_;
        this.f_97132_ = p_97150_.m_14990_();
        this.f_97133_ = p_97150_.m_14977_();
        this.f_97134_ = new AdvancementWidget(this, p_97145_, p_297568_, p_97150_);
        this.m_97175_(this.f_97134_, p_297568_.m_295246_());
    }

    public AdvancementTabType m_169538_() {
        return this.f_97128_;
    }

    public int m_169539_() {
        return this.f_97129_;
    }

    public AdvancementNode m_293004_() {
        return this.f_291660_;
    }

    public Component m_97189_() {
        return this.f_97133_;
    }

    public DisplayInfo m_169540_() {
        return this.f_97131_;
    }

    public void m_280105_(GuiGraphics p_282671_, int p_282721_, int p_282964_, boolean p_283052_) {
        this.f_97128_.m_280111_(p_282671_, p_282721_, p_282964_, p_283052_, this.f_97129_);
    }

    public void m_280485_(GuiGraphics p_282895_, int p_283419_, int p_283293_) {
        this.f_97128_.m_280639_(p_282895_, p_283419_, p_283293_, this.f_97129_, this.f_97132_);
    }

    public void m_280047_(GuiGraphics p_282728_, int p_282962_, int p_281511_) {
        if (!this.f_97143_) {
            this.f_97136_ = (double)(117 - (this.f_97140_ + this.f_97138_) / 2);
            this.f_97137_ = (double)(56 - (this.f_97141_ + this.f_97139_) / 2);
            this.f_97143_ = true;
        }

        p_282728_.m_280588_(p_282962_, p_281511_, p_282962_ + 234, p_281511_ + 113);
        p_282728_.m_280168_().m_85836_();
        p_282728_.m_280168_().m_252880_((float)p_282962_, (float)p_281511_, 0.0F);
        ResourceLocation resourcelocation = this.f_97131_.m_14991_().orElse(TextureManager.f_118466_);
        int i = Mth.m_14107_(this.f_97136_);
        int j = Mth.m_14107_(this.f_97137_);
        int k = i % 16;
        int l = j % 16;

        for (int i1 = -1; i1 <= 15; i1++) {
            for (int j1 = -1; j1 <= 8; j1++) {
                p_282728_.m_280159_(RenderType::m_355513_, resourcelocation, k + 16 * i1, l + 16 * j1, 0.0F, 0.0F, 16, 16, 16, 16);
            }
        }

        this.f_97134_.m_97298_(p_282728_, i, j, true);
        this.f_97134_.m_97298_(p_282728_, i, j, false);
        this.f_97134_.m_280229_(p_282728_, i, j);
        p_282728_.m_280168_().m_85849_();
        p_282728_.m_280618_();
    }

    public void m_280571_(GuiGraphics p_282892_, int p_283658_, int p_282602_, int p_282652_, int p_283595_) {
        p_282892_.m_280168_().m_85836_();
        p_282892_.m_280168_().m_252880_(0.0F, 0.0F, -200.0F);
        p_282892_.m_280509_(0, 0, 234, 113, Mth.m_14143_(this.f_97142_ * 255.0F) << 24);
        boolean flag = false;
        int i = Mth.m_14107_(this.f_97136_);
        int j = Mth.m_14107_(this.f_97137_);
        if (p_283658_ > 0 && p_283658_ < 234 && p_282602_ > 0 && p_282602_ < 113) {
            for (AdvancementWidget advancementwidget : this.f_97135_.values()) {
                if (advancementwidget.m_97259_(i, j, p_283658_, p_282602_)) {
                    flag = true;
                    advancementwidget.m_280255_(p_282892_, i, j, this.f_97142_, p_282652_, p_283595_);
                    break;
                }
            }
        }

        p_282892_.m_280168_().m_85849_();
        if (flag) {
            this.f_97142_ = Mth.m_14036_(this.f_97142_ + 0.02F, 0.0F, 0.3F);
        } else {
            this.f_97142_ = Mth.m_14036_(this.f_97142_ - 0.04F, 0.0F, 1.0F);
        }
    }

    public boolean m_97154_(int p_97155_, int p_97156_, double p_97157_, double p_97158_) {
        return this.f_97128_.m_97213_(p_97155_, p_97156_, this.f_97129_, p_97157_, p_97158_);
    }

    @Nullable
    public static AdvancementTab m_97170_(Minecraft p_97171_, AdvancementsScreen p_97172_, int p_97173_, AdvancementNode p_299876_) {
        Optional<DisplayInfo> optional = p_299876_.m_293739_().f_138299_();
        if (optional.isEmpty()) {
            return null;
        } else {
            for (AdvancementTabType advancementtabtype : AdvancementTabType.values()) {
                if (p_97173_ < advancementtabtype.m_97210_()) {
                    return new AdvancementTab(p_97171_, p_97172_, advancementtabtype, p_97173_, p_299876_, optional.get());
                }

                p_97173_ -= advancementtabtype.m_97210_();
            }

            return null;
        }
    }

    public void m_97151_(double p_97152_, double p_97153_) {
        if (this.f_97140_ - this.f_97138_ > 234) {
            this.f_97136_ = Mth.m_14008_(this.f_97136_ + p_97152_, (double)(-(this.f_97140_ - 234)), 0.0);
        }

        if (this.f_97141_ - this.f_97139_ > 113) {
            this.f_97137_ = Mth.m_14008_(this.f_97137_ + p_97153_, (double)(-(this.f_97141_ - 113)), 0.0);
        }
    }

    public void m_97178_(AdvancementNode p_297831_) {
        Optional<DisplayInfo> optional = p_297831_.m_293739_().f_138299_();
        if (!optional.isEmpty()) {
            AdvancementWidget advancementwidget = new AdvancementWidget(this, this.f_97126_, p_297831_, optional.get());
            this.m_97175_(advancementwidget, p_297831_.m_295246_());
        }
    }

    private void m_97175_(AdvancementWidget p_97176_, AdvancementHolder p_298201_) {
        this.f_97135_.put(p_298201_, p_97176_);
        int i = p_97176_.m_97315_();
        int j = i + 28;
        int k = p_97176_.m_97314_();
        int l = k + 27;
        this.f_97138_ = Math.min(this.f_97138_, i);
        this.f_97140_ = Math.max(this.f_97140_, j);
        this.f_97139_ = Math.min(this.f_97139_, k);
        this.f_97141_ = Math.max(this.f_97141_, l);

        for (AdvancementWidget advancementwidget : this.f_97135_.values()) {
            advancementwidget.m_97313_();
        }
    }

    @Nullable
    public AdvancementWidget m_97180_(AdvancementHolder p_300472_) {
        return this.f_97135_.get(p_300472_);
    }

    public AdvancementsScreen m_97190_() {
        return this.f_97127_;
    }
}