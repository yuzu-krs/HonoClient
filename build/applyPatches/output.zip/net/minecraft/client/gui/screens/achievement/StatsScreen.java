package net.minecraft.client.gui.screens.achievement;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.LoadingDotsWidget;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.stats.Stat;
import net.minecraft.stats.StatType;
import net.minecraft.stats.Stats;
import net.minecraft.stats.StatsCounter;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class StatsScreen extends Screen {
    private static final Component f_315509_ = Component.m_237115_("gui.stats");
    static final ResourceLocation f_290494_ = ResourceLocation.m_340282_("container/slot");
    static final ResourceLocation f_290590_ = ResourceLocation.m_340282_("statistics/header");
    static final ResourceLocation f_290511_ = ResourceLocation.m_340282_("statistics/sort_up");
    static final ResourceLocation f_290818_ = ResourceLocation.m_340282_("statistics/sort_down");
    private static final Component f_96897_ = Component.m_237115_("multiplayer.downloadingStats");
    static final Component f_291420_ = Component.m_237115_("stats.none");
    private static final Component f_315469_ = Component.m_237115_("stat.generalButton");
    private static final Component f_314112_ = Component.m_237115_("stat.itemsButton");
    private static final Component f_316096_ = Component.m_237115_("stat.mobsButton");
    protected final Screen f_96896_;
    private static final int f_316161_ = 280;
    private static final int f_314495_ = 5;
    private static final int f_315533_ = 58;
    private HeaderAndFooterLayout f_314249_ = new HeaderAndFooterLayout(this, 33, 58);
    @Nullable
    private StatsScreen.GeneralStatisticsList f_96898_;
    @Nullable
    StatsScreen.ItemStatisticsList f_96899_;
    @Nullable
    private StatsScreen.MobsStatisticsList f_96900_;
    final StatsCounter f_96901_;
    @Nullable
    private ObjectSelectionList<?> f_96902_;
    private boolean f_96903_ = true;

    public StatsScreen(Screen p_96906_, StatsCounter p_96907_) {
        super(f_315509_);
        this.f_96896_ = p_96906_;
        this.f_96901_ = p_96907_;
    }

    @Override
    protected void m_7856_() {
        this.f_314249_.m_268999_(new LoadingDotsWidget(this.f_96547_, f_96897_));
        this.f_96541_.m_91403_().m_295327_(new ServerboundClientCommandPacket(ServerboundClientCommandPacket.Action.REQUEST_STATS));
    }

    public void m_96972_() {
        this.f_96898_ = new StatsScreen.GeneralStatisticsList(this.f_96541_);
        this.f_96899_ = new StatsScreen.ItemStatisticsList(this.f_96541_);
        this.f_96900_ = new StatsScreen.MobsStatisticsList(this.f_96541_);
    }

    public void m_96975_() {
        HeaderAndFooterLayout headerandfooterlayout = new HeaderAndFooterLayout(this, 33, 58);
        headerandfooterlayout.m_324480_(f_315509_, this.f_96547_);
        LinearLayout linearlayout = headerandfooterlayout.m_269281_(LinearLayout.m_293633_()).m_294554_(5);
        linearlayout.m_294823_().m_264356_();
        LinearLayout linearlayout1 = linearlayout.m_264406_(LinearLayout.m_295847_()).m_294554_(5);
        linearlayout1.m_264406_(Button.m_253074_(f_315469_, p_96963_ -> this.m_96924_(this.f_96898_)).m_252780_(120).m_253136_());
        Button button = linearlayout1.m_264406_(Button.m_253074_(f_314112_, p_96959_ -> this.m_96924_(this.f_96899_)).m_252780_(120).m_253136_());
        Button button1 = linearlayout1.m_264406_(Button.m_253074_(f_316096_, p_96949_ -> this.m_96924_(this.f_96900_)).m_252780_(120).m_253136_());
        linearlayout.m_264406_(Button.m_253074_(CommonComponents.f_130655_, p_325372_ -> this.m_7379_()).m_252780_(200).m_253136_());
        if (this.f_96899_ != null && this.f_96899_.m_6702_().isEmpty()) {
            button.f_93623_ = false;
        }

        if (this.f_96900_ != null && this.f_96900_.m_6702_().isEmpty()) {
            button1.f_93623_ = false;
        }

        this.f_314249_ = headerandfooterlayout;
        this.f_314249_.m_264134_(p_325374_ -> {
            AbstractWidget abstractwidget = this.m_142416_(p_325374_);
        });
        this.m_267719_();
    }

    @Override
    protected void m_267719_() {
        this.f_314249_.m_264036_();
        if (this.f_96902_ != null) {
            this.f_96902_.m_319425_(this.f_96543_, this.f_314249_);
        }
    }

    @Override
    public void m_7379_() {
        this.f_96541_.m_91152_(this.f_96896_);
    }

    public void m_96980_() {
        if (this.f_96903_) {
            this.m_96972_();
            this.m_96924_(this.f_96898_);
            this.m_96975_();
            this.m_318615_();
            this.f_96903_ = false;
        }
    }

    @Override
    public boolean m_7043_() {
        return !this.f_96903_;
    }

    public void m_96924_(@Nullable ObjectSelectionList<?> p_96925_) {
        if (this.f_96902_ != null) {
            this.m_169411_(this.f_96902_);
        }

        if (p_96925_ != null) {
            this.m_142416_(p_96925_);
            this.f_96902_ = p_96925_;
            this.m_267719_();
        }
    }

    static String m_96946_(Stat<ResourceLocation> p_96947_) {
        return "stat." + p_96947_.m_12867_().toString().replace(':', '.');
    }

    @OnlyIn(Dist.CLIENT)
    class GeneralStatisticsList extends ObjectSelectionList<StatsScreen.GeneralStatisticsList.Entry> {
        public GeneralStatisticsList(final Minecraft p_96995_) {
            super(p_96995_, StatsScreen.this.f_96543_, StatsScreen.this.f_96544_ - 33 - 58, 33, 14);
            ObjectArrayList<Stat<ResourceLocation>> objectarraylist = new ObjectArrayList<>(Stats.f_12988_.iterator());
            objectarraylist.sort(Comparator.comparing(p_96997_ -> I18n.m_118938_(StatsScreen.m_96946_((Stat<ResourceLocation>)p_96997_))));

            for (Stat<ResourceLocation> stat : objectarraylist) {
                this.m_7085_(new StatsScreen.GeneralStatisticsList.Entry(stat));
            }
        }

        @Override
        public int m_5759_() {
            return 280;
        }

        @OnlyIn(Dist.CLIENT)
        class Entry extends ObjectSelectionList.Entry<StatsScreen.GeneralStatisticsList.Entry> {
            private final Stat<ResourceLocation> f_97001_;
            private final Component f_97002_;

            Entry(final Stat<ResourceLocation> p_97005_) {
                this.f_97001_ = p_97005_;
                this.f_97002_ = Component.m_237115_(StatsScreen.m_96946_(p_97005_));
            }

            private String m_169513_() {
                return this.f_97001_.m_12860_(StatsScreen.this.f_96901_.m_13015_(this.f_97001_));
            }

            @Override
            public void m_6311_(
                GuiGraphics p_283043_,
                int p_97012_,
                int p_97013_,
                int p_97014_,
                int p_97015_,
                int p_97016_,
                int p_97017_,
                int p_97018_,
                boolean p_97019_,
                float p_97020_
            ) {
                int i = p_97013_ + p_97016_ / 2 - 9 / 2;
                int j = p_97012_ % 2 == 0 ? -1 : -4539718;
                p_283043_.m_280430_(StatsScreen.this.f_96547_, this.f_97002_, p_97014_ + 2, i, j);
                String s = this.m_169513_();
                p_283043_.m_280488_(StatsScreen.this.f_96547_, s, p_97014_ + p_97015_ - StatsScreen.this.f_96547_.m_92895_(s) - 4, i, j);
            }

            @Override
            public Component m_142172_() {
                return Component.m_237110_(
                    "narrator.select", Component.m_237119_().m_7220_(this.f_97002_).m_7220_(CommonComponents.f_263701_).m_130946_(this.m_169513_())
                );
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    class ItemStatisticsList extends ObjectSelectionList<StatsScreen.ItemStatisticsList.ItemRow> {
        private static final int f_317021_ = 18;
        private static final int f_316087_ = 22;
        private static final int f_316064_ = 1;
        private static final int f_314657_ = 0;
        private static final int f_315968_ = -1;
        private static final int f_316525_ = 1;
        private final ResourceLocation[] f_291724_ = new ResourceLocation[]{
            ResourceLocation.m_340282_("statistics/block_mined"),
            ResourceLocation.m_340282_("statistics/item_broken"),
            ResourceLocation.m_340282_("statistics/item_crafted"),
            ResourceLocation.m_340282_("statistics/item_used"),
            ResourceLocation.m_340282_("statistics/item_picked_up"),
            ResourceLocation.m_340282_("statistics/item_dropped")
        };
        protected final List<StatType<Block>> f_97021_;
        protected final List<StatType<Item>> f_97022_;
        protected final Comparator<StatsScreen.ItemStatisticsList.ItemRow> f_97025_ = new StatsScreen.ItemStatisticsList.ItemRowComparator();
        @Nullable
        protected StatType<?> f_97026_;
        protected int f_97023_ = -1;
        protected int f_97027_;

        public ItemStatisticsList(final Minecraft p_97032_) {
            super(p_97032_, StatsScreen.this.f_96543_, StatsScreen.this.f_96544_ - 33 - 58, 33, 22);
            this.f_97021_ = Lists.newArrayList();
            this.f_97021_.add(Stats.f_12949_);
            this.f_97022_ = Lists.newArrayList(Stats.f_12983_, Stats.f_12981_, Stats.f_12982_, Stats.f_12984_, Stats.f_12985_);
            this.m_93473_(true, 22);
            Set<Item> set = Sets.newIdentityHashSet();

            for (Item item : BuiltInRegistries.f_257033_) {
                boolean flag = false;

                for (StatType<Item> stattype : this.f_97022_) {
                    if (stattype.m_12897_(item) && StatsScreen.this.f_96901_.m_13015_(stattype.m_12902_(item)) > 0) {
                        flag = true;
                    }
                }

                if (flag) {
                    set.add(item);
                }
            }

            for (Block block : BuiltInRegistries.f_256975_) {
                boolean flag1 = false;

                for (StatType<Block> stattype1 : this.f_97021_) {
                    if (stattype1.m_12897_(block) && StatsScreen.this.f_96901_.m_13015_(stattype1.m_12902_(block)) > 0) {
                        flag1 = true;
                    }
                }

                if (flag1) {
                    set.add(block.m_5456_());
                }
            }

            set.remove(Items.f_41852_);

            for (Item item1 : set) {
                this.m_7085_(new StatsScreen.ItemStatisticsList.ItemRow(item1));
            }
        }

        int m_320127_(int p_329609_) {
            return 75 + 40 * p_329609_;
        }

        @Override
        protected void m_7415_(GuiGraphics p_282214_, int p_97050_, int p_97051_) {
            if (!this.f_93386_.f_91067_.m_91560_()) {
                this.f_97023_ = -1;
            }

            for (int i = 0; i < this.f_291724_.length; i++) {
                ResourceLocation resourcelocation = this.f_97023_ == i ? StatsScreen.f_290494_ : StatsScreen.f_290590_;
                p_282214_.m_294122_(RenderType::m_355513_, resourcelocation, p_97050_ + this.m_320127_(i) - 18, p_97051_ + 1, 18, 18);
            }

            if (this.f_97026_ != null) {
                int j = this.m_320127_(this.m_97058_(this.f_97026_)) - 36;
                ResourceLocation resourcelocation1 = this.f_97027_ == 1 ? StatsScreen.f_290511_ : StatsScreen.f_290818_;
                p_282214_.m_294122_(RenderType::m_355513_, resourcelocation1, p_97050_ + j, p_97051_ + 1, 18, 18);
            }

            for (int k = 0; k < this.f_291724_.length; k++) {
                int l = this.f_97023_ == k ? 1 : 0;
                p_282214_.m_294122_(RenderType::m_355513_, this.f_291724_[k], p_97050_ + this.m_320127_(k) - 18 + l, p_97051_ + 1 + l, 18, 18);
            }
        }

        @Override
        public int m_5759_() {
            return 280;
        }

        @Override
        protected boolean m_6205_(int p_97036_, int p_97037_) {
            this.f_97023_ = -1;

            for (int i = 0; i < this.f_291724_.length; i++) {
                int j = p_97036_ - this.m_320127_(i);
                if (j >= -36 && j <= 0) {
                    this.f_97023_ = i;
                    break;
                }
            }

            if (this.f_97023_ >= 0) {
                this.m_97038_(this.m_97033_(this.f_97023_));
                this.f_93386_.m_91106_().m_120367_(SimpleSoundInstance.m_263171_(SoundEvents.f_12490_, 1.0F));
                return true;
            } else {
                return super.m_6205_(p_97036_, p_97037_);
            }
        }

        private StatType<?> m_97033_(int p_97034_) {
            return p_97034_ < this.f_97021_.size() ? this.f_97021_.get(p_97034_) : this.f_97022_.get(p_97034_ - this.f_97021_.size());
        }

        private int m_97058_(StatType<?> p_97059_) {
            int i = this.f_97021_.indexOf(p_97059_);
            if (i >= 0) {
                return i;
            } else {
                int j = this.f_97022_.indexOf(p_97059_);
                return j >= 0 ? j + this.f_97021_.size() : -1;
            }
        }

        @Override
        protected void m_7154_(GuiGraphics p_283203_, int p_97046_, int p_97047_) {
            if (p_97047_ >= this.m_252907_() && p_97047_ <= this.m_306468_()) {
                StatsScreen.ItemStatisticsList.ItemRow statsscreen$itemstatisticslist$itemrow = this.m_168795_();
                int i = this.m_5747_();
                if (statsscreen$itemstatisticslist$itemrow != null) {
                    if (p_97046_ < i || p_97046_ > i + 18) {
                        return;
                    }

                    Item item = statsscreen$itemstatisticslist$itemrow.m_169519_();
                    p_283203_.m_354936_(StatsScreen.this.f_96547_, item.m_352178_(), p_97046_, p_97047_, item.m_320917_().m_318834_(DataComponents.f_348750_));
                } else {
                    Component component = null;
                    int j = p_97046_ - i;

                    for (int k = 0; k < this.f_291724_.length; k++) {
                        int l = this.m_320127_(k);
                        if (j >= l - 18 && j <= l) {
                            component = this.m_97033_(k).m_12905_();
                            break;
                        }
                    }

                    if (component != null) {
                        p_283203_.m_280557_(StatsScreen.this.f_96547_, component, p_97046_, p_97047_);
                    }
                }
            }
        }

        protected void m_97038_(StatType<?> p_97039_) {
            if (p_97039_ != this.f_97026_) {
                this.f_97026_ = p_97039_;
                this.f_97027_ = -1;
            } else if (this.f_97027_ == -1) {
                this.f_97027_ = 1;
            } else {
                this.f_97026_ = null;
                this.f_97027_ = 0;
            }

            this.m_6702_().sort(this.f_97025_);
        }

        @OnlyIn(Dist.CLIENT)
        class ItemRow extends ObjectSelectionList.Entry<StatsScreen.ItemStatisticsList.ItemRow> {
            private final Item f_169514_;

            ItemRow(final Item p_169517_) {
                this.f_169514_ = p_169517_;
            }

            public Item m_169519_() {
                return this.f_169514_;
            }

            @Override
            public void m_6311_(
                GuiGraphics p_283614_,
                int p_97082_,
                int p_97083_,
                int p_97084_,
                int p_97085_,
                int p_97086_,
                int p_97087_,
                int p_97088_,
                boolean p_97089_,
                float p_97090_
            ) {
                p_283614_.m_294122_(RenderType::m_355513_, StatsScreen.f_290494_, p_97084_, p_97083_, 18, 18);
                p_283614_.m_280203_(this.f_169514_.m_7968_(), p_97084_ + 1, p_97083_ + 1);
                if (StatsScreen.this.f_96899_ != null) {
                    for (int i = 0; i < StatsScreen.this.f_96899_.f_97021_.size(); i++) {
                        Stat<Block> stat;
                        if (this.f_169514_ instanceof BlockItem blockitem) {
                            stat = StatsScreen.this.f_96899_.f_97021_.get(i).m_12902_(blockitem.m_40614_());
                        } else {
                            stat = null;
                        }

                        this.m_97091_(p_283614_, stat, p_97084_ + ItemStatisticsList.this.m_320127_(i), p_97083_ + p_97086_ / 2 - 9 / 2, p_97082_ % 2 == 0);
                    }

                    for (int j = 0; j < StatsScreen.this.f_96899_.f_97022_.size(); j++) {
                        this.m_97091_(
                            p_283614_,
                            StatsScreen.this.f_96899_.f_97022_.get(j).m_12902_(this.f_169514_),
                            p_97084_ + ItemStatisticsList.this.m_320127_(j + StatsScreen.this.f_96899_.f_97021_.size()),
                            p_97083_ + p_97086_ / 2 - 9 / 2,
                            p_97082_ % 2 == 0
                        );
                    }
                }
            }

            protected void m_97091_(GuiGraphics p_282544_, @Nullable Stat<?> p_97093_, int p_97094_, int p_97095_, boolean p_97096_) {
                Component component = (Component)(p_97093_ == null
                    ? StatsScreen.f_291420_
                    : Component.m_237113_(p_97093_.m_12860_(StatsScreen.this.f_96901_.m_13015_(p_97093_))));
                p_282544_.m_280430_(
                    StatsScreen.this.f_96547_, component, p_97094_ - StatsScreen.this.f_96547_.m_92852_(component), p_97095_, p_97096_ ? -1 : -4539718
                );
            }

            @Override
            public Component m_142172_() {
                return Component.m_237110_("narrator.select", this.f_169514_.m_352178_());
            }
        }

        @OnlyIn(Dist.CLIENT)
        class ItemRowComparator implements Comparator<StatsScreen.ItemStatisticsList.ItemRow> {
            public int compare(StatsScreen.ItemStatisticsList.ItemRow p_169524_, StatsScreen.ItemStatisticsList.ItemRow p_169525_) {
                Item item = p_169524_.m_169519_();
                Item item1 = p_169525_.m_169519_();
                int i;
                int j;
                if (ItemStatisticsList.this.f_97026_ == null) {
                    i = 0;
                    j = 0;
                } else if (ItemStatisticsList.this.f_97021_.contains(ItemStatisticsList.this.f_97026_)) {
                    StatType<Block> stattype = (StatType<Block>)ItemStatisticsList.this.f_97026_;
                    i = item instanceof BlockItem ? StatsScreen.this.f_96901_.m_13017_(stattype, ((BlockItem)item).m_40614_()) : -1;
                    j = item1 instanceof BlockItem ? StatsScreen.this.f_96901_.m_13017_(stattype, ((BlockItem)item1).m_40614_()) : -1;
                } else {
                    StatType<Item> stattype1 = (StatType<Item>)ItemStatisticsList.this.f_97026_;
                    i = StatsScreen.this.f_96901_.m_13017_(stattype1, item);
                    j = StatsScreen.this.f_96901_.m_13017_(stattype1, item1);
                }

                return i == j
                    ? ItemStatisticsList.this.f_97027_ * Integer.compare(Item.m_41393_(item), Item.m_41393_(item1))
                    : ItemStatisticsList.this.f_97027_ * Integer.compare(i, j);
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    class MobsStatisticsList extends ObjectSelectionList<StatsScreen.MobsStatisticsList.MobRow> {
        public MobsStatisticsList(final Minecraft p_97100_) {
            super(p_97100_, StatsScreen.this.f_96543_, StatsScreen.this.f_96544_ - 33 - 58, 33, 9 * 4);

            for (EntityType<?> entitytype : BuiltInRegistries.f_256780_) {
                if (StatsScreen.this.f_96901_.m_13015_(Stats.f_12986_.m_12902_(entitytype)) > 0
                    || StatsScreen.this.f_96901_.m_13015_(Stats.f_12987_.m_12902_(entitytype)) > 0) {
                    this.m_7085_(new StatsScreen.MobsStatisticsList.MobRow(entitytype));
                }
            }
        }

        @Override
        public int m_5759_() {
            return 280;
        }

        @OnlyIn(Dist.CLIENT)
        class MobRow extends ObjectSelectionList.Entry<StatsScreen.MobsStatisticsList.MobRow> {
            private final Component f_97105_;
            private final Component f_97106_;
            private final Component f_97108_;
            private final boolean f_97107_;
            private final boolean f_97109_;

            public MobRow(final EntityType<?> p_97112_) {
                this.f_97105_ = p_97112_.m_20676_();
                int i = StatsScreen.this.f_96901_.m_13015_(Stats.f_12986_.m_12902_(p_97112_));
                if (i == 0) {
                    this.f_97106_ = Component.m_237110_("stat_type.minecraft.killed.none", this.f_97105_);
                    this.f_97107_ = false;
                } else {
                    this.f_97106_ = Component.m_237110_("stat_type.minecraft.killed", i, this.f_97105_);
                    this.f_97107_ = true;
                }

                int j = StatsScreen.this.f_96901_.m_13015_(Stats.f_12987_.m_12902_(p_97112_));
                if (j == 0) {
                    this.f_97108_ = Component.m_237110_("stat_type.minecraft.killed_by.none", this.f_97105_);
                    this.f_97109_ = false;
                } else {
                    this.f_97108_ = Component.m_237110_("stat_type.minecraft.killed_by", this.f_97105_, j);
                    this.f_97109_ = true;
                }
            }

            @Override
            public void m_6311_(
                GuiGraphics p_283265_,
                int p_97115_,
                int p_97116_,
                int p_97117_,
                int p_97118_,
                int p_97119_,
                int p_97120_,
                int p_97121_,
                boolean p_97122_,
                float p_97123_
            ) {
                p_283265_.m_280430_(StatsScreen.this.f_96547_, this.f_97105_, p_97117_ + 2, p_97116_ + 1, -1);
                p_283265_.m_280430_(StatsScreen.this.f_96547_, this.f_97106_, p_97117_ + 2 + 10, p_97116_ + 1 + 9, this.f_97107_ ? -4539718 : -8355712);
                p_283265_.m_280430_(StatsScreen.this.f_96547_, this.f_97108_, p_97117_ + 2 + 10, p_97116_ + 1 + 9 * 2, this.f_97109_ ? -4539718 : -8355712);
            }

            @Override
            public Component m_142172_() {
                return Component.m_237110_("narrator.select", CommonComponents.m_267603_(this.f_97106_, this.f_97108_));
            }
        }
    }
}