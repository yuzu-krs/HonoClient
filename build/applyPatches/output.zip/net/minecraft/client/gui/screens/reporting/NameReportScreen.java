package net.minecraft.client.gui.screens.reporting;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.layouts.CommonLayouts;
import net.minecraft.client.gui.layouts.LayoutSettings;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.chat.report.NameReport;
import net.minecraft.client.multiplayer.chat.report.ReportingContext;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class NameReportScreen extends AbstractReportScreen<NameReport.Builder> {
    private static final Component f_290359_ = Component.m_237115_("gui.abuseReport.name.title");
    private static final Component f_347657_ = Component.m_237115_("gui.abuseReport.name.comment_box_label");
    @Nullable
    private MultiLineEditBox f_290978_;

    private NameReportScreen(Screen p_300534_, ReportingContext p_300915_, NameReport.Builder p_300014_) {
        super(f_290359_, p_300534_, p_300915_, p_300014_);
    }

    public NameReportScreen(Screen p_300152_, ReportingContext p_300083_, UUID p_298096_, String p_300249_) {
        this(p_300152_, p_300083_, new NameReport.Builder(p_298096_, p_300249_, p_300083_.m_240161_().m_239479_()));
    }

    public NameReportScreen(Screen p_300445_, ReportingContext p_299367_, NameReport p_297896_) {
        this(p_300445_, p_299367_, new NameReport.Builder(p_297896_, p_299367_.m_240161_().m_239479_()));
    }

    @Override
    protected void m_338957_() {
        Component component = Component.m_237113_(this.f_291568_.m_292899_().m_294329_()).m_130940_(ChatFormatting.YELLOW);
        this.f_336805_
            .m_293842_(
                new StringWidget(Component.m_237110_("gui.abuseReport.name.reporting", component), this.f_96547_),
                p_357694_ -> p_357694_.m_264356_().m_264414_(0, 8)
            );
        this.f_290978_ = this.m_294932_(280, 9 * 8, p_357693_ -> {
            this.f_291568_.m_293258_(p_357693_);
            this.m_239041_();
        });
        this.f_336805_.m_264406_(CommonLayouts.m_293132_(this.f_96547_, this.f_290978_, f_347657_, p_299823_ -> p_299823_.m_264154_(12)));
    }

    @Override
    public boolean m_6348_(double p_297585_, double p_300170_, int p_297299_) {
        if (super.m_6348_(p_297585_, p_300170_, p_297299_)) {
            return true;
        } else {
            return this.f_290978_ != null ? this.f_290978_.m_6348_(p_297585_, p_300170_, p_297299_) : false;
        }
    }
}