package net.minecraft.client.gui.screens.options;

import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.navigation.CommonInputs;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.language.LanguageInfo;
import net.minecraft.client.resources.language.LanguageManager;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class LanguageSelectScreen extends OptionsSubScreen {
    private static final Component f_337597_ = Component.m_237115_("options.languageAccuracyWarning").m_306658_(-4539718);
    private static final int f_337208_ = 53;
    private LanguageSelectScreen.LanguageSelectionList f_337322_;
    final LanguageManager f_337434_;

    public LanguageSelectScreen(Screen p_344210_, Options p_342264_, LanguageManager p_343432_) {
        super(p_344210_, p_342264_, Component.m_237115_("options.language.title"));
        this.f_337434_ = p_343432_;
        this.f_337270_.m_269413_(53);
    }

    @Override
    protected void m_338632_() {
        this.f_337322_ = this.f_337270_.m_268999_(new LanguageSelectScreen.LanguageSelectionList(this.f_96541_));
    }

    @Override
    protected void m_338523_() {
    }

    @Override
    protected void m_339217_() {
        LinearLayout linearlayout = this.f_337270_.m_269281_(LinearLayout.m_293633_()).m_294554_(8);
        linearlayout.m_294823_().m_264356_();
        linearlayout.m_264406_(new StringWidget(f_337597_, this.f_96547_));
        LinearLayout linearlayout1 = linearlayout.m_264406_(LinearLayout.m_295847_().m_294554_(8));
        linearlayout1.m_264406_(
            Button.m_253074_(Component.m_237115_("options.font"), p_343010_ -> this.f_96541_.m_91152_(new FontOptionsScreen(this, this.f_337734_))).m_253136_()
        );
        linearlayout1.m_264406_(Button.m_253074_(CommonComponents.f_130655_, p_343186_ -> this.m_339000_()).m_253136_());
    }

    @Override
    protected void m_267719_() {
        super.m_267719_();
        this.f_337322_.m_319425_(this.f_96543_, this.f_337270_);
    }

    void m_339000_() {
        LanguageSelectScreen.LanguageSelectionList.Entry languageselectscreen$languageselectionlist$entry = this.f_337322_.m_93511_();
        if (languageselectscreen$languageselectionlist$entry != null
            && !languageselectscreen$languageselectionlist$entry.f_337298_.equals(this.f_337434_.m_264236_())) {
            this.f_337434_.m_264110_(languageselectscreen$languageselectionlist$entry.f_337298_);
            this.f_337734_.f_92075_ = languageselectscreen$languageselectionlist$entry.f_337298_;
            this.f_96541_.m_91391_();
        }

        this.f_96541_.m_91152_(this.f_337508_);
    }

    @OnlyIn(Dist.CLIENT)
    class LanguageSelectionList extends ObjectSelectionList<LanguageSelectScreen.LanguageSelectionList.Entry> {
        public LanguageSelectionList(final Minecraft p_343433_) {
            super(p_343433_, LanguageSelectScreen.this.f_96543_, LanguageSelectScreen.this.f_96544_ - 33 - 53, 33, 18);
            String s = LanguageSelectScreen.this.f_337434_.m_264236_();
            LanguageSelectScreen.this.f_337434_
                .m_264450_()
                .forEach(
                    (p_342614_, p_342581_) -> {
                        LanguageSelectScreen.LanguageSelectionList.Entry languageselectscreen$languageselectionlist$entry = new LanguageSelectScreen.LanguageSelectionList.Entry(
                            p_342614_, p_342581_
                        );
                        this.m_7085_(languageselectscreen$languageselectionlist$entry);
                        if (s.equals(p_342614_)) {
                            this.m_6987_(languageselectscreen$languageselectionlist$entry);
                        }
                    }
                );
            if (this.m_93511_() != null) {
                this.m_93494_(this.m_93511_());
            }
        }

        @Override
        public int m_5759_() {
            return super.m_5759_() + 50;
        }

        @OnlyIn(Dist.CLIENT)
        public class Entry extends ObjectSelectionList.Entry<LanguageSelectScreen.LanguageSelectionList.Entry> {
            final String f_337298_;
            private final Component f_336816_;
            private long f_337659_;

            public Entry(final String p_344457_, final LanguageInfo p_342261_) {
                this.f_337298_ = p_344457_;
                this.f_336816_ = p_342261_.m_264517_();
            }

            @Override
            public void m_6311_(
                GuiGraphics p_344847_,
                int p_342936_,
                int p_344271_,
                int p_343473_,
                int p_343669_,
                int p_343479_,
                int p_342702_,
                int p_343137_,
                boolean p_344510_,
                float p_345266_
            ) {
                p_344847_.m_280653_(
                    LanguageSelectScreen.this.f_96547_, this.f_336816_, LanguageSelectionList.this.f_93618_ / 2, p_344271_ + p_343479_ / 2 - 9 / 2, -1
                );
            }

            @Override
            public boolean m_7933_(int p_343262_, int p_344349_, int p_345020_) {
                if (CommonInputs.m_278691_(p_343262_)) {
                    this.m_340030_();
                    LanguageSelectScreen.this.m_339000_();
                    return true;
                } else {
                    return super.m_7933_(p_343262_, p_344349_, p_345020_);
                }
            }

            @Override
            public boolean m_6375_(double p_342624_, double p_342099_, int p_344982_) {
                this.m_340030_();
                if (Util.m_137550_() - this.f_337659_ < 250L) {
                    LanguageSelectScreen.this.m_339000_();
                }

                this.f_337659_ = Util.m_137550_();
                return super.m_6375_(p_342624_, p_342099_, p_344982_);
            }

            private void m_340030_() {
                LanguageSelectionList.this.m_6987_(this);
            }

            @Override
            public Component m_142172_() {
                return Component.m_237110_("narrator.select", this.f_336816_);
            }
        }
    }
}