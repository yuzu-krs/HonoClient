package net.minecraft.client.gui.screens.reporting;

import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.layouts.SpacerElement;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.social.PlayerEntry;
import net.minecraft.client.multiplayer.chat.report.ReportingContext;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ReportPlayerScreen extends Screen {
    private static final Component f_291176_ = Component.m_237115_("gui.abuseReport.title");
    private static final Component f_291817_ = Component.m_237115_("gui.abuseReport.message");
    private static final Component f_291608_ = Component.m_237115_("gui.abuseReport.type.chat");
    private static final Component f_291321_ = Component.m_237115_("gui.abuseReport.type.skin");
    private static final Component f_291064_ = Component.m_237115_("gui.abuseReport.type.name");
    private static final int f_291277_ = 6;
    private final Screen f_291648_;
    private final ReportingContext f_291107_;
    private final PlayerEntry f_290733_;
    private final LinearLayout f_291097_ = LinearLayout.m_293633_().m_294554_(6);

    public ReportPlayerScreen(Screen p_300148_, ReportingContext p_298995_, PlayerEntry p_300468_) {
        super(f_291176_);
        this.f_291648_ = p_300148_;
        this.f_291107_ = p_298995_;
        this.f_290733_ = p_300468_;
    }

    @Override
    public Component m_142562_() {
        return CommonComponents.m_267603_(super.m_142562_(), f_291817_);
    }

    @Override
    protected void m_7856_() {
        this.f_291097_.m_294823_().m_264356_();
        this.f_291097_.m_264512_(new StringWidget(this.f_96539_, this.f_96547_), this.f_291097_.m_293373_().m_264154_(6));
        this.f_291097_.m_264512_(new MultiLineTextWidget(f_291817_, this.f_96547_).m_269484_(true), this.f_291097_.m_293373_().m_264154_(6));
        Button button = this.f_291097_
            .m_264406_(
                Button.m_253074_(
                        f_291608_, p_297615_ -> this.f_96541_.m_91152_(new ChatReportScreen(this.f_291648_, this.f_291107_, this.f_290733_.m_100618_()))
                    )
                    .m_253136_()
            );
        if (!this.f_290733_.m_295583_()) {
            button.f_93623_ = false;
            button.m_257544_(Tooltip.m_257550_(Component.m_237115_("gui.socialInteractions.tooltip.report.not_reportable")));
        } else if (!this.f_290733_.m_240694_()) {
            button.f_93623_ = false;
            button.m_257544_(Tooltip.m_257550_(Component.m_237110_("gui.socialInteractions.tooltip.report.no_messages", this.f_290733_.m_100600_())));
        }

        this.f_291097_
            .m_264406_(
                Button.m_253074_(
                        f_291321_,
                        p_299324_ -> this.f_96541_
                                .m_91152_(new SkinReportScreen(this.f_291648_, this.f_291107_, this.f_290733_.m_100618_(), this.f_290733_.m_293311_()))
                    )
                    .m_253136_()
            );
        this.f_291097_
            .m_264406_(
                Button.m_253074_(
                        f_291064_,
                        p_298210_ -> this.f_96541_
                                .m_91152_(new NameReportScreen(this.f_291648_, this.f_291107_, this.f_290733_.m_100618_(), this.f_290733_.m_100600_()))
                    )
                    .m_253136_()
            );
        this.f_291097_.m_264406_(SpacerElement.m_264252_(20));
        this.f_291097_.m_264406_(Button.m_253074_(CommonComponents.f_130656_, p_299500_ -> this.m_7379_()).m_253136_());
        this.f_291097_.m_264134_(p_325402_ -> {
            AbstractWidget abstractwidget = this.m_142416_(p_325402_);
        });
        this.m_267719_();
    }

    @Override
    protected void m_267719_() {
        this.f_291097_.m_264036_();
        FrameLayout.m_267781_(this.f_291097_, this.m_264198_());
    }

    @Override
    public void m_7379_() {
        this.f_96541_.m_91152_(this.f_291648_);
    }
}