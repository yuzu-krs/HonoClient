package net.minecraft.client.gui.screens.advancements;

import net.minecraft.advancements.AdvancementType;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public enum AdvancementWidgetType {
    OBTAINED(
        ResourceLocation.m_340282_("advancements/box_obtained"),
        ResourceLocation.m_340282_("advancements/task_frame_obtained"),
        ResourceLocation.m_340282_("advancements/challenge_frame_obtained"),
        ResourceLocation.m_340282_("advancements/goal_frame_obtained")
    ),
    UNOBTAINED(
        ResourceLocation.m_340282_("advancements/box_unobtained"),
        ResourceLocation.m_340282_("advancements/task_frame_unobtained"),
        ResourceLocation.m_340282_("advancements/challenge_frame_unobtained"),
        ResourceLocation.m_340282_("advancements/goal_frame_unobtained")
    );

    private final ResourceLocation f_291296_;
    private final ResourceLocation f_291162_;
    private final ResourceLocation f_290574_;
    private final ResourceLocation f_291398_;

    private AdvancementWidgetType(
        final ResourceLocation p_300112_, final ResourceLocation p_300140_, final ResourceLocation p_299008_, final ResourceLocation p_301311_
    ) {
        this.f_291296_ = p_300112_;
        this.f_291162_ = p_300140_;
        this.f_290574_ = p_299008_;
        this.f_291398_ = p_301311_;
    }

    public ResourceLocation m_294185_() {
        return this.f_291296_;
    }

    public ResourceLocation m_293359_(AdvancementType p_311711_) {
        return switch (p_311711_) {
            case TASK -> this.f_291162_;
            case CHALLENGE -> this.f_290574_;
            case GOAL -> this.f_291398_;
        };
    }
}