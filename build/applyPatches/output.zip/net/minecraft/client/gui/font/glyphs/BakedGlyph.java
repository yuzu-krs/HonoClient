package net.minecraft.client.gui.font.glyphs;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.font.GlyphRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Style;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(Dist.CLIENT)
public class BakedGlyph {
    private final GlyphRenderTypes f_283799_;
    private final float f_95201_;
    private final float f_95202_;
    private final float f_95203_;
    private final float f_95204_;
    private final float f_95205_;
    private final float f_95206_;
    private final float f_95207_;
    private final float f_95208_;

    public BakedGlyph(
        GlyphRenderTypes p_285527_,
        float p_285271_,
        float p_284970_,
        float p_285098_,
        float p_285023_,
        float p_285242_,
        float p_285043_,
        float p_285100_,
        float p_284948_
    ) {
        this.f_283799_ = p_285527_;
        this.f_95201_ = p_285271_;
        this.f_95202_ = p_284970_;
        this.f_95203_ = p_285098_;
        this.f_95204_ = p_285023_;
        this.f_95205_ = p_285242_;
        this.f_95206_ = p_285043_;
        this.f_95207_ = p_285100_;
        this.f_95208_ = p_284948_;
    }

    public void m_95277_(BakedGlyph.GlyphInstance p_368554_, Matrix4f p_365625_, VertexConsumer p_370130_, int p_369456_) {
        Style style = p_368554_.f_348676_();
        boolean flag = style.m_131161_();
        float f = p_368554_.f_347659_();
        float f1 = p_368554_.f_346777_();
        int i = p_368554_.f_346842_();
        this.m_5626_(flag, f, f1, p_365625_, p_370130_, i, p_369456_);
        if (style.m_131154_()) {
            this.m_5626_(flag, f + p_368554_.f_346601_(), f1, p_365625_, p_370130_, i, p_369456_);
        }
    }

    private void m_5626_(boolean p_95227_, float p_95228_, float p_95229_, Matrix4f p_253706_, VertexConsumer p_95231_, int p_95236_, int p_365126_) {
        float f = p_95228_ + this.f_95205_;
        float f1 = p_95228_ + this.f_95206_;
        float f2 = p_95229_ + this.f_95207_;
        float f3 = p_95229_ + this.f_95208_;
        float f4 = p_95227_ ? 1.0F - 0.25F * this.f_95207_ : 0.0F;
        float f5 = p_95227_ ? 1.0F - 0.25F * this.f_95208_ : 0.0F;
        p_95231_.m_339083_(p_253706_, f + f4, f2, 0.0F).m_338399_(p_95236_).m_167083_(this.f_95201_, this.f_95203_).m_338973_(p_365126_);
        p_95231_.m_339083_(p_253706_, f + f5, f3, 0.0F).m_338399_(p_95236_).m_167083_(this.f_95201_, this.f_95204_).m_338973_(p_365126_);
        p_95231_.m_339083_(p_253706_, f1 + f5, f3, 0.0F).m_338399_(p_95236_).m_167083_(this.f_95202_, this.f_95204_).m_338973_(p_365126_);
        p_95231_.m_339083_(p_253706_, f1 + f4, f2, 0.0F).m_338399_(p_95236_).m_167083_(this.f_95202_, this.f_95203_).m_338973_(p_365126_);
    }

    public void m_95220_(BakedGlyph.Effect p_95221_, Matrix4f p_254370_, VertexConsumer p_95223_, int p_95224_) {
        p_95223_.m_339083_(p_254370_, p_95221_.f_95237_, p_95221_.f_95238_, p_95221_.f_95241_)
            .m_338399_(p_95221_.f_348885_)
            .m_167083_(this.f_95201_, this.f_95203_)
            .m_338973_(p_95224_);
        p_95223_.m_339083_(p_254370_, p_95221_.f_95239_, p_95221_.f_95238_, p_95221_.f_95241_)
            .m_338399_(p_95221_.f_348885_)
            .m_167083_(this.f_95201_, this.f_95204_)
            .m_338973_(p_95224_);
        p_95223_.m_339083_(p_254370_, p_95221_.f_95239_, p_95221_.f_95240_, p_95221_.f_95241_)
            .m_338399_(p_95221_.f_348885_)
            .m_167083_(this.f_95202_, this.f_95204_)
            .m_338973_(p_95224_);
        p_95223_.m_339083_(p_254370_, p_95221_.f_95237_, p_95221_.f_95240_, p_95221_.f_95241_)
            .m_338399_(p_95221_.f_348885_)
            .m_167083_(this.f_95202_, this.f_95203_)
            .m_338973_(p_95224_);
    }

    public RenderType m_181387_(Font.DisplayMode p_181388_) {
        return this.f_283799_.m_284370_(p_181388_);
    }

    @OnlyIn(Dist.CLIENT)
    public static record Effect(float f_95237_, float f_95238_, float f_95239_, float f_95240_, float f_95241_, int f_348885_) {
    }

    @OnlyIn(Dist.CLIENT)
    public static record GlyphInstance(float f_347659_, float f_346777_, int f_346842_, BakedGlyph f_347257_, Style f_348676_, float f_346601_) {
    }
}