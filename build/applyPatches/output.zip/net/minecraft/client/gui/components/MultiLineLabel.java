package net.minecraft.client.gui.components;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface MultiLineLabel {
    MultiLineLabel f_94331_ = new MultiLineLabel() {
        @Override
        public void m_6276_(GuiGraphics p_283384_, int p_94395_, int p_94396_) {
        }

        @Override
        public void m_6514_(GuiGraphics p_283208_, int p_210825_, int p_210826_, int p_210827_, int p_210828_) {
        }

        @Override
        public void m_6508_(GuiGraphics p_283077_, int p_94379_, int p_94380_, int p_282157_, int p_282742_) {
        }

        @Override
        public int m_6516_(GuiGraphics p_283645_, int p_94389_, int p_94390_, int p_94391_, int p_94392_) {
            return p_94390_;
        }

        @Override
        public int m_5770_() {
            return 0;
        }

        @Override
        public int m_214161_() {
            return 0;
        }
    };

    static MultiLineLabel m_94350_(Font p_94351_, Component... p_94352_) {
        return m_169036_(p_94351_, Integer.MAX_VALUE, Integer.MAX_VALUE, p_94352_);
    }

    static MultiLineLabel m_94341_(Font p_94342_, int p_94344_, Component... p_345312_) {
        return m_169036_(p_94342_, p_94344_, Integer.MAX_VALUE, p_345312_);
    }

    static MultiLineLabel m_94345_(Font p_94346_, Component p_344884_, int p_94348_) {
        return m_169036_(p_94346_, p_94348_, Integer.MAX_VALUE, p_344884_);
    }

    static MultiLineLabel m_169036_(final Font p_169037_, final int p_342954_, final int p_342610_, final Component... p_345091_) {
        return p_345091_.length == 0 ? f_94331_ : new MultiLineLabel() {
            @Nullable
            private List<MultiLineLabel.TextAndWidth> f_337163_;
            @Nullable
            private Language f_337284_;

            @Override
            public void m_6276_(GuiGraphics p_283492_, int p_283184_, int p_282078_) {
                this.m_6514_(p_283492_, p_283184_, p_282078_, 9, -1);
            }

            @Override
            public void m_6514_(GuiGraphics p_281603_, int p_281267_, int p_281819_, int p_281545_, int p_282780_) {
                int i = p_281819_;

                for (MultiLineLabel.TextAndWidth multilinelabel$textandwidth : this.m_340624_()) {
                    p_281603_.m_280364_(p_169037_, multilinelabel$textandwidth.f_337690_, p_281267_, i, p_282780_);
                    i += p_281545_;
                }
            }

            @Override
            public void m_6508_(GuiGraphics p_282318_, int p_283665_, int p_283416_, int p_281919_, int p_281686_) {
                int i = p_283416_;

                for (MultiLineLabel.TextAndWidth multilinelabel$textandwidth : this.m_340624_()) {
                    p_282318_.m_280648_(p_169037_, multilinelabel$textandwidth.f_337690_, p_283665_, i, p_281686_);
                    i += p_281919_;
                }
            }

            @Override
            public int m_6516_(GuiGraphics p_281782_, int p_282841_, int p_283554_, int p_282768_, int p_283499_) {
                int i = p_283554_;

                for (MultiLineLabel.TextAndWidth multilinelabel$textandwidth : this.m_340624_()) {
                    p_281782_.m_280649_(p_169037_, multilinelabel$textandwidth.f_337690_, p_282841_, i, p_283499_, false);
                    i += p_282768_;
                }

                return i;
            }

            private List<MultiLineLabel.TextAndWidth> m_340624_() {
                Language language = Language.m_128107_();
                if (this.f_337163_ != null && language == this.f_337284_) {
                    return this.f_337163_;
                } else {
                    this.f_337284_ = language;
                    List<FormattedCharSequence> list = new ArrayList<>();

                    for (Component component : p_345091_) {
                        list.addAll(p_169037_.m_92923_(component, p_342954_));
                    }

                    this.f_337163_ = new ArrayList<>();

                    for (FormattedCharSequence formattedcharsequence : list.subList(0, Math.min(list.size(), p_342610_))) {
                        this.f_337163_.add(new MultiLineLabel.TextAndWidth(formattedcharsequence, p_169037_.m_92724_(formattedcharsequence)));
                    }

                    return this.f_337163_;
                }
            }

            @Override
            public int m_5770_() {
                return this.m_340624_().size();
            }

            @Override
            public int m_214161_() {
                return Math.min(p_342954_, this.m_340624_().stream().mapToInt(MultiLineLabel.TextAndWidth::f_337339_).max().orElse(0));
            }
        };
    }

    void m_6276_(GuiGraphics p_281749_, int p_94334_, int p_94335_);

    void m_6514_(GuiGraphics p_281785_, int p_94337_, int p_94338_, int p_94339_, int p_94340_);

    void m_6508_(GuiGraphics p_282655_, int p_94365_, int p_94366_, int p_94367_, int p_94368_);

    int m_6516_(GuiGraphics p_281982_, int p_94354_, int p_94355_, int p_94356_, int p_94357_);

    int m_5770_();

    int m_214161_();

    @OnlyIn(Dist.CLIENT)
    public static record TextAndWidth(FormattedCharSequence f_337690_, int f_337339_) {
    }
}