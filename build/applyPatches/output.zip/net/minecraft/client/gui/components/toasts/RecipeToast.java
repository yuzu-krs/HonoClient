package net.minecraft.client.gui.components.toasts;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.context.ContextMap;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.display.RecipeDisplay;
import net.minecraft.world.item.crafting.display.SlotDisplayContext;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class RecipeToast implements Toast {
    private static final ResourceLocation f_291662_ = ResourceLocation.m_340282_("toast/recipe");
    private static final long f_169076_ = 5000L;
    private static final Component f_94803_ = Component.m_237115_("recipe.toast.title");
    private static final Component f_94804_ = Component.m_237115_("recipe.toast.description");
    private final List<RecipeToast.Entry> f_348671_ = new ArrayList<>();
    private long f_94806_;
    private boolean f_94807_;
    private Toast.Visibility f_347163_ = Toast.Visibility.HIDE;
    private int f_349565_;

    private RecipeToast() {
    }

    @Override
    public Toast.Visibility m_7172_() {
        return this.f_347163_;
    }

    @Override
    public void m_351712_(ToastManager p_366265_, long p_364617_) {
        if (this.f_94807_) {
            this.f_94806_ = p_364617_;
            this.f_94807_ = false;
        }

        if (this.f_348671_.isEmpty()) {
            this.f_347163_ = Toast.Visibility.HIDE;
        } else {
            this.f_347163_ = (double)(p_364617_ - this.f_94806_) >= 5000.0 * p_366265_.m_357409_() ? Toast.Visibility.HIDE : Toast.Visibility.SHOW;
        }

        this.f_349565_ = (int)(
            (double)p_364617_ / Math.max(1.0, 5000.0 * p_366265_.m_357409_() / (double)this.f_348671_.size()) % (double)this.f_348671_.size()
        );
    }

    @Override
    public void m_280018_(GuiGraphics p_281667_, Font p_369994_, long p_281779_) {
        p_281667_.m_294122_(RenderType::m_355513_, f_291662_, 0, 0, this.m_7828_(), this.m_94899_());
        p_281667_.m_280614_(p_369994_, f_94803_, 30, 7, -11534256, false);
        p_281667_.m_280614_(p_369994_, f_94804_, 30, 18, -16777216, false);
        RecipeToast.Entry recipetoast$entry = this.f_348671_.get(this.f_349565_);
        p_281667_.m_280168_().m_85836_();
        p_281667_.m_280168_().m_85841_(0.6F, 0.6F, 1.0F);
        p_281667_.m_280203_(recipetoast$entry.f_347816_(), 3, 3);
        p_281667_.m_280168_().m_85849_();
        p_281667_.m_280203_(recipetoast$entry.f_347929_(), 8, 8);
    }

    private void m_94811_(ItemStack p_365961_, ItemStack p_367451_) {
        this.f_348671_.add(new RecipeToast.Entry(p_365961_, p_367451_));
        this.f_94807_ = true;
    }

    public static void m_94817_(ToastManager p_367086_, RecipeDisplay p_362853_) {
        RecipeToast recipetoast = p_367086_.m_353160_(RecipeToast.class, f_94894_);
        if (recipetoast == null) {
            recipetoast = new RecipeToast();
            p_367086_.m_351591_(recipetoast);
        }

        ContextMap contextmap = SlotDisplayContext.m_356058_(p_367086_.m_354773_().f_91073_);
        ItemStack itemstack = p_362853_.m_351862_().m_351754_(contextmap);
        ItemStack itemstack1 = p_362853_.m_353124_().m_351754_(contextmap);
        recipetoast.m_94811_(itemstack, itemstack1);
    }

    @OnlyIn(Dist.CLIENT)
    static record Entry(ItemStack f_347816_, ItemStack f_347929_) {
    }
}