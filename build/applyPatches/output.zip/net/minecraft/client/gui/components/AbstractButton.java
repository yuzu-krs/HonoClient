package net.minecraft.client.gui.components;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.navigation.CommonInputs;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class AbstractButton extends AbstractWidget {
    protected static final int f_273867_ = 2;
    private static final WidgetSprites f_290895_ = new WidgetSprites(
        ResourceLocation.m_340282_("widget/button"),
        ResourceLocation.m_340282_("widget/button_disabled"),
        ResourceLocation.m_340282_("widget/button_highlighted")
    );

    public AbstractButton(int p_93365_, int p_93366_, int p_93367_, int p_93368_, Component p_93369_) {
        super(p_93365_, p_93366_, p_93367_, p_93368_, p_93369_);
    }

    public abstract void m_5691_();

    @Override
    protected void m_87963_(GuiGraphics p_281670_, int p_282682_, int p_281714_, float p_282542_) {
        Minecraft minecraft = Minecraft.m_91087_();
        p_281670_.m_292816_(
            RenderType::m_355513_,
            f_290895_.m_295557_(this.f_93623_, this.m_198029_()),
            this.m_252754_(),
            this.m_252907_(),
            this.m_5711_(),
            this.m_93694_(),
            ARGB.m_357071_(this.f_93625_)
        );
        int i = this.f_93623_ ? 16777215 : 10526880;
        this.m_280465_(p_281670_, minecraft.f_91062_, i | Mth.m_14167_(this.f_93625_ * 255.0F) << 24);
    }

    public void m_280465_(GuiGraphics p_283366_, Font p_283054_, int p_281656_) {
        this.m_280372_(p_283366_, p_283054_, 2, p_281656_);
    }

    @Override
    public void m_5716_(double p_93371_, double p_93372_) {
        this.m_5691_();
    }

    @Override
    public boolean m_7933_(int p_93374_, int p_93375_, int p_93376_) {
        if (!this.f_93623_ || !this.f_93624_) {
            return false;
        } else if (CommonInputs.m_278691_(p_93374_)) {
            this.m_7435_(Minecraft.m_91087_().m_91106_());
            this.m_5691_();
            return true;
        } else {
            return false;
        }
    }
}