package net.minecraft.client.telemetry;

import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import javax.annotation.Nullable;
import net.minecraft.Util;
import net.minecraft.util.eventlog.EventLogDirectory;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class TelemetryLogManager implements AutoCloseable {
    private static final Logger f_260574_ = LogUtils.getLogger();
    private static final String f_260596_ = ".json";
    private static final int f_260510_ = 7;
    private final EventLogDirectory f_260465_;
    @Nullable
    private CompletableFuture<Optional<TelemetryEventLog>> f_260526_;

    private TelemetryLogManager(EventLogDirectory p_261728_) {
        this.f_260465_ = p_261728_;
    }

    public static CompletableFuture<Optional<TelemetryLogManager>> m_261252_(Path p_262078_) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                EventLogDirectory eventlogdirectory = EventLogDirectory.m_260952_(p_262078_, ".json");
                eventlogdirectory.m_261134_().m_261245_(LocalDate.now(), 7).m_261127_();
                return Optional.of(new TelemetryLogManager(eventlogdirectory));
            } catch (Exception exception) {
                f_260574_.error("Failed to create telemetry log manager", (Throwable)exception);
                return Optional.empty();
            }
        }, Util.m_183991_());
    }

    public CompletableFuture<Optional<TelemetryEventLogger>> m_260856_() {
        if (this.f_260526_ == null) {
            this.f_260526_ = CompletableFuture.supplyAsync(() -> {
                try {
                    EventLogDirectory.RawFile eventlogdirectory$rawfile = this.f_260465_.m_261046_(LocalDate.now());
                    FileChannel filechannel = eventlogdirectory$rawfile.m_261200_();
                    return Optional.of(new TelemetryEventLog(filechannel, Util.m_183991_()));
                } catch (IOException ioexception) {
                    f_260574_.error("Failed to open channel for telemetry event log", (Throwable)ioexception);
                    return Optional.empty();
                }
            }, Util.m_183991_());
        }

        return this.f_260526_.thenApply(p_262106_ -> p_262106_.map(TelemetryEventLog::m_261088_));
    }

    @Override
    public void close() {
        if (this.f_260526_ != null) {
            this.f_260526_.thenAccept(p_261871_ -> p_261871_.ifPresent(TelemetryEventLog::close));
        }
    }
}