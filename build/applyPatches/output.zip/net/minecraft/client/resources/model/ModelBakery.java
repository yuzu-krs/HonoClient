package net.minecraft.client.resources.model;

import com.mojang.logging.LogUtils;
import com.mojang.math.Transformation;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.block.model.BlockModel;
import net.minecraft.client.renderer.block.model.ItemModelGenerator;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class ModelBakery {
    public static final Material f_119219_ = new Material(TextureAtlas.f_118259_, ResourceLocation.m_340282_("block/fire_0"));
    public static final Material f_119220_ = new Material(TextureAtlas.f_118259_, ResourceLocation.m_340282_("block/fire_1"));
    public static final Material f_119221_ = new Material(TextureAtlas.f_118259_, ResourceLocation.m_340282_("block/lava_flow"));
    public static final Material f_119222_ = new Material(TextureAtlas.f_118259_, ResourceLocation.m_340282_("block/water_flow"));
    public static final Material f_119223_ = new Material(TextureAtlas.f_118259_, ResourceLocation.m_340282_("block/water_overlay"));
    public static final Material f_119224_ = new Material(Sheets.f_110737_, ResourceLocation.m_340282_("entity/banner_base"));
    public static final Material f_119225_ = new Material(Sheets.f_110738_, ResourceLocation.m_340282_("entity/shield_base"));
    public static final Material f_119226_ = new Material(Sheets.f_110738_, ResourceLocation.m_340282_("entity/shield_base_nopattern"));
    public static final int f_174875_ = 10;
    public static final List<ResourceLocation> f_119227_ = IntStream.range(0, 10)
        .mapToObj(p_340955_ -> ResourceLocation.m_340282_("block/destroy_stage_" + p_340955_))
        .collect(Collectors.toList());
    public static final List<ResourceLocation> f_119228_ = f_119227_.stream()
        .map(p_340960_ -> p_340960_.m_247266_(p_340956_ -> "textures/" + p_340956_ + ".png"))
        .collect(Collectors.toList());
    public static final List<RenderType> f_119229_ = f_119228_.stream().map(RenderType::m_110494_).collect(Collectors.toList());
    static final Logger f_119235_ = LogUtils.getLogger();
    static final ItemModelGenerator f_119241_ = new ItemModelGenerator();
    final Map<ModelBakery.BakedCacheKey, BakedModel> f_119213_ = new HashMap<>();
    private final Map<ModelResourceLocation, BakedModel> f_119215_ = new HashMap<>();
    private final Map<ModelResourceLocation, UnbakedModel> f_348467_;
    final Map<ResourceLocation, UnbakedModel> f_349345_;
    final UnbakedModel f_336931_;

    public ModelBakery(Map<ModelResourceLocation, UnbakedModel> p_251087_, Map<ResourceLocation, UnbakedModel> p_250416_, UnbakedModel p_361482_) {
        this.f_348467_ = p_251087_;
        this.f_349345_ = p_250416_;
        this.f_336931_ = p_361482_;
    }

    public void m_245909_(ModelBakery.TextureGetter p_343407_) {
        this.f_348467_.forEach((p_340958_, p_340959_) -> {
            BakedModel bakedmodel = null;

            try {
                bakedmodel = new ModelBakery.ModelBakerImpl(p_343407_, p_340958_).m_339454_(p_340959_, BlockModelRotation.X0_Y0);
            } catch (Exception exception) {
                f_119235_.warn("Unable to bake model: '{}': {}", p_340958_, exception);
            }

            if (bakedmodel != null) {
                this.f_119215_.put(p_340958_, bakedmodel);
            }
        });
    }

    public Map<ModelResourceLocation, BakedModel> m_119251_() {
        return this.f_119215_;
    }

    @OnlyIn(Dist.CLIENT)
    static record BakedCacheKey(ResourceLocation f_243934_, Transformation f_243798_, boolean f_243915_) {
    }

    @OnlyIn(Dist.CLIENT)
    class ModelBakerImpl implements ModelBaker {
        private final Function<Material, TextureAtlasSprite> f_243920_;

        ModelBakerImpl(final ModelBakery.TextureGetter p_342310_, final ModelResourceLocation p_344289_) {
            this.f_243920_ = p_340963_ -> p_342310_.m_338804_(p_344289_, p_340963_);
        }

        private UnbakedModel m_247217_(ResourceLocation p_248568_) {
            UnbakedModel unbakedmodel = ModelBakery.this.f_349345_.get(p_248568_);
            if (unbakedmodel == null) {
                ModelBakery.f_119235_.warn("Requested a model that was not discovered previously: {}", p_248568_);
                return ModelBakery.this.f_336931_;
            } else {
                return unbakedmodel;
            }
        }

        @Override
        public BakedModel m_245240_(ResourceLocation p_252176_, ModelState p_249765_) {
            ModelBakery.BakedCacheKey modelbakery$bakedcachekey = new ModelBakery.BakedCacheKey(p_252176_, p_249765_.m_6189_(), p_249765_.m_7538_());
            BakedModel bakedmodel = ModelBakery.this.f_119213_.get(modelbakery$bakedcachekey);
            if (bakedmodel != null) {
                return bakedmodel;
            } else {
                UnbakedModel unbakedmodel = this.m_247217_(p_252176_);
                BakedModel bakedmodel1 = this.m_339454_(unbakedmodel, p_249765_);
                ModelBakery.this.f_119213_.put(modelbakery$bakedcachekey, bakedmodel1);
                return bakedmodel1;
            }
        }

        BakedModel m_339454_(UnbakedModel p_343761_, ModelState p_342939_) {
            if (p_343761_ instanceof BlockModel blockmodel && blockmodel.m_111490_() == SpecialModels.f_347038_) {
                return ModelBakery.f_119241_.m_111670_(this.f_243920_, blockmodel).m_111449_(this.f_243920_, p_342939_, false);
            }

            return p_343761_.m_7611_(this, this.f_243920_, p_342939_);
        }
    }

    @FunctionalInterface
    @OnlyIn(Dist.CLIENT)
    public interface TextureGetter {
        TextureAtlasSprite m_338804_(ModelResourceLocation p_343839_, Material p_345409_);
    }
}