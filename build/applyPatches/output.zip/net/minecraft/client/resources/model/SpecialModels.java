package net.minecraft.client.resources.model;

import java.util.List;
import java.util.Map;
import net.minecraft.client.renderer.block.model.BlockModel;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class SpecialModels {
    public static final ResourceLocation f_349208_ = m_355556_("generated");
    public static final ResourceLocation f_348894_ = m_355556_("entity");
    public static final UnbakedModel f_347038_ = m_354475_("generation marker", BlockModel.GuiLight.FRONT);
    public static final UnbakedModel f_348406_ = m_354475_("block entity marker", BlockModel.GuiLight.SIDE);

    public static ResourceLocation m_355556_(String p_365122_) {
        return ResourceLocation.m_340282_("builtin/" + p_365122_);
    }

    private static UnbakedModel m_354475_(String p_369288_, BlockModel.GuiLight p_367009_) {
        BlockModel blockmodel = new BlockModel(null, List.of(), Map.of(), null, p_367009_, ItemTransforms.f_111786_, List.of());
        blockmodel.f_111416_ = p_369288_;
        return blockmodel;
    }
}