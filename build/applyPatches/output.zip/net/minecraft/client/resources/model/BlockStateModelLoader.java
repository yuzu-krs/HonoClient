package net.minecraft.client.resources.model;

import com.mojang.logging.LogUtils;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.client.renderer.block.BlockModelShaper;
import net.minecraft.client.renderer.block.model.BlockModelDefinition;
import net.minecraft.client.renderer.block.model.UnbakedBlockStateModel;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class BlockStateModelLoader {
    private static final Logger f_337111_ = LogUtils.getLogger();
    private static final String f_349483_ = "map";
    private static final String f_348080_ = "map=true";
    private static final String f_349403_ = "map=false";
    private static final StateDefinition<Block, BlockState> f_336962_ = new StateDefinition.Builder<Block, BlockState>(Blocks.f_50016_)
        .m_61104_(BooleanProperty.m_61465_("map"))
        .m_61101_(Block::m_49966_, BlockState::new);
    private static final ResourceLocation f_346605_ = ResourceLocation.m_340282_("glow_item_frame");
    private static final ResourceLocation f_348351_ = ResourceLocation.m_340282_("item_frame");
    private static final Map<ResourceLocation, StateDefinition<Block, BlockState>> f_337705_ = Map.of(f_348351_, f_336962_, f_346605_, f_336962_);
    public static final ModelResourceLocation f_349472_ = new ModelResourceLocation(f_346605_, "map=true");
    public static final ModelResourceLocation f_348500_ = new ModelResourceLocation(f_346605_, "map=false");
    public static final ModelResourceLocation f_349524_ = new ModelResourceLocation(f_348351_, "map=true");
    public static final ModelResourceLocation f_348464_ = new ModelResourceLocation(f_348351_, "map=false");
    private final UnbakedModel f_336883_;

    public BlockStateModelLoader(UnbakedModel p_344187_) {
        this.f_336883_ = p_344187_;
    }

    public static Function<ResourceLocation, StateDefinition<Block, BlockState>> m_353547_() {
        Map<ResourceLocation, StateDefinition<Block, BlockState>> map = new HashMap<>(f_337705_);

        for (Block block : BuiltInRegistries.f_256975_) {
            map.put(block.m_204297_().m_205785_().m_135782_(), block.m_49965_());
        }

        return map::get;
    }

    public BlockStateModelLoader.LoadedModels m_355177_(
        ResourceLocation p_367866_, StateDefinition<Block, BlockState> p_361140_, List<BlockStateModelLoader.LoadedBlockModelDefinition> p_367255_
    ) {
        List<BlockState> list = p_361140_.m_61056_();
        Map<BlockState, BlockStateModelLoader.LoadedModel> map = new HashMap<>();
        Map<ModelResourceLocation, BlockStateModelLoader.LoadedModel> map1 = new HashMap<>();

        try {
            for (BlockStateModelLoader.LoadedBlockModelDefinition blockstatemodelloader$loadedblockmodeldefinition : p_367255_) {
                blockstatemodelloader$loadedblockmodeldefinition.f_348679_
                    .m_351745_(p_361140_, p_367866_ + "/" + blockstatemodelloader$loadedblockmodeldefinition.f_347501_)
                    .forEach((p_358032_, p_358033_) -> map.put(p_358032_, new BlockStateModelLoader.LoadedModel(p_358032_, p_358033_)));
            }
        } finally {
        	for (BlockState blockstate : list) {
                    ModelResourceLocation modelresourcelocation = BlockModelShaper.m_110889_(p_367866_, blockstate);
                    BlockStateModelLoader.LoadedModel blockstatemodelloader$loadedmodel = map.get(blockstate);
                    if (blockstatemodelloader$loadedmodel == null) {
                        f_337111_.warn("Missing blockstate definition: '{}' missing model for variant: '{}'", p_367866_, modelresourcelocation);
                        blockstatemodelloader$loadedmodel = new BlockStateModelLoader.LoadedModel(blockstate, this.f_336883_);
                    }

                    map1.put(modelresourcelocation, blockstatemodelloader$loadedmodel);
                }
            }

        return new BlockStateModelLoader.LoadedModels(map1);
    }

    @OnlyIn(Dist.CLIENT)
    public static record LoadedBlockModelDefinition(String f_347501_, BlockModelDefinition f_348679_) {
    }

    @OnlyIn(Dist.CLIENT)
    public static record LoadedModel(BlockState f_346878_, UnbakedModel f_337292_) {
    }

    @OnlyIn(Dist.CLIENT)
    public static record LoadedModels(Map<ModelResourceLocation, BlockStateModelLoader.LoadedModel> f_347769_) {
    }
}
