package net.minecraft.client.resources.language;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.function.Consumer;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import net.minecraft.client.resources.metadata.language.LanguageMetadataSection;
import net.minecraft.locale.Language;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class LanguageManager implements ResourceManagerReloadListener {
    private static final Logger f_118964_ = LogUtils.getLogger();
    private static final LanguageInfo f_118965_ = new LanguageInfo("US", "English", false);
    private Map<String, LanguageInfo> f_118966_ = ImmutableMap.of("en_us", f_118965_);
    private String f_118967_;
    private final Consumer<ClientLanguage> f_337104_;

    public LanguageManager(String p_118971_, Consumer<ClientLanguage> p_342376_) {
        this.f_118967_ = p_118971_;
        this.f_337104_ = p_342376_;
    }

    private static Map<String, LanguageInfo> m_118981_(Stream<PackResources> p_118982_) {
        Map<String, LanguageInfo> map = Maps.newHashMap();
        p_118982_.forEach(p_264712_ -> {
            try {
                LanguageMetadataSection languagemetadatasection = p_264712_.m_5550_(LanguageMetadataSection.f_263724_);
                if (languagemetadatasection != null) {
                    languagemetadatasection.f_119097_().forEach(map::putIfAbsent);
                }
            } catch (IOException | RuntimeException runtimeexception) {
                f_118964_.warn("Unable to parse language metadata section of resourcepack: {}", p_264712_.m_5542_(), runtimeexception);
            }
        });
        return ImmutableMap.copyOf(map);
    }

    @Override
    public void m_6213_(ResourceManager p_118973_) {
        this.f_118966_ = m_118981_(p_118973_.m_7536_());
        List<String> list = new ArrayList<>(2);
        boolean flag = f_118965_.f_118946_();
        list.add("en_us");
        if (!this.f_118967_.equals("en_us")) {
            LanguageInfo languageinfo = this.f_118966_.get(this.f_118967_);
            if (languageinfo != null) {
                list.add(this.f_118967_);
                flag = languageinfo.f_118946_();
            }
        }

        ClientLanguage clientlanguage = ClientLanguage.m_264420_(p_118973_, list, flag);
        I18n.m_118941_(clientlanguage);
        Language.m_128114_(clientlanguage);
        this.f_337104_.accept(clientlanguage);
    }

    public void m_264110_(String p_265224_) {
        this.f_118967_ = p_265224_;
    }

    public String m_264236_() {
        return this.f_118967_;
    }

    public SortedMap<String, LanguageInfo> m_264450_() {
        return new TreeMap<>(this.f_118966_);
    }

    @Nullable
    public LanguageInfo m_118976_(String p_118977_) {
        return this.f_118966_.get(p_118977_);
    }
}