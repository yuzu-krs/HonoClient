package net.minecraft.client.player;

import com.mojang.authlib.GameProfile;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class AbstractClientPlayer extends Player {
    @Nullable
    private PlayerInfo f_108546_;
    protected Vec3 f_271420_ = Vec3.f_82478_;
    public float f_108542_;
    public float f_108543_;
    public float f_108544_;
    public final ClientLevel f_108545_;
    public float f_346273_;
    public float f_349037_;

    public AbstractClientPlayer(ClientLevel p_250460_, GameProfile p_249912_) {
        super(p_250460_, p_250460_.m_220360_(), p_250460_.m_220361_(), p_249912_);
        this.f_108545_ = p_250460_;
    }

    @Override
    public boolean m_5833_() {
        PlayerInfo playerinfo = this.m_108558_();
        return playerinfo != null && playerinfo.m_105325_() == GameType.SPECTATOR;
    }

    @Override
    public boolean m_7500_() {
        PlayerInfo playerinfo = this.m_108558_();
        return playerinfo != null && playerinfo.m_105325_() == GameType.CREATIVE;
    }

    @Nullable
    protected PlayerInfo m_108558_() {
        if (this.f_108546_ == null) {
            this.f_108546_ = Minecraft.m_91087_().m_91403_().m_104949_(this.m_20148_());
        }

        return this.f_108546_;
    }

    @Override
    public void m_8119_() {
        this.f_346273_ = this.f_349037_;
        this.f_271420_ = this.m_20184_();
        super.m_8119_();
    }

    public Vec3 m_272267_(float p_272943_) {
        return this.f_271420_.m_165921_(this.m_20184_(), (double)p_272943_);
    }

    public PlayerSkin m_294544_() {
        PlayerInfo playerinfo = this.m_108558_();
        return playerinfo == null ? DefaultPlayerSkin.m_294143_(this.m_20148_()) : playerinfo.m_293823_();
    }

    public float m_108565_(boolean p_361176_, float p_362521_) {
        float f = 1.0F;
        if (this.m_150110_().f_35935_) {
            f *= 1.1F;
        }

        float f1 = this.m_150110_().m_35947_();
        if (f1 != 0.0F) {
            float f2 = (float)this.m_246858_(Attributes.f_22279_) / f1;
            f *= (f2 + 1.0F) / 2.0F;
        }

        if (this.m_6117_()) {
            if (this.m_21211_().m_150930_(Items.f_42411_)) {
                float f3 = Math.min((float)this.m_21252_() / 20.0F, 1.0F);
                f *= 1.0F - Mth.m_14207_(f3) * 0.15F;
            } else if (p_361176_ && this.m_150108_()) {
                return 0.1F;
            }
        }

        return Mth.m_14179_(p_362521_, 1.0F, f);
    }
}