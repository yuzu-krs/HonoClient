package net.minecraft.client.renderer;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.shaders.FogShape;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.Util;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.ARGB;
import net.minecraft.util.CubicSampler;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.material.FogType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Vector3f;
import org.joml.Vector4f;

@OnlyIn(Dist.CLIENT)
public class FogRenderer {
    private static final int f_172575_ = 96;
    private static final List<FogRenderer.MobEffectFogFunction> f_234164_ = Lists.newArrayList(
        new FogRenderer.BlindnessFogFunction(), new FogRenderer.DarknessFogFunction()
    );
    public static final float f_172574_ = 5000.0F;
    private static int f_109013_ = -1;
    private static int f_109014_ = -1;
    private static long f_109015_ = -1L;
    private static boolean f_348610_ = true;

    public static Vector4f m_356830_(Camera p_362477_, float p_364035_, ClientLevel p_361507_, int p_361512_, float p_367602_) {
        FogType fogtype = p_362477_.m_167685_();
        Entity entity = p_362477_.m_90592_();
        float f;
        float f1;
        float f2;
        if (fogtype == FogType.WATER) {
            long i = Util.m_137550_();
            int k = p_361507_.m_204166_(BlockPos.m_274446_(p_362477_.m_90583_())).m_203334_().m_47561_();
            if (f_109015_ < 0L) {
                f_109013_ = k;
                f_109014_ = k;
                f_109015_ = i;
            }

            int l = f_109013_ >> 16 & 0xFF;
            int i1 = f_109013_ >> 8 & 0xFF;
            int j1 = f_109013_ & 0xFF;
            int k1 = f_109014_ >> 16 & 0xFF;
            int l1 = f_109014_ >> 8 & 0xFF;
            int i2 = f_109014_ & 0xFF;
            float f3 = Mth.m_14036_((float)(i - f_109015_) / 5000.0F, 0.0F, 1.0F);
            float f4 = Mth.m_14179_(f3, (float)k1, (float)l);
            float f5 = Mth.m_14179_(f3, (float)l1, (float)i1);
            float f6 = Mth.m_14179_(f3, (float)i2, (float)j1);
            f = f4 / 255.0F;
            f1 = f5 / 255.0F;
            f2 = f6 / 255.0F;
            if (f_109013_ != k) {
                f_109013_ = k;
                f_109014_ = Mth.m_14143_(f4) << 16 | Mth.m_14143_(f5) << 8 | Mth.m_14143_(f6);
                f_109015_ = i;
            }
        } else if (fogtype == FogType.LAVA) {
            f = 0.6F;
            f1 = 0.1F;
            f2 = 0.0F;
            f_109015_ = -1L;
        } else if (fogtype == FogType.POWDER_SNOW) {
            f = 0.623F;
            f1 = 0.734F;
            f2 = 0.785F;
            f_109015_ = -1L;
        } else {
            float f7 = 0.25F + 0.75F * (float)p_361512_ / 32.0F;
            f7 = 1.0F - (float)Math.pow((double)f7, 0.25);
            int j = p_361507_.m_171660_(p_362477_.m_90583_(), p_364035_);
            float f9 = ARGB.m_351887_(ARGB.m_353456_(j));
            float f11 = ARGB.m_351887_(ARGB.m_353987_(j));
            float f13 = ARGB.m_351887_(ARGB.m_353181_(j));
            float f14 = Mth.m_14036_(Mth.m_14089_(p_361507_.m_46942_(p_364035_) * (float) (Math.PI * 2)) * 2.0F + 0.5F, 0.0F, 1.0F);
            BiomeManager biomemanager = p_361507_.m_7062_();
            Vec3 vec3 = p_362477_.m_90583_().m_82492_(2.0, 2.0, 2.0).m_82490_(0.25);
            Vec3 vec31 = CubicSampler.m_130038_(
                vec3,
                (p_109033_, p_109034_, p_109035_) -> p_361507_.m_104583_()
                        .m_5927_(Vec3.m_82501_(biomemanager.m_204210_(p_109033_, p_109034_, p_109035_).m_203334_().m_47539_()), f14)
            );
            f = (float)vec31.m_7096_();
            f1 = (float)vec31.m_7098_();
            f2 = (float)vec31.m_7094_();
            if (p_361512_ >= 4) {
                float f15 = Mth.m_14031_(p_361507_.m_46490_(p_364035_)) > 0.0F ? -1.0F : 1.0F;
                Vector3f vector3f = new Vector3f(f15, 0.0F, 0.0F);
                float f19 = p_362477_.m_253058_().dot(vector3f);
                if (f19 < 0.0F) {
                    f19 = 0.0F;
                }

                if (f19 > 0.0F && p_361507_.m_104583_().m_352229_(p_361507_.m_46942_(p_364035_))) {
                    int j2 = p_361507_.m_104583_().m_356871_(p_361507_.m_46942_(p_364035_));
                    f19 *= ARGB.m_351887_(ARGB.m_356301_(j2));
                    f = f * (1.0F - f19) + ARGB.m_351887_(ARGB.m_353456_(j2)) * f19;
                    f1 = f1 * (1.0F - f19) + ARGB.m_351887_(ARGB.m_353987_(j2)) * f19;
                    f2 = f2 * (1.0F - f19) + ARGB.m_351887_(ARGB.m_353181_(j2)) * f19;
                }
            }

            f += (f9 - f) * f7;
            f1 += (f11 - f1) * f7;
            f2 += (f13 - f2) * f7;
            float f16 = p_361507_.m_46722_(p_364035_);
            if (f16 > 0.0F) {
                float f17 = 1.0F - f16 * 0.5F;
                float f20 = 1.0F - f16 * 0.4F;
                f *= f17;
                f1 *= f17;
                f2 *= f20;
            }

            float f18 = p_361507_.m_46661_(p_364035_);
            if (f18 > 0.0F) {
                float f21 = 1.0F - f18 * 0.5F;
                f *= f21;
                f1 *= f21;
                f2 *= f21;
            }

            f_109015_ = -1L;
        }

        float f8 = ((float)p_362477_.m_90583_().f_82480_ - (float)p_361507_.m_141937_()) * p_361507_.m_6106_().m_205519_();
        FogRenderer.MobEffectFogFunction fogrenderer$mobeffectfogfunction = m_234165_(entity, p_364035_);
        if (fogrenderer$mobeffectfogfunction != null) {
            LivingEntity livingentity = (LivingEntity)entity;
            f8 = fogrenderer$mobeffectfogfunction.m_213936_(livingentity, livingentity.m_21124_(fogrenderer$mobeffectfogfunction.m_213948_()), f8, p_364035_);
        }

        if (f8 < 1.0F && fogtype != FogType.LAVA && fogtype != FogType.POWDER_SNOW) {
            if (f8 < 0.0F) {
                f8 = 0.0F;
            }

            f8 *= f8;
            f *= f8;
            f1 *= f8;
            f2 *= f8;
        }

        if (p_367602_ > 0.0F) {
            f = f * (1.0F - p_367602_) + f * 0.7F * p_367602_;
            f1 = f1 * (1.0F - p_367602_) + f1 * 0.6F * p_367602_;
            f2 = f2 * (1.0F - p_367602_) + f2 * 0.6F * p_367602_;
        }

        float f10;
        if (fogtype == FogType.WATER) {
            if (entity instanceof LocalPlayer) {
                f10 = ((LocalPlayer)entity).m_108639_();
            } else {
                f10 = 1.0F;
            }
        } else {
            label86: {
                if (entity instanceof LivingEntity livingentity1
                    && livingentity1.m_21023_(MobEffects.f_19611_)
                    && !livingentity1.m_21023_(MobEffects.f_216964_)) {
                    f10 = GameRenderer.m_109108_(livingentity1, p_364035_);
                    break label86;
                }

                f10 = 0.0F;
            }
        }

        if (f != 0.0F && f1 != 0.0F && f2 != 0.0F) {
            float f12 = Math.min(1.0F / f, Math.min(1.0F / f1, 1.0F / f2));
            f = f * (1.0F - f10) + f * f12 * f10;
            f1 = f1 * (1.0F - f10) + f1 * f12 * f10;
            f2 = f2 * (1.0F - f10) + f2 * f12 * f10;
        }

        return new Vector4f(f, f1, f2, 1.0F);
    }

    public static boolean m_352056_() {
        return f_348610_ = !f_348610_;
    }

    @Nullable
    private static FogRenderer.MobEffectFogFunction m_234165_(Entity p_234166_, float p_234167_) {
        return p_234166_ instanceof LivingEntity livingentity
            ? f_234164_.stream().filter(p_234171_ -> p_234171_.m_234205_(livingentity, p_234167_)).findFirst().orElse(null)
            : null;
    }

    public static FogParameters m_234172_(
        Camera p_234173_, FogRenderer.FogMode p_234174_, Vector4f p_365589_, float p_234175_, boolean p_234176_, float p_234177_
    ) {
        if (!f_348610_) {
            return FogParameters.f_346502_;
        } else {
            FogType fogtype = p_234173_.m_167685_();
            Entity entity = p_234173_.m_90592_();
            FogRenderer.FogData fogrenderer$fogdata = new FogRenderer.FogData(p_234174_);
            FogRenderer.MobEffectFogFunction fogrenderer$mobeffectfogfunction = m_234165_(entity, p_234177_);
            if (fogtype == FogType.LAVA) {
                if (entity.m_5833_()) {
                    fogrenderer$fogdata.f_234200_ = -8.0F;
                    fogrenderer$fogdata.f_234201_ = p_234175_ * 0.5F;
                } else if (entity instanceof LivingEntity && ((LivingEntity)entity).m_21023_(MobEffects.f_19607_)) {
                    fogrenderer$fogdata.f_234200_ = 0.0F;
                    fogrenderer$fogdata.f_234201_ = 5.0F;
                } else {
                    fogrenderer$fogdata.f_234200_ = 0.25F;
                    fogrenderer$fogdata.f_234201_ = 1.0F;
                }
            } else if (fogtype == FogType.POWDER_SNOW) {
                if (entity.m_5833_()) {
                    fogrenderer$fogdata.f_234200_ = -8.0F;
                    fogrenderer$fogdata.f_234201_ = p_234175_ * 0.5F;
                } else {
                    fogrenderer$fogdata.f_234200_ = 0.0F;
                    fogrenderer$fogdata.f_234201_ = 2.0F;
                }
            } else if (fogrenderer$mobeffectfogfunction != null) {
                LivingEntity livingentity = (LivingEntity)entity;
                MobEffectInstance mobeffectinstance = livingentity.m_21124_(fogrenderer$mobeffectfogfunction.m_213948_());
                if (mobeffectinstance != null) {
                    fogrenderer$mobeffectfogfunction.m_213725_(fogrenderer$fogdata, livingentity, mobeffectinstance, p_234175_, p_234177_);
                }
            } else if (fogtype == FogType.WATER) {
                fogrenderer$fogdata.f_234200_ = -8.0F;
                fogrenderer$fogdata.f_234201_ = 96.0F;
                if (entity instanceof LocalPlayer localplayer) {
                    fogrenderer$fogdata.f_234201_ = fogrenderer$fogdata.f_234201_ * Math.max(0.25F, localplayer.m_108639_());
                    Holder<Biome> holder = localplayer.m_9236_().m_204166_(localplayer.m_20183_());
                    if (holder.m_203656_(BiomeTags.f_215802_)) {
                        fogrenderer$fogdata.f_234201_ *= 0.85F;
                    }
                }

                if (fogrenderer$fogdata.f_234201_ > p_234175_) {
                    fogrenderer$fogdata.f_234201_ = p_234175_;
                    fogrenderer$fogdata.f_234202_ = FogShape.CYLINDER;
                }
            } else if (p_234176_) {
                fogrenderer$fogdata.f_234200_ = p_234175_ * 0.05F;
                fogrenderer$fogdata.f_234201_ = Math.min(p_234175_, 192.0F) * 0.5F;
            } else if (p_234174_ == FogRenderer.FogMode.FOG_SKY) {
                fogrenderer$fogdata.f_234200_ = 0.0F;
                fogrenderer$fogdata.f_234201_ = p_234175_;
                fogrenderer$fogdata.f_234202_ = FogShape.CYLINDER;
            } else if (p_234174_ == FogRenderer.FogMode.FOG_TERRAIN) {
                float f = Mth.m_14036_(p_234175_ / 10.0F, 4.0F, 64.0F);
                fogrenderer$fogdata.f_234200_ = p_234175_ - f;
                fogrenderer$fogdata.f_234201_ = p_234175_;
                fogrenderer$fogdata.f_234202_ = FogShape.CYLINDER;
            }

            return new FogParameters(
                fogrenderer$fogdata.f_234200_, fogrenderer$fogdata.f_234201_, fogrenderer$fogdata.f_234202_, p_365589_.x, p_365589_.y, p_365589_.z, p_365589_.w
            );
        }
    }

    @OnlyIn(Dist.CLIENT)
    static class BlindnessFogFunction implements FogRenderer.MobEffectFogFunction {
        @Override
        public Holder<MobEffect> m_213948_() {
            return MobEffects.f_19610_;
        }

        @Override
        public void m_213725_(FogRenderer.FogData p_234181_, LivingEntity p_234182_, MobEffectInstance p_234183_, float p_234184_, float p_234185_) {
            float f = p_234183_.m_267577_() ? 5.0F : Mth.m_14179_(Math.min(1.0F, (float)p_234183_.m_19557_() / 20.0F), p_234184_, 5.0F);
            if (p_234181_.f_234199_ == FogRenderer.FogMode.FOG_SKY) {
                p_234181_.f_234200_ = 0.0F;
                p_234181_.f_234201_ = f * 0.8F;
            } else if (p_234181_.f_234199_ == FogRenderer.FogMode.FOG_TERRAIN) {
                p_234181_.f_234200_ = f * 0.25F;
                p_234181_.f_234201_ = f;
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    static class DarknessFogFunction implements FogRenderer.MobEffectFogFunction {
        @Override
        public Holder<MobEffect> m_213948_() {
            return MobEffects.f_216964_;
        }

        @Override
        public void m_213725_(FogRenderer.FogData p_234194_, LivingEntity p_234195_, MobEffectInstance p_234196_, float p_234197_, float p_234198_) {
            float f = Mth.m_14179_(p_234196_.m_318631_(p_234195_, p_234198_), p_234197_, 15.0F);

            p_234194_.f_234200_ = switch (p_234194_.f_234199_) {
                case FOG_SKY -> 0.0F;
                case FOG_TERRAIN -> f * 0.75F;
            };
            p_234194_.f_234201_ = f;
        }

        @Override
        public float m_213936_(LivingEntity p_234189_, MobEffectInstance p_234190_, float p_234191_, float p_234192_) {
            return 1.0F - p_234190_.m_318631_(p_234189_, p_234192_);
        }
    }

    @OnlyIn(Dist.CLIENT)
    static class FogData {
        public final FogRenderer.FogMode f_234199_;
        public float f_234200_;
        public float f_234201_;
        public FogShape f_234202_ = FogShape.SPHERE;

        public FogData(FogRenderer.FogMode p_234204_) {
            this.f_234199_ = p_234204_;
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static enum FogMode {
        FOG_SKY,
        FOG_TERRAIN;
    }

    @OnlyIn(Dist.CLIENT)
    interface MobEffectFogFunction {
        Holder<MobEffect> m_213948_();

        void m_213725_(FogRenderer.FogData p_234212_, LivingEntity p_234213_, MobEffectInstance p_234214_, float p_234215_, float p_234216_);

        default boolean m_234205_(LivingEntity p_234206_, float p_234207_) {
            return p_234206_.m_21023_(this.m_213948_());
        }

        default float m_213936_(LivingEntity p_234208_, MobEffectInstance p_234209_, float p_234210_, float p_234211_) {
            MobEffectInstance mobeffectinstance = p_234208_.m_21124_(this.m_213948_());
            if (mobeffectinstance != null) {
                if (mobeffectinstance.m_267633_(19)) {
                    p_234210_ = 1.0F - (float)mobeffectinstance.m_19557_() / 20.0F;
                } else {
                    p_234210_ = 0.0F;
                }
            }

            return p_234210_;
        }
    }
}