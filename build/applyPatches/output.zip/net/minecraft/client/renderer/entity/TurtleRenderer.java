package net.minecraft.client.renderer.entity;

import net.minecraft.client.model.TurtleModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.state.TurtleRenderState;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.animal.Turtle;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class TurtleRenderer extends AgeableMobRenderer<Turtle, TurtleRenderState, TurtleModel> {
    private static final ResourceLocation f_116231_ = ResourceLocation.m_340282_("textures/entity/turtle/big_sea_turtle.png");

    public TurtleRenderer(EntityRendererProvider.Context p_174430_) {
        super(p_174430_, new TurtleModel(p_174430_.m_174023_(ModelLayers.f_171260_)), new TurtleModel(p_174430_.m_174023_(ModelLayers.f_349473_)), 0.7F);
    }

    protected float m_318622_(TurtleRenderState p_363081_) {
        float f = super.m_318622_(p_363081_);
        return p_363081_.f_348880_ ? f * 0.83F : f;
    }

    public TurtleRenderState m_5478_() {
        return new TurtleRenderState();
    }

    public void m_351578_(Turtle p_369829_, TurtleRenderState p_365033_, float p_360902_) {
        super.m_351578_(p_369829_, p_365033_, p_360902_);
        p_365033_.f_346898_ = !p_369829_.m_20069_() && p_369829_.m_20096_();
        p_365033_.f_346561_ = p_369829_.m_30206_();
        p_365033_.f_348408_ = !p_369829_.m_6162_() && p_369829_.m_30205_();
    }

    public ResourceLocation m_113764_(TurtleRenderState p_368462_) {
        return f_116231_;
    }
}