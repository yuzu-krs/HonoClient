package net.minecraft.client.renderer.entity;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.scores.Team;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class LivingEntityRenderer<T extends LivingEntity, S extends LivingEntityRenderState, M extends EntityModel<? super S>>
    extends EntityRenderer<T, S>
    implements RenderLayerParent<S, M> {
    private static final float f_174287_ = 0.1F;
    protected M f_115290_;
    protected final ItemRenderer f_348708_;
    protected final List<RenderLayer<S, M>> f_115291_ = Lists.newArrayList();

    public LivingEntityRenderer(EntityRendererProvider.Context p_174289_, M p_174290_, float p_174291_) {
        super(p_174289_);
        this.f_348708_ = p_174289_.m_174025_();
        this.f_115290_ = p_174290_;
        this.f_114477_ = p_174291_;
    }

    protected final boolean m_115326_(RenderLayer<S, M> p_115327_) {
        return this.f_115291_.add(p_115327_);
    }

    @Override
    public M m_7200_() {
        return this.f_115290_;
    }

    protected AABB m_352235_(T p_361472_) {
        AABB aabb = super.m_352235_(p_361472_);
        if (p_361472_.m_6844_(EquipmentSlot.HEAD).m_150930_(Items.f_42683_)) {
            float f = 0.5F;
            return aabb.m_82377_(0.5, 0.5, 0.5);
        } else {
            return aabb;
        }
    }

    public void m_7392_(S p_364280_, PoseStack p_115311_, MultiBufferSource p_115312_, int p_115313_) {
        p_115311_.m_85836_();
        if (p_364280_.m_352923_(Pose.SLEEPING)) {
            Direction direction = p_364280_.f_347461_;
            if (direction != null) {
                float f = p_364280_.f_348161_ - 0.1F;
                p_115311_.m_252880_((float)(-direction.m_122429_()) * f, 0.0F, (float)(-direction.m_122431_()) * f);
            }
        }

        float f1 = p_364280_.f_349019_;
        p_115311_.m_85841_(f1, f1, f1);
        this.m_7523_(p_364280_, p_115311_, p_364280_.f_348412_, f1);
        p_115311_.m_85841_(-1.0F, -1.0F, 1.0F);
        this.m_7546_(p_364280_, p_115311_);
        p_115311_.m_252880_(0.0F, -1.501F, 0.0F);
        this.f_115290_.m_6973_(p_364280_);
        boolean flag1 = this.m_5933_(p_364280_);
        boolean flag = !flag1 && !p_364280_.f_348214_;
        RenderType rendertype = this.m_7225_(p_364280_, flag1, flag, p_364280_.f_348590_);
        if (rendertype != null) {
            VertexConsumer vertexconsumer = p_115312_.m_6299_(rendertype);
            int i = m_115338_(p_364280_, this.m_6931_(p_364280_));
            int j = flag ? 654311423 : -1;
            int k = ARGB.m_356655_(j, this.m_352085_(p_364280_));
            this.f_115290_.m_7695_(p_115311_, vertexconsumer, p_115313_, i, k);
        }

        if (this.m_351571_(p_364280_)) {
            for (RenderLayer<S, M> renderlayer : this.f_115291_) {
                renderlayer.m_6494_(p_115311_, p_115312_, p_115313_, p_364280_, p_364280_.f_349133_, p_364280_.f_347628_);
            }
        }

        p_115311_.m_85849_();
        super.m_7392_(p_364280_, p_115311_, p_115312_, p_115313_);
    }

    protected boolean m_351571_(S p_360804_) {
        return true;
    }

    protected int m_352085_(S p_361319_) {
        return -1;
    }

    public abstract ResourceLocation m_113764_(S p_362468_);

    @Nullable
    protected RenderType m_7225_(S p_369777_, boolean p_115323_, boolean p_115324_, boolean p_115325_) {
        ResourceLocation resourcelocation = this.m_113764_(p_369777_);
        if (p_115324_) {
            return RenderType.m_110467_(resourcelocation);
        } else if (p_115323_) {
            return this.f_115290_.m_103119_(resourcelocation);
        } else {
            return p_115325_ ? RenderType.m_110491_(resourcelocation) : null;
        }
    }

    public static int m_115338_(LivingEntityRenderState p_365259_, float p_115340_) {
        return OverlayTexture.m_118093_(OverlayTexture.m_118088_(p_115340_), OverlayTexture.m_118096_(p_365259_.f_346693_));
    }

    protected boolean m_5933_(S p_363166_) {
        return !p_363166_.f_347933_;
    }

    private static float m_115328_(Direction p_115329_) {
        switch (p_115329_) {
            case SOUTH:
                return 90.0F;
            case WEST:
                return 0.0F;
            case NORTH:
                return 270.0F;
            case EAST:
                return 180.0F;
            default:
                return 0.0F;
        }
    }

    protected boolean m_5936_(S p_361206_) {
        return p_361206_.f_349078_;
    }

    protected void m_7523_(S p_370120_, PoseStack p_115318_, float p_115319_, float p_115320_) {
        if (this.m_5936_(p_370120_)) {
            p_115319_ += (float)(Math.cos((double)((float)Mth.m_14143_(p_370120_.f_349307_) * 3.25F)) * Math.PI * 0.4F);
        }

        if (!p_370120_.m_352923_(Pose.SLEEPING)) {
            p_115318_.m_252781_(Axis.f_252436_.m_252977_(180.0F - p_115319_));
        }

        if (p_370120_.f_346621_ > 0.0F) {
            float f = (p_370120_.f_346621_ - 1.0F) / 20.0F * 1.6F;
            f = Mth.m_14116_(f);
            if (f > 1.0F) {
                f = 1.0F;
            }

            p_115318_.m_252781_(Axis.f_252403_.m_252977_(f * this.m_6441_()));
        } else if (p_370120_.f_348017_) {
            p_115318_.m_252781_(Axis.f_252529_.m_252977_(-90.0F - p_370120_.f_347628_));
            p_115318_.m_252781_(Axis.f_252436_.m_252977_(p_370120_.f_349307_ * -75.0F));
        } else if (p_370120_.m_352923_(Pose.SLEEPING)) {
            Direction direction = p_370120_.f_347461_;
            float f1 = direction != null ? m_115328_(direction) : p_115319_;
            p_115318_.m_252781_(Axis.f_252436_.m_252977_(f1));
            p_115318_.m_252781_(Axis.f_252403_.m_252977_(this.m_6441_()));
            p_115318_.m_252781_(Axis.f_252436_.m_252977_(270.0F));
        } else if (p_370120_.f_346935_) {
            p_115318_.m_252880_(0.0F, (p_370120_.f_347661_ + 0.1F) / p_115320_, 0.0F);
            p_115318_.m_252781_(Axis.f_252403_.m_252977_(180.0F));
        }
    }

    protected float m_6441_() {
        return 90.0F;
    }

    protected float m_6931_(S p_367139_) {
        return 0.0F;
    }

    protected void m_7546_(S p_363445_, PoseStack p_115315_) {
    }

    protected boolean m_6512_(T p_115333_, double p_365822_) {
        if (p_115333_.m_20163_()) {
            float f = 32.0F;
            if (p_365822_ >= 1024.0) {
                return false;
            }
        }

        Minecraft minecraft = Minecraft.m_91087_();
        LocalPlayer localplayer = minecraft.f_91074_;
        boolean flag = !p_115333_.m_20177_(localplayer);
        if (p_115333_ != localplayer) {
            Team team = p_115333_.m_5647_();
            Team team1 = localplayer.m_5647_();
            if (team != null) {
                Team.Visibility team$visibility = team.m_7470_();
                switch (team$visibility) {
                    case ALWAYS:
                        return flag;
                    case NEVER:
                        return false;
                    case HIDE_FOR_OTHER_TEAMS:
                        return team1 == null ? flag : team.m_83536_(team1) && (team.m_6259_() || flag);
                    case HIDE_FOR_OWN_TEAM:
                        return team1 == null ? flag : !team.m_83536_(team1) && flag;
                    default:
                        return true;
                }
            }
        }

        return Minecraft.m_91404_() && p_115333_ != minecraft.m_91288_() && flag && !p_115333_.m_20160_();
    }

    public static boolean m_194453_(LivingEntity p_194454_) {
        if (p_194454_ instanceof Player || p_194454_.m_8077_()) {
            String s = ChatFormatting.m_126649_(p_194454_.m_7755_().getString());
            if ("Dinnerbone".equals(s) || "Grumm".equals(s)) {
                return !(p_194454_ instanceof Player) || ((Player)p_194454_).m_36170_(PlayerModelPart.CAPE);
            }
        }

        return false;
    }

    protected float m_318622_(S p_363803_) {
        return super.m_318622_(p_363803_) * p_363803_.f_349019_;
    }

    public void m_351578_(T p_368665_, S p_363057_, float p_364497_) {
        super.m_351578_(p_368665_, p_363057_, p_364497_);
        float f = Mth.m_14189_(p_364497_, p_368665_.f_20886_, p_368665_.f_20885_);
        p_363057_.f_348412_ = m_354794_(p_368665_, f, p_364497_);
        p_363057_.f_349133_ = Mth.m_14177_(f - p_363057_.f_348412_);
        p_363057_.f_347628_ = p_368665_.m_356829_(p_364497_);
        p_363057_.f_349366_ = p_368665_.m_7770_();
        p_363057_.f_346935_ = m_194453_(p_368665_);
        if (p_363057_.f_346935_) {
            p_363057_.f_347628_ *= -1.0F;
            p_363057_.f_349133_ *= -1.0F;
        }

        if (!p_368665_.m_20159_() && p_368665_.m_6084_()) {
            p_363057_.f_346252_ = p_368665_.f_267362_.m_267590_(p_364497_);
            p_363057_.f_349061_ = p_368665_.f_267362_.m_267711_(p_364497_);
        } else {
            p_363057_.f_346252_ = 0.0F;
            p_363057_.f_349061_ = 0.0F;
        }

        if (p_368665_.m_20202_() instanceof LivingEntity livingentity) {
            p_363057_.f_348975_ = livingentity.f_267362_.m_267590_(p_364497_);
        } else {
            p_363057_.f_348975_ = p_363057_.f_346252_;
        }

        p_363057_.f_349019_ = p_368665_.m_6134_();
        p_363057_.f_347476_ = p_368665_.m_320705_();
        p_363057_.f_348071_ = p_368665_.m_20089_();
        p_363057_.f_347461_ = p_368665_.m_21259_();
        if (p_363057_.f_347461_ != null) {
            p_363057_.f_348161_ = p_368665_.m_20236_(Pose.STANDING);
        }

        p_363057_.f_349078_ = p_368665_.m_146890_();
        p_363057_.f_348880_ = p_368665_.m_6162_();
        p_363057_.f_346463_ = p_368665_.m_20069_();
        p_363057_.f_348017_ = p_368665_.m_21209_();
        p_363057_.f_346693_ = p_368665_.f_20916_ > 0 || p_368665_.f_20919_ > 0;
        ItemStack itemstack1 = p_368665_.m_6844_(EquipmentSlot.HEAD);
        p_363057_.f_347614_ = itemstack1.m_41777_();
        p_363057_.f_346929_ = this.f_348708_.m_352836_(itemstack1, p_368665_, ItemDisplayContext.HEAD);
        p_363057_.f_347370_ = p_368665_.m_5737_();
        ItemStack itemstack2 = p_368665_.m_352599_(HumanoidArm.RIGHT);
        ItemStack itemstack = p_368665_.m_352599_(HumanoidArm.LEFT);
        p_363057_.f_349595_ = itemstack2.m_41777_();
        p_363057_.f_348619_ = itemstack.m_41777_();
        p_363057_.f_346874_ = this.f_348708_.m_352836_(itemstack2, p_368665_, ItemDisplayContext.THIRD_PERSON_RIGHT_HAND);
        p_363057_.f_347968_ = this.f_348708_.m_352836_(itemstack, p_368665_, ItemDisplayContext.THIRD_PERSON_LEFT_HAND);
        p_363057_.f_346621_ = p_368665_.f_20919_ > 0 ? (float)p_368665_.f_20919_ + p_364497_ : 0.0F;
        Minecraft minecraft = Minecraft.m_91087_();
        p_363057_.f_348214_ = p_363057_.f_347933_ && p_368665_.m_20177_(minecraft.f_91074_);
        p_363057_.f_348590_ = minecraft.m_91314_(p_368665_);
    }

    private static float m_354794_(LivingEntity p_367822_, float p_362662_, float p_362007_) {
        if (p_367822_.m_20202_() instanceof LivingEntity livingentity) {
            float f2 = Mth.m_14189_(p_362007_, livingentity.f_20884_, livingentity.f_20883_);
            float f = 85.0F;
            float f1 = Mth.m_14036_(Mth.m_14177_(p_362662_ - f2), -85.0F, 85.0F);
            f2 = p_362662_ - f1;
            if (Math.abs(f1) > 50.0F) {
                f2 += f1 * 0.2F;
            }

            return f2;
        } else {
            return Mth.m_14189_(p_362007_, p_367822_.f_20884_, p_367822_.f_20883_);
        }
    }
}