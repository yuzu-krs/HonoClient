package net.minecraft.client.renderer.entity.layers;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerCapeModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.client.resources.model.EquipmentModelSet;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.equipment.EquipmentModel;
import net.minecraft.world.item.equipment.Equippable;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class CapeLayer extends RenderLayer<PlayerRenderState, PlayerModel> {
    private final HumanoidModel<PlayerRenderState> f_346668_;
    private final EquipmentModelSet f_349331_;

    public CapeLayer(RenderLayerParent<PlayerRenderState, PlayerModel> p_116602_, EntityModelSet p_364158_, EquipmentModelSet p_365349_) {
        super(p_116602_);
        this.f_346668_ = new PlayerCapeModel<>(p_364158_.m_171103_(ModelLayers.f_349033_));
        this.f_349331_ = p_365349_;
    }

    private boolean m_355695_(ItemStack p_362441_, EquipmentModel.LayerType p_367137_) {
        Equippable equippable = p_362441_.m_323252_(DataComponents.f_348912_);
        if (equippable != null && !equippable.f_348074_().isEmpty()) {
            EquipmentModel equipmentmodel = this.f_349331_.m_356035_(equippable.f_348074_().get());
            return !equipmentmodel.m_351645_(p_367137_).isEmpty();
        } else {
            return false;
        }
    }

    public void m_6494_(PoseStack p_116615_, MultiBufferSource p_116616_, int p_116617_, PlayerRenderState p_367257_, float p_116619_, float p_116620_) {
        if (!p_367257_.f_347933_ && p_367257_.f_349411_) {
            PlayerSkin playerskin = p_367257_.f_348779_;
            if (playerskin.f_291348_() != null) {
                if (!this.m_355695_(p_367257_.f_348260_, EquipmentModel.LayerType.WINGS)) {
                    p_116615_.m_85836_();
                    if (this.m_355695_(p_367257_.f_348260_, EquipmentModel.LayerType.HUMANOID)) {
                        p_116615_.m_252880_(0.0F, -0.053125F, 0.06875F);
                    }

                    VertexConsumer vertexconsumer = p_116616_.m_6299_(RenderType.m_110446_(playerskin.f_291348_()));
                    this.m_117386_().m_102872_(this.f_346668_);
                    this.f_346668_.m_6973_(p_367257_);
                    this.f_346668_.m_340227_(p_116615_, vertexconsumer, p_116617_, OverlayTexture.f_118083_);
                    p_116615_.m_85849_();
                }
            }
        }
    }
}