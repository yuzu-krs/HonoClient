package net.minecraft.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.SheetedDecalTextureGenerator;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexMultiConsumer;
import com.mojang.math.MatrixUtil;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.item.ItemColors;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.ItemModelShaper;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.ARGB;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BundleItem;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ItemRenderer implements ResourceManagerReloadListener {
    public static final ResourceLocation f_273897_ = ResourceLocation.m_340282_("textures/misc/enchanted_glint_entity.png");
    public static final ResourceLocation f_273833_ = ResourceLocation.m_340282_("textures/misc/enchanted_glint_item.png");
    public static final int f_174221_ = 8;
    public static final int f_174222_ = 8;
    public static final int f_346291_ = 200;
    public static final float f_174219_ = 0.5F;
    public static final float f_174220_ = 0.75F;
    public static final float f_256734_ = 0.0078125F;
    public static final ModelResourceLocation f_244324_ = ModelResourceLocation.m_340229_(ResourceLocation.m_340282_("trident"));
    public static final ModelResourceLocation f_244537_ = ModelResourceLocation.m_340229_(ResourceLocation.m_340282_("spyglass"));
    private final ModelManager f_346835_;
    private final ItemModelShaper f_115095_;
    private final ItemColors f_115097_;
    private final BlockEntityWithoutLevelRenderer f_174223_;

    public ItemRenderer(ModelManager p_266850_, ItemColors p_267016_, BlockEntityWithoutLevelRenderer p_267049_) {
        this.f_346835_ = p_266850_;
        this.f_115095_ = new ItemModelShaper(p_266850_);
        this.f_174223_ = p_267049_;
        this.f_115097_ = p_267016_;
    }

    private void m_115189_(BakedModel p_115190_, ItemStack p_115191_, int p_115192_, int p_115193_, PoseStack p_115194_, VertexConsumer p_115195_) {
        RandomSource randomsource = RandomSource.m_216327_();
        long i = 42L;

        for (Direction direction : Direction.values()) {
            randomsource.m_188584_(42L);
            this.m_115162_(p_115194_, p_115195_, p_115190_.m_213637_(null, direction, randomsource), p_115191_, p_115192_, p_115193_);
        }

        randomsource.m_188584_(42L);
        this.m_115162_(p_115194_, p_115195_, p_115190_.m_213637_(null, null, randomsource), p_115191_, p_115192_, p_115193_);
    }

    public void m_115143_(
        ItemStack p_115144_,
        ItemDisplayContext p_270188_,
        boolean p_115146_,
        PoseStack p_115147_,
        MultiBufferSource p_115148_,
        int p_115149_,
        int p_115150_,
        BakedModel p_115151_
    ) {
        if (!p_115144_.m_41619_()) {
            this.m_356315_(p_115144_, p_270188_, p_115146_, p_115147_, p_115148_, p_115149_, p_115150_, p_115151_, m_356510_(p_270188_));
        }
    }

    public void m_354008_(
        ItemStack p_366843_,
        ItemDisplayContext p_364164_,
        boolean p_366015_,
        PoseStack p_363983_,
        MultiBufferSource p_366400_,
        int p_364183_,
        int p_366202_,
        BakedModel p_364448_,
        @Nullable Level p_364558_,
        @Nullable LivingEntity p_370019_,
        int p_365291_
    ) {
        if (p_366843_.m_41720_() instanceof BundleItem bundleitem) {
            if (BundleItem.m_356052_(p_366843_)) {
                boolean flag = m_356510_(p_364164_);
                BakedModel bakedmodel = this.m_351722_(this.f_115095_.m_109394_(bundleitem.m_352137_()), p_366843_, p_364558_, p_370019_, p_365291_);
                this.m_354626_(p_366843_, p_364164_, p_366015_, p_363983_, p_366400_, p_364183_, p_366202_, bakedmodel, flag, -1.5F);
                ItemStack itemstack = BundleItem.m_355315_(p_366843_);
                BakedModel bakedmodel1 = this.m_174264_(itemstack, p_364558_, p_370019_, p_365291_);
                this.m_356315_(itemstack, p_364164_, p_366015_, p_363983_, p_366400_, p_364183_, p_366202_, bakedmodel1, flag);
                BakedModel bakedmodel2 = this.m_351722_(this.f_115095_.m_109394_(bundleitem.m_357172_()), p_366843_, p_364558_, p_370019_, p_365291_);
                this.m_354626_(p_366843_, p_364164_, p_366015_, p_363983_, p_366400_, p_364183_, p_366202_, bakedmodel2, flag, 0.5F);
            } else {
                this.m_115143_(p_366843_, p_364164_, p_366015_, p_363983_, p_366400_, p_364183_, p_366202_, p_364448_);
            }
        }
    }

    private void m_356315_(
        ItemStack p_365537_,
        ItemDisplayContext p_362112_,
        boolean p_366241_,
        PoseStack p_362829_,
        MultiBufferSource p_361571_,
        int p_360705_,
        int p_366554_,
        BakedModel p_363511_,
        boolean p_370176_
    ) {
        if (p_370176_) {
            if (p_365537_.m_150930_(Items.f_42713_)) {
                p_363511_ = this.f_346835_.m_119422_(f_244324_);
            } else if (p_365537_.m_150930_(Items.f_151059_)) {
                p_363511_ = this.f_346835_.m_119422_(f_244537_);
            }
        }

        this.m_354626_(p_365537_, p_362112_, p_366241_, p_362829_, p_361571_, p_360705_, p_366554_, p_363511_, p_370176_, -0.5F);
    }

    private void m_354626_(
        ItemStack p_368265_,
        ItemDisplayContext p_369628_,
        boolean p_365876_,
        PoseStack p_366810_,
        MultiBufferSource p_363829_,
        int p_363235_,
        int p_368132_,
        BakedModel p_369691_,
        boolean p_366607_,
        float p_368655_
    ) {
        p_366810_.m_85836_();
        p_369691_.m_7442_().m_269404_(p_369628_).m_111763_(p_365876_, p_366810_);
        p_366810_.m_252880_(-0.5F, -0.5F, p_368655_);
        this.m_355630_(p_368265_, p_369628_, p_366810_, p_363829_, p_363235_, p_368132_, p_369691_, p_366607_);
        p_366810_.m_85849_();
    }

    private void m_355630_(
        ItemStack p_364096_,
        ItemDisplayContext p_362035_,
        PoseStack p_370127_,
        MultiBufferSource p_365365_,
        int p_363416_,
        int p_367651_,
        BakedModel p_367824_,
        boolean p_366488_
    ) {
        if (!p_367824_.m_7521_() && (!p_364096_.m_150930_(Items.f_42713_) || p_366488_)) {
            RenderType rendertype = ItemBlockRenderTypes.m_109284_(p_364096_);
            VertexConsumer vertexconsumer;
            if (m_285827_(p_364096_) && p_364096_.m_41790_()) {
                PoseStack.Pose posestack$pose = p_370127_.m_85850_().m_323639_();
                if (p_362035_ == ItemDisplayContext.GUI) {
                    MatrixUtil.m_253023_(posestack$pose.m_252922_(), 0.5F);
                } else if (p_362035_.m_269069_()) {
                    MatrixUtil.m_253023_(posestack$pose.m_252922_(), 0.75F);
                }

                vertexconsumer = m_115180_(p_365365_, rendertype, posestack$pose);
            } else {
                vertexconsumer = m_115211_(p_365365_, rendertype, true, p_364096_.m_41790_());
            }

            this.m_115189_(p_367824_, p_364096_, p_363416_, p_367651_, p_370127_, vertexconsumer);
        } else {
            this.f_174223_.m_108829_(p_364096_, p_362035_, p_370127_, p_365365_, p_363416_, p_367651_);
        }
    }

    private static boolean m_356510_(ItemDisplayContext p_368418_) {
        return p_368418_ == ItemDisplayContext.GUI || p_368418_ == ItemDisplayContext.GROUND || p_368418_ == ItemDisplayContext.FIXED;
    }

    private static boolean m_285827_(ItemStack p_286353_) {
        return p_286353_.m_204117_(ItemTags.f_215866_) || p_286353_.m_150930_(Items.f_42524_);
    }

    public static VertexConsumer m_115184_(MultiBufferSource p_115185_, RenderType p_115186_, boolean p_115187_) {
        return p_115187_ ? VertexMultiConsumer.m_86168_(p_115185_.m_6299_(RenderType.m_110484_()), p_115185_.m_6299_(p_115186_)) : p_115185_.m_6299_(p_115186_);
    }

    public static VertexConsumer m_115180_(MultiBufferSource p_115181_, RenderType p_115182_, PoseStack.Pose p_115183_) {
        return VertexMultiConsumer.m_86168_(
            new SheetedDecalTextureGenerator(p_115181_.m_6299_(RenderType.m_110490_()), p_115183_, 0.0078125F), p_115181_.m_6299_(p_115182_)
        );
    }

    public static VertexConsumer m_115211_(MultiBufferSource p_115212_, RenderType p_115213_, boolean p_115214_, boolean p_115215_) {
        if (p_115215_) {
            return Minecraft.m_91085_() && p_115213_ == Sheets.m_110791_()
                ? VertexMultiConsumer.m_86168_(p_115212_.m_6299_(RenderType.m_110487_()), p_115212_.m_6299_(p_115213_))
                : VertexMultiConsumer.m_86168_(p_115212_.m_6299_(p_115214_ ? RenderType.m_110490_() : RenderType.m_110496_()), p_115212_.m_6299_(p_115213_));
        } else {
            return p_115212_.m_6299_(p_115213_);
        }
    }

    private void m_115162_(PoseStack p_115163_, VertexConsumer p_115164_, List<BakedQuad> p_115165_, ItemStack p_115166_, int p_115167_, int p_115168_) {
        boolean flag = !p_115166_.m_41619_();
        PoseStack.Pose posestack$pose = p_115163_.m_85850_();

        for (BakedQuad bakedquad : p_115165_) {
            int i = -1;
            if (flag && bakedquad.m_111304_()) {
                i = this.f_115097_.m_92676_(p_115166_, bakedquad.m_111305_());
            }

            float f = (float)ARGB.m_356301_(i) / 255.0F;
            float f1 = (float)ARGB.m_353456_(i) / 255.0F;
            float f2 = (float)ARGB.m_353987_(i) / 255.0F;
            float f3 = (float)ARGB.m_353181_(i) / 255.0F;
            p_115164_.m_85995_(posestack$pose, bakedquad, f1, f2, f3, f, p_115167_, p_115168_);
        }
    }

    public BakedModel m_174264_(ItemStack p_174265_, @Nullable Level p_174266_, @Nullable LivingEntity p_174267_, int p_174268_) {
        BakedModel bakedmodel = this.f_115095_.m_109406_(p_174265_);
        return this.m_351722_(bakedmodel, p_174265_, p_174266_, p_174267_, p_174268_);
    }

    public void m_269128_(
        ItemStack p_270761_,
        ItemDisplayContext p_270648_,
        int p_270410_,
        int p_270894_,
        PoseStack p_270430_,
        MultiBufferSource p_270457_,
        @Nullable Level p_270149_,
        int p_270509_
    ) {
        this.m_269491_(null, p_270761_, p_270648_, false, p_270430_, p_270457_, p_270149_, p_270410_, p_270894_, p_270509_);
    }

    public void m_269491_(
        @Nullable LivingEntity p_270101_,
        ItemStack p_270637_,
        ItemDisplayContext p_270437_,
        boolean p_270434_,
        PoseStack p_270230_,
        MultiBufferSource p_270411_,
        @Nullable Level p_270641_,
        int p_270595_,
        int p_270927_,
        int p_270845_
    ) {
        if (!p_270637_.m_41619_()) {
            BakedModel bakedmodel = this.m_174264_(p_270637_, p_270641_, p_270101_, p_270845_);
            this.m_115143_(p_270637_, p_270437_, p_270434_, p_270230_, p_270411_, p_270595_, p_270927_, bakedmodel);
        }
    }

    @Override
    public void m_6213_(ResourceManager p_115105_) {
        this.f_115095_.m_354225_();
    }

    @Nullable
    public BakedModel m_352836_(ItemStack p_364028_, LivingEntity p_361089_, ItemDisplayContext p_363628_) {
        return p_364028_.m_41619_() ? null : this.m_174264_(p_364028_, p_361089_.m_9236_(), p_361089_, p_361089_.m_19879_() + p_363628_.ordinal());
    }

    private BakedModel m_351722_(BakedModel p_366074_, ItemStack p_366170_, @Nullable Level p_366692_, @Nullable LivingEntity p_368475_, int p_365150_) {
        ClientLevel clientlevel = p_366692_ instanceof ClientLevel ? (ClientLevel)p_366692_ : null;
        BakedModel bakedmodel = p_366074_.m_352678_().m_351741_(p_366170_, clientlevel, p_368475_, p_365150_);
        return bakedmodel == null ? p_366074_ : bakedmodel;
    }
}