package net.minecraft.client.renderer.entity.layers;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class EnergySwirlLayer<S extends EntityRenderState, M extends EntityModel<S>> extends RenderLayer<S, M> {
    public EnergySwirlLayer(RenderLayerParent<S, M> p_116967_) {
        super(p_116967_);
    }

    @Override
    public void m_6494_(PoseStack p_116970_, MultiBufferSource p_116971_, int p_116972_, S p_367433_, float p_116974_, float p_116975_) {
        if (this.m_354165_(p_367433_)) {
            float f = p_367433_.f_349307_;
            M m = this.m_7193_();
            VertexConsumer vertexconsumer = p_116971_.m_6299_(RenderType.m_110436_(this.m_7029_(), this.m_7631_(f) % 1.0F, f * 0.01F % 1.0F));
            m.m_6973_(p_367433_);
            m.m_7695_(p_116970_, vertexconsumer, p_116972_, OverlayTexture.f_118083_, -8355712);
        }
    }

    protected abstract boolean m_354165_(S p_367450_);

    protected abstract float m_7631_(float p_116968_);

    protected abstract ResourceLocation m_7029_();

    protected abstract M m_7193_();
}