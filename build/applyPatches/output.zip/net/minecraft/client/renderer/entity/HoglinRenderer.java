package net.minecraft.client.renderer.entity;

import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.state.HoglinRenderState;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.hoglin.Hoglin;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class HoglinRenderer extends AbstractHoglinRenderer<Hoglin> {
    private static final ResourceLocation f_114853_ = ResourceLocation.m_340282_("textures/entity/hoglin/hoglin.png");

    public HoglinRenderer(EntityRendererProvider.Context p_174165_) {
        super(p_174165_, ModelLayers.f_171184_, ModelLayers.f_346627_, 0.7F);
    }

    public ResourceLocation m_113764_(HoglinRenderState p_368945_) {
        return f_114853_;
    }

    public void m_351578_(Hoglin p_368627_, HoglinRenderState p_365127_, float p_365776_) {
        super.m_351578_(p_368627_, p_365127_, p_365776_);
        p_365127_.f_346860_ = p_368627_.m_34554_();
    }

    protected boolean m_5936_(HoglinRenderState p_369897_) {
        return super.m_5936_(p_369897_) || p_369897_.f_346860_;
    }
}