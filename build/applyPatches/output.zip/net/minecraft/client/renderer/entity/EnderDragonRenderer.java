package net.minecraft.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.dragon.EnderDragonModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.state.EnderDragonRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.enderdragon.phases.DragonPhaseInstance;
import net.minecraft.world.entity.boss.enderdragon.phases.EnderDragonPhase;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.EndPodiumFeature;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Quaternionf;
import org.joml.Vector3f;

@OnlyIn(Dist.CLIENT)
public class EnderDragonRenderer extends EntityRenderer<EnderDragon, EnderDragonRenderState> {
    public static final ResourceLocation f_114174_ = ResourceLocation.m_340282_("textures/entity/end_crystal/end_crystal_beam.png");
    private static final ResourceLocation f_114175_ = ResourceLocation.m_340282_("textures/entity/enderdragon/dragon_exploding.png");
    private static final ResourceLocation f_114176_ = ResourceLocation.m_340282_("textures/entity/enderdragon/dragon.png");
    private static final ResourceLocation f_114177_ = ResourceLocation.m_340282_("textures/entity/enderdragon/dragon_eyes.png");
    private static final RenderType f_114178_ = RenderType.m_110458_(f_114176_);
    private static final RenderType f_114179_ = RenderType.m_110479_(f_114176_);
    private static final RenderType f_114180_ = RenderType.m_110488_(f_114177_);
    private static final RenderType f_114181_ = RenderType.m_110476_(f_114174_);
    private static final float f_114182_ = (float)(Math.sqrt(3.0) / 2.0);
    private final EnderDragonModel f_114183_;

    public EnderDragonRenderer(EntityRendererProvider.Context p_173973_) {
        super(p_173973_);
        this.f_114477_ = 0.5F;
        this.f_114183_ = new EnderDragonModel(p_173973_.m_174023_(ModelLayers.f_171144_));
    }

    public void m_7392_(EnderDragonRenderState p_361915_, PoseStack p_114202_, MultiBufferSource p_114203_, int p_114204_) {
        p_114202_.m_85836_();
        float f = p_361915_.m_353929_(7).f_348586_();
        float f1 = (float)(p_361915_.m_353929_(5).f_347944_() - p_361915_.m_353929_(10).f_347944_());
        p_114202_.m_252781_(Axis.f_252436_.m_252977_(-f));
        p_114202_.m_252781_(Axis.f_252529_.m_252977_(f1 * 10.0F));
        p_114202_.m_252880_(0.0F, 0.0F, 1.0F);
        p_114202_.m_85841_(-1.0F, -1.0F, 1.0F);
        p_114202_.m_252880_(0.0F, -1.501F, 0.0F);
        this.f_114183_.m_6973_(p_361915_);
        if (p_361915_.f_348482_ > 0.0F) {
            float f2 = p_361915_.f_348482_ / 200.0F;
            int i = ARGB.m_356955_(Mth.m_14143_(f2 * 255.0F), -1);
            VertexConsumer vertexconsumer = p_114203_.m_6299_(RenderType.m_173235_(f_114175_));
            this.f_114183_.m_7695_(p_114202_, vertexconsumer, p_114204_, OverlayTexture.f_118083_, i);
            VertexConsumer vertexconsumer1 = p_114203_.m_6299_(f_114179_);
            this.f_114183_.m_340227_(p_114202_, vertexconsumer1, p_114204_, OverlayTexture.m_118090_(0.0F, p_361915_.f_347232_));
        } else {
            VertexConsumer vertexconsumer2 = p_114203_.m_6299_(f_114178_);
            this.f_114183_.m_340227_(p_114202_, vertexconsumer2, p_114204_, OverlayTexture.m_118090_(0.0F, p_361915_.f_347232_));
        }

        VertexConsumer vertexconsumer3 = p_114203_.m_6299_(f_114180_);
        this.f_114183_.m_340227_(p_114202_, vertexconsumer3, p_114204_, OverlayTexture.f_118083_);
        if (p_361915_.f_348482_ > 0.0F) {
            float f3 = p_361915_.f_348482_ / 200.0F;
            p_114202_.m_85836_();
            p_114202_.m_252880_(0.0F, -1.0F, -2.0F);
            m_338930_(p_114202_, f3, p_114203_.m_6299_(RenderType.m_339127_()));
            m_338930_(p_114202_, f3, p_114203_.m_6299_(RenderType.m_339251_()));
            p_114202_.m_85849_();
        }

        p_114202_.m_85849_();
        if (p_361915_.f_346436_ != null) {
            m_114187_(
                (float)p_361915_.f_346436_.f_82479_,
                (float)p_361915_.f_346436_.f_82480_,
                (float)p_361915_.f_346436_.f_82481_,
                p_361915_.f_349307_,
                p_114202_,
                p_114203_,
                p_114204_
            );
        }

        super.m_7392_(p_361915_, p_114202_, p_114203_, p_114204_);
    }

    private static void m_338930_(PoseStack p_345439_, float p_344944_, VertexConsumer p_344181_) {
        p_345439_.m_85836_();
        float f = Math.min(p_344944_ > 0.8F ? (p_344944_ - 0.8F) / 0.2F : 0.0F, 1.0F);
        int i = ARGB.m_353391_(1.0F - f, 1.0F, 1.0F, 1.0F);
        int j = 16711935;
        RandomSource randomsource = RandomSource.m_216335_(432L);
        Vector3f vector3f = new Vector3f();
        Vector3f vector3f1 = new Vector3f();
        Vector3f vector3f2 = new Vector3f();
        Vector3f vector3f3 = new Vector3f();
        Quaternionf quaternionf = new Quaternionf();
        int k = Mth.m_14143_((p_344944_ + p_344944_ * p_344944_) / 2.0F * 60.0F);

        for (int l = 0; l < k; l++) {
            quaternionf.rotationXYZ(
                    randomsource.m_188501_() * (float) (Math.PI * 2),
                    randomsource.m_188501_() * (float) (Math.PI * 2),
                    randomsource.m_188501_() * (float) (Math.PI * 2)
                )
                .rotateXYZ(
                    randomsource.m_188501_() * (float) (Math.PI * 2),
                    randomsource.m_188501_() * (float) (Math.PI * 2),
                    randomsource.m_188501_() * (float) (Math.PI * 2) + p_344944_ * (float) (Math.PI / 2)
                );
            p_345439_.m_252781_(quaternionf);
            float f1 = randomsource.m_188501_() * 20.0F + 5.0F + f * 10.0F;
            float f2 = randomsource.m_188501_() * 2.0F + 1.0F + f * 2.0F;
            vector3f1.set(-f_114182_ * f2, f1, -0.5F * f2);
            vector3f2.set(f_114182_ * f2, f1, -0.5F * f2);
            vector3f3.set(0.0F, f1, f2);
            PoseStack.Pose posestack$pose = p_345439_.m_85850_();
            p_344181_.m_340301_(posestack$pose, vector3f).m_338399_(i);
            p_344181_.m_340301_(posestack$pose, vector3f1).m_338399_(16711935);
            p_344181_.m_340301_(posestack$pose, vector3f2).m_338399_(16711935);
            p_344181_.m_340301_(posestack$pose, vector3f).m_338399_(i);
            p_344181_.m_340301_(posestack$pose, vector3f2).m_338399_(16711935);
            p_344181_.m_340301_(posestack$pose, vector3f3).m_338399_(16711935);
            p_344181_.m_340301_(posestack$pose, vector3f).m_338399_(i);
            p_344181_.m_340301_(posestack$pose, vector3f3).m_338399_(16711935);
            p_344181_.m_340301_(posestack$pose, vector3f1).m_338399_(16711935);
        }

        p_345439_.m_85849_();
    }

    public static void m_114187_(
        float p_114188_, float p_114189_, float p_114190_, float p_114191_, PoseStack p_114193_, MultiBufferSource p_114194_, int p_114192_
    ) {
        float f = Mth.m_14116_(p_114188_ * p_114188_ + p_114190_ * p_114190_);
        float f1 = Mth.m_14116_(p_114188_ * p_114188_ + p_114189_ * p_114189_ + p_114190_ * p_114190_);
        p_114193_.m_85836_();
        p_114193_.m_252880_(0.0F, 2.0F, 0.0F);
        p_114193_.m_252781_(Axis.f_252436_.m_252961_((float)(-Math.atan2((double)p_114190_, (double)p_114188_)) - (float) (Math.PI / 2)));
        p_114193_.m_252781_(Axis.f_252529_.m_252961_((float)(-Math.atan2((double)f, (double)p_114189_)) - (float) (Math.PI / 2)));
        VertexConsumer vertexconsumer = p_114194_.m_6299_(f_114181_);
        float f2 = 0.0F - p_114191_ * 0.01F;
        float f3 = f1 / 32.0F - p_114191_ * 0.01F;
        int i = 8;
        float f4 = 0.0F;
        float f5 = 0.75F;
        float f6 = 0.0F;
        PoseStack.Pose posestack$pose = p_114193_.m_85850_();

        for (int j = 1; j <= 8; j++) {
            float f7 = Mth.m_14031_((float)j * (float) (Math.PI * 2) / 8.0F) * 0.75F;
            float f8 = Mth.m_14089_((float)j * (float) (Math.PI * 2) / 8.0F) * 0.75F;
            float f9 = (float)j / 8.0F;
            vertexconsumer.m_338370_(posestack$pose, f4 * 0.2F, f5 * 0.2F, 0.0F)
                .m_338399_(-16777216)
                .m_167083_(f6, f2)
                .m_338943_(OverlayTexture.f_118083_)
                .m_338973_(p_114192_)
                .m_339200_(posestack$pose, 0.0F, -1.0F, 0.0F);
            vertexconsumer.m_338370_(posestack$pose, f4, f5, f1)
                .m_338399_(-1)
                .m_167083_(f6, f3)
                .m_338943_(OverlayTexture.f_118083_)
                .m_338973_(p_114192_)
                .m_339200_(posestack$pose, 0.0F, -1.0F, 0.0F);
            vertexconsumer.m_338370_(posestack$pose, f7, f8, f1)
                .m_338399_(-1)
                .m_167083_(f9, f3)
                .m_338943_(OverlayTexture.f_118083_)
                .m_338973_(p_114192_)
                .m_339200_(posestack$pose, 0.0F, -1.0F, 0.0F);
            vertexconsumer.m_338370_(posestack$pose, f7 * 0.2F, f8 * 0.2F, 0.0F)
                .m_338399_(-16777216)
                .m_167083_(f9, f2)
                .m_338943_(OverlayTexture.f_118083_)
                .m_338973_(p_114192_)
                .m_339200_(posestack$pose, 0.0F, -1.0F, 0.0F);
            f4 = f7;
            f5 = f8;
            f6 = f9;
        }

        p_114193_.m_85849_();
    }

    public EnderDragonRenderState m_5478_() {
        return new EnderDragonRenderState();
    }

    public void m_351578_(EnderDragon p_367718_, EnderDragonRenderState p_360720_, float p_367927_) {
        super.m_351578_(p_367718_, p_360720_, p_367927_);
        p_360720_.f_348021_ = Mth.m_14179_(p_367927_, p_367718_.f_31081_, p_367718_.f_31082_);
        p_360720_.f_348482_ = p_367718_.f_31084_ > 0 ? (float)p_367718_.f_31084_ + p_367927_ : 0.0F;
        p_360720_.f_347232_ = p_367718_.f_20916_ > 0;
        EndCrystal endcrystal = p_367718_.f_31086_;
        if (endcrystal != null) {
            Vec3 vec3 = endcrystal.m_20318_(p_367927_).m_82520_(0.0, (double)EndCrystalRenderer.m_114158_((float)endcrystal.f_31032_ + p_367927_), 0.0);
            p_360720_.f_346436_ = vec3.m_82546_(p_367718_.m_20318_(p_367927_));
        } else {
            p_360720_.f_346436_ = null;
        }

        DragonPhaseInstance dragonphaseinstance = p_367718_.m_31157_().m_31415_();
        p_360720_.f_346278_ = dragonphaseinstance == EnderDragonPhase.f_31380_ || dragonphaseinstance == EnderDragonPhase.f_31381_;
        p_360720_.f_348611_ = dragonphaseinstance.m_7080_();
        BlockPos blockpos = p_367718_.m_9236_().m_5452_(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, EndPodiumFeature.m_287210_(p_367718_.m_287165_()));
        p_360720_.f_348243_ = blockpos.m_203193_(p_367718_.m_20182_());
        p_360720_.f_348865_ = p_367718_.m_21224_() ? 0.0F : p_367927_;
        p_360720_.f_349094_.m_354247_(p_367718_.f_348961_);
    }

    protected boolean m_351558_(EnderDragon p_362111_) {
        return false;
    }
}