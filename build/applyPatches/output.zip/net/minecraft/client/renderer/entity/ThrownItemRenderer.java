package net.minecraft.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.state.ThrownItemRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ThrownItemRenderer<T extends Entity & ItemSupplier> extends EntityRenderer<T, ThrownItemRenderState> {
    private final ItemRenderer f_116071_;
    private final float f_116072_;
    private final boolean f_116073_;

    public ThrownItemRenderer(EntityRendererProvider.Context p_174416_, float p_174417_, boolean p_174418_) {
        super(p_174416_);
        this.f_116071_ = p_174416_.m_174025_();
        this.f_116072_ = p_174417_;
        this.f_116073_ = p_174418_;
    }

    public ThrownItemRenderer(EntityRendererProvider.Context p_174414_) {
        this(p_174414_, 1.0F, false);
    }

    @Override
    protected int m_6086_(T p_116092_, BlockPos p_116093_) {
        return this.f_116073_ ? 15 : super.m_6086_(p_116092_, p_116093_);
    }

    public void m_7392_(ThrownItemRenderState p_362153_, PoseStack p_367133_, MultiBufferSource p_369201_, int p_366531_) {
        p_367133_.m_85836_();
        p_367133_.m_85841_(this.f_116072_, this.f_116072_, this.f_116072_);
        p_367133_.m_252781_(this.f_114476_.m_253208_());
        if (p_362153_.f_346675_ != null) {
            this.f_116071_
                .m_115143_(
                    p_362153_.f_348822_, ItemDisplayContext.GROUND, false, p_367133_, p_369201_, p_366531_, OverlayTexture.f_118083_, p_362153_.f_346675_
                );
        }

        p_367133_.m_85849_();
        super.m_7392_(p_362153_, p_367133_, p_369201_, p_366531_);
    }

    public ThrownItemRenderState m_5478_() {
        return new ThrownItemRenderState();
    }

    public void m_351578_(T p_367843_, ThrownItemRenderState p_362566_, float p_361133_) {
        super.m_351578_(p_367843_, p_362566_, p_361133_);
        ItemStack itemstack = p_367843_.m_7846_();
        p_362566_.f_346675_ = !itemstack.m_41619_() ? this.f_116071_.m_174264_(itemstack, p_367843_.m_9236_(), null, p_367843_.m_19879_()) : null;
        p_362566_.f_348822_ = itemstack.m_41777_();
    }
}