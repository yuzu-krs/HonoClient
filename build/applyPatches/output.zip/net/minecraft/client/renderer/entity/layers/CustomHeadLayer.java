package net.minecraft.client.renderer.entity.layers;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.Map;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HeadedModel;
import net.minecraft.client.model.SkullModelBase;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.SkullBlockRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ResolvableProfile;
import net.minecraft.world.level.block.AbstractSkullBlock;
import net.minecraft.world.level.block.SkullBlock;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class CustomHeadLayer<S extends LivingEntityRenderState, M extends EntityModel<S> & HeadedModel> extends RenderLayer<S, M> {
    private static final float f_347271_ = 0.625F;
    private static final float f_346704_ = 1.1875F;
    private final CustomHeadLayer.Transforms f_349003_;
    private final Map<SkullBlock.Type, SkullModelBase> f_174473_;
    private final ItemRenderer f_346846_;

    public CustomHeadLayer(RenderLayerParent<S, M> p_234829_, EntityModelSet p_234830_, ItemRenderer p_366480_) {
        this(p_234829_, p_234830_, CustomHeadLayer.Transforms.f_346701_, p_366480_);
    }

    public CustomHeadLayer(RenderLayerParent<S, M> p_234822_, EntityModelSet p_234823_, CustomHeadLayer.Transforms p_362492_, ItemRenderer p_368013_) {
        super(p_234822_);
        this.f_349003_ = p_362492_;
        this.f_174473_ = SkullBlockRenderer.m_173661_(p_234823_);
        this.f_346846_ = p_368013_;
    }

    public void m_6494_(PoseStack p_116731_, MultiBufferSource p_116732_, int p_116733_, S p_363423_, float p_116735_, float p_116736_) {
        ItemStack itemstack = p_363423_.f_347614_;
        BakedModel bakedmodel = p_363423_.f_346929_;
        if (!itemstack.m_41619_() && bakedmodel != null) {
            label17: {
                Item item = itemstack.m_41720_();
                p_116731_.m_85836_();
                p_116731_.m_85841_(this.f_349003_.f_347879_(), 1.0F, this.f_349003_.f_347879_());
                M m = this.m_117386_();
                m.m_351639_().m_104299_(p_116731_);
                m.m_5585_().m_104299_(p_116731_);
                if (item instanceof BlockItem blockitem && blockitem.m_40614_() instanceof AbstractSkullBlock abstractskullblock) {
                    p_116731_.m_252880_(0.0F, this.f_349003_.f_349412_(), 0.0F);
                    p_116731_.m_85841_(1.1875F, -1.1875F, -1.1875F);
                    ResolvableProfile resolvableprofile = itemstack.m_323252_(DataComponents.f_315901_);
                    p_116731_.m_85837_(-0.5, 0.0, -0.5);
                    SkullBlock.Type skullblock$type = abstractskullblock.m_48754_();
                    SkullModelBase skullmodelbase = this.f_174473_.get(skullblock$type);
                    RenderType rendertype = SkullBlockRenderer.m_112523_(skullblock$type, resolvableprofile);
                    SkullBlockRenderer.m_173663_(null, 180.0F, p_363423_.f_348975_, p_116731_, p_116732_, p_116733_, skullmodelbase, rendertype);
                    break label17;
                }

                if (!HumanoidArmorLayer.m_352636_(itemstack, EquipmentSlot.HEAD)) {
                    m_174483_(p_116731_, this.f_349003_);
                    this.f_346846_.m_115143_(itemstack, ItemDisplayContext.HEAD, false, p_116731_, p_116732_, p_116733_, OverlayTexture.f_118083_, bakedmodel);
                }
            }

            p_116731_.m_85849_();
        }
    }

    public static void m_174483_(PoseStack p_174484_, CustomHeadLayer.Transforms p_366424_) {
        p_174484_.m_252880_(0.0F, -0.25F + p_366424_.f_346494_(), 0.0F);
        p_174484_.m_252781_(Axis.f_252436_.m_252977_(180.0F));
        p_174484_.m_85841_(0.625F, -0.625F, -0.625F);
    }

    @OnlyIn(Dist.CLIENT)
    public static record Transforms(float f_346494_, float f_349412_, float f_347879_) {
        public static final CustomHeadLayer.Transforms f_346701_ = new CustomHeadLayer.Transforms(0.0F, 0.0F, 1.0F);
    }
}