package net.minecraft.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.mojang.math.Transformation;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.state.BlockDisplayEntityRenderState;
import net.minecraft.client.renderer.entity.state.DisplayEntityRenderState;
import net.minecraft.client.renderer.entity.state.ItemDisplayEntityRenderState;
import net.minecraft.client.renderer.entity.state.TextDisplayEntityRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.Display;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

@OnlyIn(Dist.CLIENT)
public abstract class DisplayRenderer<T extends Display, S, ST extends DisplayEntityRenderState> extends EntityRenderer<T, ST> {
    private final EntityRenderDispatcher f_268749_;

    protected DisplayRenderer(EntityRendererProvider.Context p_270168_) {
        super(p_270168_);
        this.f_268749_ = p_270168_.m_174022_();
    }

    protected AABB m_352235_(T p_368254_) {
        return p_368254_.m_269567_();
    }

    protected boolean m_351558_(T p_365810_) {
        return p_365810_.m_351985_();
    }

    private static int m_351966_(Display p_365446_) {
        Display.RenderState display$renderstate = p_365446_.m_276844_();
        return display$renderstate != null ? display$renderstate.f_276438_() : -1;
    }

    protected int m_114508_(T p_367797_, BlockPos p_364805_) {
        int i = m_351966_(p_367797_);
        return i != -1 ? LightTexture.m_109894_(i) : super.m_114508_(p_367797_, p_364805_);
    }

    protected int m_6086_(T p_362888_, BlockPos p_365686_) {
        int i = m_351966_(p_362888_);
        return i != -1 ? LightTexture.m_109883_(i) : super.m_6086_(p_362888_, p_365686_);
    }

    public void m_7392_(ST p_363838_, PoseStack p_270117_, MultiBufferSource p_270319_, int p_270659_) {
        Display.RenderState display$renderstate = p_363838_.f_348947_;
        if (display$renderstate != null) {
            if (p_363838_.m_352034_()) {
                float f = p_363838_.f_349596_;
                this.f_114477_ = display$renderstate.f_276607_().m_269229_(f);
                this.f_114478_ = display$renderstate.f_276693_().m_269229_(f);
                super.m_7392_(p_363838_, p_270117_, p_270319_, p_270659_);
                p_270117_.m_85836_();
                p_270117_.m_252781_(this.m_269592_(display$renderstate, p_363838_, new Quaternionf()));
                Transformation transformation = display$renderstate.f_276585_().m_269136_(f);
                p_270117_.m_318714_(transformation.m_252783_());
                this.m_276924_(p_363838_, p_270117_, p_270319_, p_270659_, f);
                p_270117_.m_85849_();
            }
        }
    }

    private Quaternionf m_269592_(Display.RenderState p_277846_, ST p_361564_, Quaternionf p_298476_) {
        Camera camera = this.f_268749_.f_114358_;

        return switch (p_277846_.f_276506_()) {
            case FIXED -> p_298476_.rotationYXZ((float) (-Math.PI / 180.0) * p_361564_.f_346284_, (float) (Math.PI / 180.0) * p_361564_.f_346784_, 0.0F);
            case HORIZONTAL -> p_298476_.rotationYXZ((float) (-Math.PI / 180.0) * p_361564_.f_346284_, (float) (Math.PI / 180.0) * m_293458_(camera), 0.0F);
            case VERTICAL -> p_298476_.rotationYXZ((float) (-Math.PI / 180.0) * m_294349_(camera), (float) (Math.PI / 180.0) * p_361564_.f_346784_, 0.0F);
            case CENTER -> p_298476_.rotationYXZ((float) (-Math.PI / 180.0) * m_294349_(camera), (float) (Math.PI / 180.0) * m_293458_(camera), 0.0F);
        };
    }

    private static float m_294349_(Camera p_299213_) {
        return p_299213_.m_90590_() - 180.0F;
    }

    private static float m_293458_(Camera p_297923_) {
        return -p_297923_.m_90589_();
    }

    private static <T extends Display> float m_294729_(T p_297849_, float p_297686_) {
        return p_297849_.m_352577_(p_297686_);
    }

    private static <T extends Display> float m_295781_(T p_298651_, float p_297691_) {
        return p_298651_.m_356829_(p_297691_);
    }

    protected abstract void m_276924_(ST p_361844_, PoseStack p_277686_, MultiBufferSource p_277429_, int p_278023_, float p_277453_);

    public void m_351578_(T p_364120_, ST p_362498_, float p_362522_) {
        super.m_351578_(p_364120_, p_362498_, p_362522_);
        p_362498_.f_348947_ = p_364120_.m_276844_();
        p_362498_.f_349596_ = p_364120_.m_272147_(p_362522_);
        p_362498_.f_346284_ = m_294729_(p_364120_, p_362522_);
        p_362498_.f_346784_ = m_295781_(p_364120_, p_362522_);
    }

    @OnlyIn(Dist.CLIENT)
    public static class BlockDisplayRenderer
        extends DisplayRenderer<Display.BlockDisplay, Display.BlockDisplay.BlockRenderState, BlockDisplayEntityRenderState> {
        private final BlockRenderDispatcher f_268487_;

        protected BlockDisplayRenderer(EntityRendererProvider.Context p_270283_) {
            super(p_270283_);
            this.f_268487_ = p_270283_.m_234597_();
        }

        public BlockDisplayEntityRenderState m_5478_() {
            return new BlockDisplayEntityRenderState();
        }

        public void m_351578_(Display.BlockDisplay p_367120_, BlockDisplayEntityRenderState p_364696_, float p_367582_) {
            super.m_351578_(p_367120_, p_364696_, p_367582_);
            p_364696_.f_346218_ = p_367120_.m_276881_();
        }

        public void m_276924_(BlockDisplayEntityRenderState p_363283_, PoseStack p_277831_, MultiBufferSource p_277554_, int p_278071_, float p_277847_) {
            this.f_268487_.m_110912_(p_363283_.f_346218_.f_276526_(), p_277831_, p_277554_, p_278071_, OverlayTexture.f_118083_);
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class ItemDisplayRenderer extends DisplayRenderer<Display.ItemDisplay, Display.ItemDisplay.ItemRenderState, ItemDisplayEntityRenderState> {
        private final ItemRenderer f_268604_;

        protected ItemDisplayRenderer(EntityRendererProvider.Context p_270110_) {
            super(p_270110_);
            this.f_268604_ = p_270110_.m_174025_();
        }

        public ItemDisplayEntityRenderState m_5478_() {
            return new ItemDisplayEntityRenderState();
        }

        public void m_351578_(Display.ItemDisplay p_368800_, ItemDisplayEntityRenderState p_363947_, float p_365503_) {
            super.m_351578_(p_368800_, p_363947_, p_365503_);
            Display.ItemDisplay.ItemRenderState display$itemdisplay$itemrenderstate = p_368800_.m_277122_();
            if (display$itemdisplay$itemrenderstate != null) {
                p_363947_.f_346963_ = display$itemdisplay$itemrenderstate;
                p_363947_.f_349313_ = this.f_268604_.m_174264_(p_363947_.f_346963_.f_276600_(), p_368800_.m_9236_(), null, p_368800_.m_19879_());
            } else {
                p_363947_.f_346963_ = null;
                p_363947_.f_349313_ = null;
            }
        }

        public void m_276924_(ItemDisplayEntityRenderState p_361473_, PoseStack p_277361_, MultiBufferSource p_277912_, int p_277474_, float p_278032_) {
            Display.ItemDisplay.ItemRenderState display$itemdisplay$itemrenderstate = p_361473_.f_346963_;
            BakedModel bakedmodel = p_361473_.f_349313_;
            if (display$itemdisplay$itemrenderstate != null && bakedmodel != null) {
                p_277361_.m_252781_(Axis.f_252436_.m_252961_((float) Math.PI));
                this.f_268604_
                    .m_115143_(
                        display$itemdisplay$itemrenderstate.f_276600_(),
                        display$itemdisplay$itemrenderstate.f_276629_(),
                        false,
                        p_277361_,
                        p_277912_,
                        p_277474_,
                        OverlayTexture.f_118083_,
                        bakedmodel
                    );
            }
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class TextDisplayRenderer extends DisplayRenderer<Display.TextDisplay, Display.TextDisplay.TextRenderState, TextDisplayEntityRenderState> {
        private final Font f_268575_;

        protected TextDisplayRenderer(EntityRendererProvider.Context p_271012_) {
            super(p_271012_);
            this.f_268575_ = p_271012_.m_174028_();
        }

        public TextDisplayEntityRenderState m_5478_() {
            return new TextDisplayEntityRenderState();
        }

        public void m_351578_(Display.TextDisplay p_365496_, TextDisplayEntityRenderState p_366254_, float p_368471_) {
            super.m_351578_(p_365496_, p_366254_, p_368471_);
            p_366254_.f_347836_ = p_365496_.m_277174_();
            p_366254_.f_348399_ = p_365496_.m_269343_(this::m_269268_);
        }

        private Display.TextDisplay.CachedInfo m_269268_(Component p_270823_, int p_270893_) {
            List<FormattedCharSequence> list = this.f_268575_.m_92923_(p_270823_, p_270893_);
            List<Display.TextDisplay.CachedLine> list1 = new ArrayList<>(list.size());
            int i = 0;

            for (FormattedCharSequence formattedcharsequence : list) {
                int j = this.f_268575_.m_92724_(formattedcharsequence);
                i = Math.max(i, j);
                list1.add(new Display.TextDisplay.CachedLine(formattedcharsequence, j));
            }

            return new Display.TextDisplay.CachedInfo(list1, i);
        }

        public void m_276924_(TextDisplayEntityRenderState p_366994_, PoseStack p_277536_, MultiBufferSource p_277845_, int p_278046_, float p_277769_) {
            Display.TextDisplay.TextRenderState display$textdisplay$textrenderstate = p_366994_.f_347836_;
            byte b0 = display$textdisplay$textrenderstate.f_276556_();
            boolean flag = (b0 & 2) != 0;
            boolean flag1 = (b0 & 4) != 0;
            boolean flag2 = (b0 & 1) != 0;
            Display.TextDisplay.Align display$textdisplay$align = Display.TextDisplay.m_269384_(b0);
            byte b1 = (byte)display$textdisplay$textrenderstate.f_276579_().m_269120_(p_277769_);
            int i;
            if (flag1) {
                float f = Minecraft.m_91087_().f_91066_.m_92141_(0.25F);
                i = (int)(f * 255.0F) << 24;
            } else {
                i = display$textdisplay$textrenderstate.f_276562_().m_269120_(p_277769_);
            }

            float f2 = 0.0F;
            Matrix4f matrix4f = p_277536_.m_85850_().m_252922_();
            matrix4f.rotate((float) Math.PI, 0.0F, 1.0F, 0.0F);
            matrix4f.scale(-0.025F, -0.025F, -0.025F);
            Display.TextDisplay.CachedInfo display$textdisplay$cachedinfo = p_366994_.f_348399_;
            int j = 1;
            int k = 9 + 1;
            int l = display$textdisplay$cachedinfo.f_268557_();
            int i1 = display$textdisplay$cachedinfo.f_268675_().size() * k - 1;
            matrix4f.translate(1.0F - (float)l / 2.0F, (float)(-i1), 0.0F);
            if (i != 0) {
                VertexConsumer vertexconsumer = p_277845_.m_6299_(flag ? RenderType.m_269508_() : RenderType.m_269058_());
                vertexconsumer.m_339083_(matrix4f, -1.0F, -1.0F, 0.0F).m_338399_(i).m_338973_(p_278046_);
                vertexconsumer.m_339083_(matrix4f, -1.0F, (float)i1, 0.0F).m_338399_(i).m_338973_(p_278046_);
                vertexconsumer.m_339083_(matrix4f, (float)l, (float)i1, 0.0F).m_338399_(i).m_338973_(p_278046_);
                vertexconsumer.m_339083_(matrix4f, (float)l, -1.0F, 0.0F).m_338399_(i).m_338973_(p_278046_);
            }

            for (Display.TextDisplay.CachedLine display$textdisplay$cachedline : display$textdisplay$cachedinfo.f_268675_()) {
                float f1 = switch (display$textdisplay$align) {
                    case LEFT -> 0.0F;
                    case RIGHT -> (float)(l - display$textdisplay$cachedline.f_268443_());
                    case CENTER -> (float)l / 2.0F - (float)display$textdisplay$cachedline.f_268443_() / 2.0F;
                };
                this.f_268575_
                    .m_272191_(
                        display$textdisplay$cachedline.f_268516_(),
                        f1,
                        f2,
                        b1 << 24 | 16777215,
                        flag2,
                        matrix4f,
                        p_277845_,
                        flag ? Font.DisplayMode.SEE_THROUGH : Font.DisplayMode.POLYGON_OFFSET,
                        0,
                        p_278046_
                    );
                f2 += (float)k;
            }
        }
    }
}