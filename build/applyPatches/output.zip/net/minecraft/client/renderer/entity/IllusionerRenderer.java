package net.minecraft.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.Arrays;
import net.minecraft.client.model.IllagerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.client.renderer.entity.state.IllusionerRenderState;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.monster.Illusioner;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class IllusionerRenderer extends IllagerRenderer<Illusioner, IllusionerRenderState> {
    private static final ResourceLocation f_114922_ = ResourceLocation.m_340282_("textures/entity/illager/illusioner.png");

    public IllusionerRenderer(EntityRendererProvider.Context p_174186_) {
        super(p_174186_, new IllagerModel<>(p_174186_.m_174023_(ModelLayers.f_171191_)), 0.5F);
        this.m_115326_(
            new ItemInHandLayer<IllusionerRenderState, IllagerModel<IllusionerRenderState>>(this, p_174186_.m_174025_()) {
                public void m_6494_(
                    PoseStack p_114967_, MultiBufferSource p_114968_, int p_114969_, IllusionerRenderState p_363608_, float p_114971_, float p_114972_
                ) {
                    if (p_363608_.f_349372_ || p_363608_.f_348926_) {
                        super.m_6494_(p_114967_, p_114968_, p_114969_, p_363608_, p_114971_, p_114972_);
                    }
                }
            }
        );
        this.f_115290_.m_102934_().f_104207_ = true;
    }

    public ResourceLocation m_113764_(IllusionerRenderState p_369391_) {
        return f_114922_;
    }

    public IllusionerRenderState m_5478_() {
        return new IllusionerRenderState();
    }

    public void m_351578_(Illusioner p_362717_, IllusionerRenderState p_369406_, float p_368331_) {
        super.m_351578_(p_362717_, p_369406_, p_368331_);
        Vec3[] avec3 = p_362717_.m_32939_(p_368331_);
        p_369406_.f_346799_ = Arrays.copyOf(avec3, avec3.length);
        p_369406_.f_349372_ = p_362717_.m_33736_();
    }

    public void m_7392_(IllusionerRenderState p_369374_, PoseStack p_114932_, MultiBufferSource p_114933_, int p_114934_) {
        if (p_369374_.f_347933_) {
            Vec3[] avec3 = p_369374_.f_346799_;

            for (int i = 0; i < avec3.length; i++) {
                p_114932_.m_85836_();
                p_114932_.m_85837_(
                    avec3[i].f_82479_ + (double)Mth.m_14089_((float)i + p_369374_.f_349307_ * 0.5F) * 0.025,
                    avec3[i].f_82480_ + (double)Mth.m_14089_((float)i + p_369374_.f_349307_ * 0.75F) * 0.0125,
                    avec3[i].f_82481_ + (double)Mth.m_14089_((float)i + p_369374_.f_349307_ * 0.7F) * 0.025
                );
                super.m_7392_(p_369374_, p_114932_, p_114933_, p_114934_);
                p_114932_.m_85849_();
            }
        } else {
            super.m_7392_(p_369374_, p_114932_, p_114933_, p_114934_);
        }
    }

    protected boolean m_5933_(IllusionerRenderState p_361370_) {
        return true;
    }

    protected AABB m_352235_(Illusioner p_365734_) {
        return super.m_352235_(p_365734_).m_82377_(3.0, 0.0, 3.0);
    }
}