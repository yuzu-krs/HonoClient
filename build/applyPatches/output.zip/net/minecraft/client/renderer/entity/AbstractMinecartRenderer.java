package net.minecraft.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.Objects;
import net.minecraft.client.model.MinecartModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.state.MinecartRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.entity.vehicle.NewMinecartBehavior;
import net.minecraft.world.entity.vehicle.OldMinecartBehavior;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class AbstractMinecartRenderer<T extends AbstractMinecart, S extends MinecartRenderState> extends EntityRenderer<T, S> {
    private static final ResourceLocation f_346332_ = ResourceLocation.m_340282_("textures/entity/minecart.png");
    protected final MinecartModel f_349247_;
    private final BlockRenderDispatcher f_348289_;

    public AbstractMinecartRenderer(EntityRendererProvider.Context p_369922_, ModelLayerLocation p_364230_) {
        super(p_369922_);
        this.f_114477_ = 0.7F;
        this.f_349247_ = new MinecartModel(p_369922_.m_174023_(p_364230_));
        this.f_348289_ = p_369922_.m_234597_();
    }

    public void m_7392_(S p_361135_, PoseStack p_366647_, MultiBufferSource p_368030_, int p_370214_) {
        super.m_7392_(p_361135_, p_366647_, p_368030_, p_370214_);
        p_366647_.m_85836_();
        long i = p_361135_.f_347251_;
        float f = (((float)(i >> 16 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
        float f1 = (((float)(i >> 20 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
        float f2 = (((float)(i >> 24 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
        p_366647_.m_252880_(f, f1, f2);
        if (p_361135_.f_349546_) {
            m_354635_(p_361135_, p_366647_);
        } else {
            m_356207_(p_361135_, p_366647_);
        }

        float f3 = p_361135_.f_349478_;
        if (f3 > 0.0F) {
            p_366647_.m_252781_(Axis.f_252529_.m_252977_(Mth.m_14031_(f3) * f3 * p_361135_.f_346622_ / 10.0F * (float)p_361135_.f_349067_));
        }

        BlockState blockstate = p_361135_.f_346987_;
        if (blockstate.m_60799_() != RenderShape.INVISIBLE) {
            p_366647_.m_85836_();
            float f4 = 0.75F;
            p_366647_.m_85841_(0.75F, 0.75F, 0.75F);
            p_366647_.m_252880_(-0.5F, (float)(p_361135_.f_347272_ - 8) / 16.0F, 0.5F);
            p_366647_.m_252781_(Axis.f_252436_.m_252977_(90.0F));
            this.m_116143_(p_361135_, blockstate, p_366647_, p_368030_, p_370214_);
            p_366647_.m_85849_();
        }

        p_366647_.m_85841_(-1.0F, -1.0F, 1.0F);
        this.f_349247_.m_6973_(p_361135_);
        VertexConsumer vertexconsumer = p_368030_.m_6299_(this.f_349247_.m_103119_(f_346332_));
        this.f_349247_.m_340227_(p_366647_, vertexconsumer, p_370214_, OverlayTexture.f_118083_);
        p_366647_.m_85849_();
    }

    private static <S extends MinecartRenderState> void m_354635_(S p_369039_, PoseStack p_366808_) {
        p_366808_.m_252781_(Axis.f_252436_.m_252977_(p_369039_.f_347107_));
        p_366808_.m_252781_(Axis.f_252403_.m_252977_(-p_369039_.f_347281_));
        p_366808_.m_252880_(0.0F, 0.375F, 0.0F);
    }

    private static <S extends MinecartRenderState> void m_356207_(S p_364306_, PoseStack p_367729_) {
        double d0 = p_364306_.f_347120_;
        double d1 = p_364306_.f_347132_;
        double d2 = p_364306_.f_348762_;
        float f = p_364306_.f_347281_;
        float f1 = p_364306_.f_347107_;
        if (p_364306_.f_348277_ != null && p_364306_.f_347880_ != null && p_364306_.f_348578_ != null) {
            Vec3 vec3 = p_364306_.f_347880_;
            Vec3 vec31 = p_364306_.f_348578_;
            p_367729_.m_85837_(p_364306_.f_348277_.f_82479_ - d0, (vec3.f_82480_ + vec31.f_82480_) / 2.0 - d1, p_364306_.f_348277_.f_82481_ - d2);
            Vec3 vec32 = vec31.m_82520_(-vec3.f_82479_, -vec3.f_82480_, -vec3.f_82481_);
            if (vec32.m_82553_() != 0.0) {
                vec32 = vec32.m_82541_();
                f1 = (float)(Math.atan2(vec32.f_82481_, vec32.f_82479_) * 180.0 / Math.PI);
                f = (float)(Math.atan(vec32.f_82480_) * 73.0);
            }
        }

        p_367729_.m_252880_(0.0F, 0.375F, 0.0F);
        p_367729_.m_252781_(Axis.f_252436_.m_252977_(180.0F - f1));
        p_367729_.m_252781_(Axis.f_252403_.m_252977_(-f));
    }

    public void m_351578_(T p_369176_, S p_364445_, float p_364174_) {
        super.m_351578_(p_369176_, p_364445_, p_364174_);
        if (p_369176_.m_356823_() instanceof NewMinecartBehavior newminecartbehavior) {
            m_354901_(p_369176_, newminecartbehavior, p_364445_, p_364174_);
            p_364445_.f_349546_ = true;
        } else if (p_369176_.m_356823_() instanceof OldMinecartBehavior oldminecartbehavior) {
            m_353643_(p_369176_, oldminecartbehavior, p_364445_, p_364174_);
            p_364445_.f_349546_ = false;
        }

        long i = (long)p_369176_.m_19879_() * 493286711L;
        p_364445_.f_347251_ = i * i * 4392167121L + i * 98761L;
        p_364445_.f_349478_ = (float)p_369176_.m_305464_() - p_364174_;
        p_364445_.f_349067_ = p_369176_.m_305195_();
        p_364445_.f_346622_ = Math.max(p_369176_.m_304923_() - p_364174_, 0.0F);
        p_364445_.f_347272_ = p_369176_.m_38183_();
        p_364445_.f_346987_ = p_369176_.m_38178_();
    }

    private static <T extends AbstractMinecart, S extends MinecartRenderState> void m_354901_(
        T p_366236_, NewMinecartBehavior p_366892_, S p_367623_, float p_365529_
    ) {
        if (p_366892_.m_353028_()) {
            p_367623_.f_349414_ = p_366892_.m_354067_(p_365529_);
            p_367623_.f_347281_ = p_366892_.m_354419_(p_365529_);
            p_367623_.f_347107_ = p_366892_.m_352055_(p_365529_);
        } else {
            p_367623_.f_349414_ = null;
            p_367623_.f_347281_ = p_366236_.m_146909_();
            p_367623_.f_347107_ = p_366236_.m_146908_();
        }
    }

    private static <T extends AbstractMinecart, S extends MinecartRenderState> void m_353643_(
        T p_367481_, OldMinecartBehavior p_362885_, S p_368073_, float p_362159_
    ) {
        float f = 0.3F;
        p_368073_.f_347281_ = p_367481_.m_356829_(p_362159_);
        p_368073_.f_347107_ = p_367481_.m_352577_(p_362159_);
        double d0 = p_368073_.f_347120_;
        double d1 = p_368073_.f_347132_;
        double d2 = p_368073_.f_348762_;
        Vec3 vec3 = p_362885_.m_351822_(d0, d1, d2);
        if (vec3 != null) {
            p_368073_.f_348277_ = vec3;
            Vec3 vec31 = p_362885_.m_355656_(d0, d1, d2, 0.3F);
            Vec3 vec32 = p_362885_.m_355656_(d0, d1, d2, -0.3F);
            p_368073_.f_347880_ = Objects.requireNonNullElse(vec31, vec3);
            p_368073_.f_348578_ = Objects.requireNonNullElse(vec32, vec3);
        } else {
            p_368073_.f_348277_ = null;
            p_368073_.f_347880_ = null;
            p_368073_.f_348578_ = null;
        }
    }

    protected void m_116143_(S p_361290_, BlockState p_362203_, PoseStack p_367440_, MultiBufferSource p_368595_, int p_366033_) {
        this.f_348289_.m_110912_(p_362203_, p_367440_, p_368595_, p_366033_, OverlayTexture.f_118083_);
    }

    protected AABB m_352235_(T p_363708_) {
        AABB aabb = super.m_352235_(p_363708_);
        return p_363708_.m_38184_() ? aabb.m_82400_((double)Math.abs(p_363708_.m_38183_()) / 16.0) : aabb;
    }

    public Vec3 m_7860_(S p_367749_) {
        Vec3 vec3 = super.m_7860_(p_367749_);
        return p_367749_.f_349546_ && p_367749_.f_349414_ != null
            ? vec3.m_82520_(
                p_367749_.f_349414_.f_82479_ - p_367749_.f_347120_,
                p_367749_.f_349414_.f_82480_ - p_367749_.f_347132_,
                p_367749_.f_349414_.f_82481_ - p_367749_.f_348762_
            )
            : vec3;
    }
}