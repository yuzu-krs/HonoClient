package net.minecraft.client.renderer.entity.layers;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.CowModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.state.MushroomCowRenderState;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class MushroomCowMushroomLayer extends RenderLayer<MushroomCowRenderState, CowModel> {
    private final BlockRenderDispatcher f_234848_;

    public MushroomCowMushroomLayer(RenderLayerParent<MushroomCowRenderState, CowModel> p_234850_, BlockRenderDispatcher p_234851_) {
        super(p_234850_);
        this.f_234848_ = p_234851_;
    }

    public void m_6494_(PoseStack p_117256_, MultiBufferSource p_117257_, int p_117258_, MushroomCowRenderState p_367819_, float p_117260_, float p_117261_) {
        if (!p_367819_.f_348880_) {
            boolean flag = p_367819_.f_348590_ && p_367819_.f_347933_;
            if (!p_367819_.f_347933_ || flag) {
                BlockState blockstate = p_367819_.f_346942_.m_354193_();
                int i = LivingEntityRenderer.m_115338_(p_367819_, 0.0F);
                BakedModel bakedmodel = this.f_234848_.m_110910_(blockstate);
                p_117256_.m_85836_();
                p_117256_.m_252880_(0.2F, -0.35F, 0.5F);
                p_117256_.m_252781_(Axis.f_252436_.m_252977_(-48.0F));
                p_117256_.m_85841_(-1.0F, -1.0F, 1.0F);
                p_117256_.m_252880_(-0.5F, -0.5F, -0.5F);
                this.m_234852_(p_117256_, p_117257_, p_117258_, flag, blockstate, i, bakedmodel);
                p_117256_.m_85849_();
                p_117256_.m_85836_();
                p_117256_.m_252880_(0.2F, -0.35F, 0.5F);
                p_117256_.m_252781_(Axis.f_252436_.m_252977_(42.0F));
                p_117256_.m_252880_(0.1F, 0.0F, -0.6F);
                p_117256_.m_252781_(Axis.f_252436_.m_252977_(-48.0F));
                p_117256_.m_85841_(-1.0F, -1.0F, 1.0F);
                p_117256_.m_252880_(-0.5F, -0.5F, -0.5F);
                this.m_234852_(p_117256_, p_117257_, p_117258_, flag, blockstate, i, bakedmodel);
                p_117256_.m_85849_();
                p_117256_.m_85836_();
                this.m_117386_().m_102450_().m_104299_(p_117256_);
                p_117256_.m_252880_(0.0F, -0.7F, -0.2F);
                p_117256_.m_252781_(Axis.f_252436_.m_252977_(-78.0F));
                p_117256_.m_85841_(-1.0F, -1.0F, 1.0F);
                p_117256_.m_252880_(-0.5F, -0.5F, -0.5F);
                this.m_234852_(p_117256_, p_117257_, p_117258_, flag, blockstate, i, bakedmodel);
                p_117256_.m_85849_();
            }
        }
    }

    private void m_234852_(
        PoseStack p_234853_, MultiBufferSource p_234854_, int p_234855_, boolean p_234856_, BlockState p_234857_, int p_234858_, BakedModel p_234859_
    ) {
        if (p_234856_) {
            this.f_234848_
                .m_110937_()
                .m_111067_(
                    p_234853_.m_85850_(),
                    p_234854_.m_6299_(RenderType.m_110491_(TextureAtlas.f_118259_)),
                    p_234857_,
                    p_234859_,
                    0.0F,
                    0.0F,
                    0.0F,
                    p_234855_,
                    p_234858_
                );
        } else {
            this.f_234848_.m_110912_(p_234857_, p_234853_, p_234854_, p_234855_, p_234858_);
        }
    }
}