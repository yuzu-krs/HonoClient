package net.minecraft.client.renderer.entity;

import net.minecraft.client.model.OcelotModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.state.FelineRenderState;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.animal.Ocelot;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class OcelotRenderer extends AgeableMobRenderer<Ocelot, FelineRenderState, OcelotModel> {
    private static final ResourceLocation f_115517_ = ResourceLocation.m_340282_("textures/entity/cat/ocelot.png");

    public OcelotRenderer(EntityRendererProvider.Context p_174330_) {
        super(p_174330_, new OcelotModel(p_174330_.m_174023_(ModelLayers.f_171201_)), new OcelotModel(p_174330_.m_174023_(ModelLayers.f_347975_)), 0.4F);
    }

    public ResourceLocation m_113764_(FelineRenderState p_368921_) {
        return f_115517_;
    }

    public FelineRenderState m_5478_() {
        return new FelineRenderState();
    }

    public void m_351578_(Ocelot p_364123_, FelineRenderState p_367316_, float p_369664_) {
        super.m_351578_(p_364123_, p_367316_, p_369664_);
        p_367316_.f_347985_ = p_364123_.m_6047_();
        p_367316_.f_348723_ = p_364123_.m_20142_();
    }
}