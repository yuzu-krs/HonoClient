package net.minecraft.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.WindChargeModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.projectile.windcharge.AbstractWindCharge;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class WindChargeRenderer extends EntityRenderer<AbstractWindCharge, EntityRenderState> {
    private static final ResourceLocation f_303353_ = ResourceLocation.m_340282_("textures/entity/projectiles/wind_charge.png");
    private final WindChargeModel f_302630_;

    public WindChargeRenderer(EntityRendererProvider.Context p_311606_) {
        super(p_311606_);
        this.f_302630_ = new WindChargeModel(p_311606_.m_174023_(ModelLayers.f_303259_));
    }

    @Override
    public void m_7392_(EntityRenderState p_369820_, PoseStack p_312831_, MultiBufferSource p_311698_, int p_311600_) {
        VertexConsumer vertexconsumer = p_311698_.m_6299_(RenderType.m_305520_(f_303353_, this.m_307386_(p_369820_.f_349307_) % 1.0F, 0.0F));
        this.f_302630_.m_6973_(p_369820_);
        this.f_302630_.m_340227_(p_312831_, vertexconsumer, p_311600_, OverlayTexture.f_118083_);
        super.m_7392_(p_369820_, p_312831_, p_311698_, p_311600_);
    }

    protected float m_307386_(float p_311672_) {
        return p_311672_ * 0.03F;
    }

    @Override
    public EntityRenderState m_5478_() {
        return new EntityRenderState();
    }
}