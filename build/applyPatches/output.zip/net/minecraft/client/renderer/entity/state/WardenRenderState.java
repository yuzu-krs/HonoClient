package net.minecraft.client.renderer.entity.state;

import net.minecraft.world.entity.AnimationState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class WardenRenderState extends LivingEntityRenderState {
    public float f_346518_;
    public float f_347259_;
    public final AnimationState f_346265_ = new AnimationState();
    public final AnimationState f_348367_ = new AnimationState();
    public final AnimationState f_348040_ = new AnimationState();
    public final AnimationState f_349480_ = new AnimationState();
    public final AnimationState f_347596_ = new AnimationState();
    public final AnimationState f_346312_ = new AnimationState();
}