package net.minecraft.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.CodModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.animal.Cod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class CodRenderer extends MobRenderer<Cod, LivingEntityRenderState, CodModel> {
    private static final ResourceLocation f_114002_ = ResourceLocation.m_340282_("textures/entity/fish/cod.png");

    public CodRenderer(EntityRendererProvider.Context p_173954_) {
        super(p_173954_, new CodModel(p_173954_.m_174023_(ModelLayers.f_171278_)), 0.3F);
    }

    @Override
    public ResourceLocation m_113764_(LivingEntityRenderState p_368865_) {
        return f_114002_;
    }

    public LivingEntityRenderState m_5478_() {
        return new LivingEntityRenderState();
    }

    @Override
    protected void m_7523_(LivingEntityRenderState p_368017_, PoseStack p_114010_, float p_114011_, float p_114012_) {
        super.m_7523_(p_368017_, p_114010_, p_114011_, p_114012_);
        float f = 4.3F * Mth.m_14031_(0.6F * p_368017_.f_349307_);
        p_114010_.m_252781_(Axis.f_252436_.m_252977_(f));
        if (!p_368017_.f_346463_) {
            p_114010_.m_252880_(0.1F, 0.1F, -0.1F);
            p_114010_.m_252781_(Axis.f_252403_.m_252977_(90.0F));
        }
    }
}