package net.minecraft.client.renderer.entity.state;

import net.minecraft.world.entity.AnimationState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ArmadilloRenderState extends LivingEntityRenderState {
    public boolean f_347865_;
    public final AnimationState f_348030_ = new AnimationState();
    public final AnimationState f_346457_ = new AnimationState();
    public final AnimationState f_348299_ = new AnimationState();
}