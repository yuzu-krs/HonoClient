package net.minecraft.client.renderer.debug;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.mojang.blaze3d.vertex.PoseStack;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Position;
import net.minecraft.network.protocol.common.custom.BeeDebugPayload;
import net.minecraft.network.protocol.common.custom.HiveDebugPayload;
import net.minecraft.network.protocol.game.DebugEntityNameGenerator;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class BeeDebugRenderer implements DebugRenderer.SimpleDebugRenderer {
    private static final boolean f_173737_ = true;
    private static final boolean f_173738_ = true;
    private static final boolean f_173739_ = true;
    private static final boolean f_173740_ = true;
    private static final boolean f_173741_ = true;
    private static final boolean f_173742_ = false;
    private static final boolean f_173743_ = true;
    private static final boolean f_173744_ = true;
    private static final boolean f_173745_ = true;
    private static final boolean f_173746_ = true;
    private static final boolean f_173747_ = true;
    private static final boolean f_173748_ = true;
    private static final boolean f_173749_ = true;
    private static final boolean f_173750_ = true;
    private static final int f_173751_ = 30;
    private static final int f_173752_ = 30;
    private static final int f_173753_ = 8;
    private static final int f_173754_ = 20;
    private static final float f_173755_ = 0.02F;
    private static final int f_173758_ = -23296;
    private static final int f_173760_ = -3355444;
    private static final int f_173761_ = -98404;
    private final Minecraft f_113048_;
    private final Map<BlockPos, BeeDebugRenderer.HiveDebugInfo> f_113049_ = new HashMap<>();
    private final Map<UUID, BeeDebugPayload.BeeInfo> f_113050_ = new HashMap<>();
    @Nullable
    private UUID f_113051_;

    public BeeDebugRenderer(Minecraft p_113053_) {
        this.f_113048_ = p_113053_;
    }

    @Override
    public void m_5630_() {
        this.f_113049_.clear();
        this.f_113050_.clear();
        this.f_113051_ = null;
    }

    public void m_113071_(HiveDebugPayload.HiveInfo p_299034_, long p_298824_) {
        this.f_113049_.put(p_299034_.f_291379_(), new BeeDebugRenderer.HiveDebugInfo(p_299034_, p_298824_));
    }

    public void m_113066_(BeeDebugPayload.BeeInfo p_300160_) {
        this.f_113050_.put(p_300160_.f_290845_(), p_300160_);
    }

    public void m_173763_(int p_173764_) {
        this.f_113050_.values().removeIf(p_296269_ -> p_296269_.f_291027_() == p_173764_);
    }

    @Override
    public void m_7790_(PoseStack p_113061_, MultiBufferSource p_113062_, double p_113063_, double p_113064_, double p_113065_) {
        this.m_113136_();
        this.m_113126_();
        this.m_269283_(p_113061_, p_113062_);
        if (!this.f_113048_.f_91074_.m_5833_()) {
            this.m_113156_();
        }
    }

    private void m_113126_() {
        this.f_113050_.entrySet().removeIf(p_296260_ -> this.f_113048_.f_91073_.m_6815_(p_296260_.getValue().f_291027_()) == null);
    }

    private void m_113136_() {
        long i = this.f_113048_.f_91073_.m_46467_() - 20L;
        this.f_113049_.entrySet().removeIf(p_296254_ -> p_296254_.getValue().f_290738_() < i);
    }

    private void m_269283_(PoseStack p_270886_, MultiBufferSource p_270808_) {
        BlockPos blockpos = this.m_113154_().m_90588_();
        this.f_113050_.values().forEach(p_296263_ -> {
            if (this.m_113147_(p_296263_)) {
                this.m_269284_(p_270886_, p_270808_, p_296263_);
            }
        });
        this.m_269561_(p_270886_, p_270808_);

        for (BlockPos blockpos1 : this.f_113049_.keySet()) {
            if (blockpos.m_123314_(blockpos1, 30.0)) {
                m_269172_(p_270886_, p_270808_, blockpos1);
            }
        }

        Map<BlockPos, Set<UUID>> map = this.m_113146_();
        this.f_113049_.values().forEach(p_296259_ -> {
            if (blockpos.m_123314_(p_296259_.f_290863_.f_291379_(), 30.0)) {
                Set<UUID> set = map.get(p_296259_.f_290863_.f_291379_());
                this.m_269169_(p_270886_, p_270808_, p_296259_.f_290863_, (Collection<UUID>)(set == null ? Sets.newHashSet() : set));
            }
        });
        this.m_113155_().forEach((p_269699_, p_269700_) -> {
            if (blockpos.m_123314_(p_269699_, 30.0)) {
                this.m_269584_(p_270886_, p_270808_, p_269699_, (List<String>)p_269700_);
            }
        });
    }

    private Map<BlockPos, Set<UUID>> m_113146_() {
        Map<BlockPos, Set<UUID>> map = Maps.newHashMap();
        this.f_113050_
            .values()
            .forEach(
                p_296271_ -> p_296271_.f_291314_()
                        .forEach(p_296274_ -> map.computeIfAbsent(p_296274_, p_173777_ -> Sets.newHashSet()).add(p_296271_.f_290845_()))
            );
        return map;
    }

    private void m_269561_(PoseStack p_270578_, MultiBufferSource p_270098_) {
        Map<BlockPos, Set<UUID>> map = Maps.newHashMap();
        this.f_113050_.values().forEach(p_296251_ -> {
            if (p_296251_.f_291765_() != null) {
                map.computeIfAbsent(p_296251_.f_291765_(), p_296252_ -> new HashSet<>()).add(p_296251_.f_290845_());
            }
        });
        map.forEach((p_325526_, p_325527_) -> {
            Set<String> set = p_325527_.stream().map(DebugEntityNameGenerator::m_133668_).collect(Collectors.toSet());
            int i = 1;
            m_269380_(p_270578_, p_270098_, set.toString(), p_325526_, i++, -256);
            m_269380_(p_270578_, p_270098_, "Flower", p_325526_, i++, -1);
            float f = 0.05F;
            DebugRenderer.m_269371_(p_270578_, p_270098_, p_325526_, 0.05F, 0.8F, 0.8F, 0.0F, 0.3F);
        });
    }

    private static String m_113115_(Collection<UUID> p_113116_) {
        if (p_113116_.isEmpty()) {
            return "-";
        } else {
            return p_113116_.size() > 3
                ? p_113116_.size() + " bees"
                : p_113116_.stream().map(DebugEntityNameGenerator::m_133668_).collect(Collectors.toSet()).toString();
        }
    }

    private static void m_269172_(PoseStack p_270133_, MultiBufferSource p_270766_, BlockPos p_270687_) {
        float f = 0.05F;
        DebugRenderer.m_269371_(p_270133_, p_270766_, p_270687_, 0.05F, 0.2F, 0.2F, 1.0F, 0.3F);
    }

    private void m_269584_(PoseStack p_270949_, MultiBufferSource p_270718_, BlockPos p_270550_, List<String> p_270221_) {
        float f = 0.05F;
        DebugRenderer.m_269371_(p_270949_, p_270718_, p_270550_, 0.05F, 0.2F, 0.2F, 1.0F, 0.3F);
        m_269380_(p_270949_, p_270718_, p_270221_ + "", p_270550_, 0, -256);
        m_269380_(p_270949_, p_270718_, "Ghost Hive", p_270550_, 1, -65536);
    }

    private void m_269169_(PoseStack p_270194_, MultiBufferSource p_270431_, HiveDebugPayload.HiveInfo p_297933_, Collection<UUID> p_270946_) {
        int i = 0;
        if (!p_270946_.isEmpty()) {
            m_269057_(p_270194_, p_270431_, "Blacklisted by " + m_113115_(p_270946_), p_297933_, i++, -65536);
        }

        m_269057_(p_270194_, p_270431_, "Out: " + m_113115_(this.m_113129_(p_297933_.f_291379_())), p_297933_, i++, -3355444);
        if (p_297933_.f_291892_() == 0) {
            m_269057_(p_270194_, p_270431_, "In: -", p_297933_, i++, -256);
        } else if (p_297933_.f_291892_() == 1) {
            m_269057_(p_270194_, p_270431_, "In: 1 bee", p_297933_, i++, -256);
        } else {
            m_269057_(p_270194_, p_270431_, "In: " + p_297933_.f_291892_() + " bees", p_297933_, i++, -256);
        }

        m_269057_(p_270194_, p_270431_, "Honey: " + p_297933_.f_290594_(), p_297933_, i++, -23296);
        m_269057_(p_270194_, p_270431_, p_297933_.f_290820_() + (p_297933_.f_291612_() ? " (sedated)" : ""), p_297933_, i++, -1);
    }

    private void m_269467_(PoseStack p_270424_, MultiBufferSource p_270123_, BeeDebugPayload.BeeInfo p_299438_) {
        if (p_299438_.f_290619_() != null) {
            PathfindingRenderer.m_269027_(
                p_270424_,
                p_270123_,
                p_299438_.f_290619_(),
                0.5F,
                false,
                false,
                this.m_113154_().m_90583_().m_7096_(),
                this.m_113154_().m_90583_().m_7098_(),
                this.m_113154_().m_90583_().m_7094_()
            );
        }
    }

    private void m_269284_(PoseStack p_270154_, MultiBufferSource p_270397_, BeeDebugPayload.BeeInfo p_299435_) {
        boolean flag = this.m_113142_(p_299435_);
        int i = 0;
        m_269015_(p_270154_, p_270397_, p_299435_.f_290637_(), i++, p_299435_.toString(), -1, 0.03F);
        if (p_299435_.f_290544_() == null) {
            m_269015_(p_270154_, p_270397_, p_299435_.f_290637_(), i++, "No hive", -98404, 0.02F);
        } else {
            m_269015_(p_270154_, p_270397_, p_299435_.f_290637_(), i++, "Hive: " + this.m_113068_(p_299435_, p_299435_.f_290544_()), -256, 0.02F);
        }

        if (p_299435_.f_291765_() == null) {
            m_269015_(p_270154_, p_270397_, p_299435_.f_290637_(), i++, "No flower", -98404, 0.02F);
        } else {
            m_269015_(p_270154_, p_270397_, p_299435_.f_290637_(), i++, "Flower: " + this.m_113068_(p_299435_, p_299435_.f_291765_()), -256, 0.02F);
        }

        for (String s : p_299435_.f_291620_()) {
            m_269015_(p_270154_, p_270397_, p_299435_.f_290637_(), i++, s, -16711936, 0.02F);
        }

        if (flag) {
            this.m_269467_(p_270154_, p_270397_, p_299435_);
        }

        if (p_299435_.f_291807_() > 0) {
            int j = p_299435_.f_291807_() < 2400 ? -3355444 : -23296;
            m_269015_(p_270154_, p_270397_, p_299435_.f_290637_(), i++, "Travelling: " + p_299435_.f_291807_() + " ticks", j, 0.02F);
        }
    }

    private static void m_269057_(
        PoseStack p_270915_, MultiBufferSource p_270663_, String p_270119_, HiveDebugPayload.HiveInfo p_300591_, int p_270930_, int p_270094_
    ) {
        m_269380_(p_270915_, p_270663_, p_270119_, p_300591_.f_291379_(), p_270930_, p_270094_);
    }

    private static void m_269380_(PoseStack p_270438_, MultiBufferSource p_270244_, String p_270486_, BlockPos p_270062_, int p_270574_, int p_270228_) {
        double d0 = 1.3;
        double d1 = 0.2;
        double d2 = (double)p_270062_.m_123341_() + 0.5;
        double d3 = (double)p_270062_.m_123342_() + 1.3 + (double)p_270574_ * 0.2;
        double d4 = (double)p_270062_.m_123343_() + 0.5;
        DebugRenderer.m_269439_(p_270438_, p_270244_, p_270486_, d2, d3, d4, p_270228_, 0.02F, true, 0.0F, true);
    }

    private static void m_269015_(
        PoseStack p_270426_, MultiBufferSource p_270600_, Position p_270548_, int p_270592_, String p_270198_, int p_270792_, float p_270938_
    ) {
        double d0 = 2.4;
        double d1 = 0.25;
        BlockPos blockpos = BlockPos.m_274446_(p_270548_);
        double d2 = (double)blockpos.m_123341_() + 0.5;
        double d3 = p_270548_.m_7098_() + 2.4 + (double)p_270592_ * 0.25;
        double d4 = (double)blockpos.m_123343_() + 0.5;
        float f = 0.5F;
        DebugRenderer.m_269439_(p_270426_, p_270600_, p_270198_, d2, d3, d4, p_270792_, p_270938_, false, 0.5F, true);
    }

    private Camera m_113154_() {
        return this.f_113048_.f_91063_.m_109153_();
    }

    private Set<String> m_173772_(HiveDebugPayload.HiveInfo p_298287_) {
        return this.m_113129_(p_298287_.f_291379_()).stream().map(DebugEntityNameGenerator::m_133668_).collect(Collectors.toSet());
    }

    private String m_113068_(BeeDebugPayload.BeeInfo p_300427_, BlockPos p_113070_) {
        double d0 = Math.sqrt(p_113070_.m_203193_(p_300427_.f_290637_()));
        double d1 = (double)Math.round(d0 * 10.0) / 10.0;
        return p_113070_.m_123344_() + " (dist " + d1 + ")";
    }

    private boolean m_113142_(BeeDebugPayload.BeeInfo p_298081_) {
        return Objects.equals(this.f_113051_, p_298081_.f_290845_());
    }

    private boolean m_113147_(BeeDebugPayload.BeeInfo p_300675_) {
        Player player = this.f_113048_.f_91074_;
        BlockPos blockpos = BlockPos.m_274561_(player.m_20185_(), p_300675_.f_290637_().m_7098_(), player.m_20189_());
        BlockPos blockpos1 = BlockPos.m_274446_(p_300675_.f_290637_());
        return blockpos.m_123314_(blockpos1, 30.0);
    }

    private Collection<UUID> m_113129_(BlockPos p_113130_) {
        return this.f_113050_
            .values()
            .stream()
            .filter(p_296249_ -> p_296249_.m_293397_(p_113130_))
            .map(BeeDebugPayload.BeeInfo::f_290845_)
            .collect(Collectors.toSet());
    }

    private Map<BlockPos, List<String>> m_113155_() {
        Map<BlockPos, List<String>> map = Maps.newHashMap();

        for (BeeDebugPayload.BeeInfo beedebugpayload$beeinfo : this.f_113050_.values()) {
            if (beedebugpayload$beeinfo.f_290544_() != null && !this.f_113049_.containsKey(beedebugpayload$beeinfo.f_290544_())) {
                map.computeIfAbsent(beedebugpayload$beeinfo.f_290544_(), p_113140_ -> Lists.newArrayList()).add(beedebugpayload$beeinfo.m_292788_());
            }
        }

        return map;
    }

    private void m_113156_() {
        DebugRenderer.m_113448_(this.f_113048_.m_91288_(), 8).ifPresent(p_113059_ -> this.f_113051_ = p_113059_.m_20148_());
    }

    @OnlyIn(Dist.CLIENT)
    static record HiveDebugInfo(HiveDebugPayload.HiveInfo f_290863_, long f_290738_) {
    }
}