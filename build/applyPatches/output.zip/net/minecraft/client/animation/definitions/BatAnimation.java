package net.minecraft.client.animation.definitions;

import net.minecraft.client.animation.AnimationChannel;
import net.minecraft.client.animation.AnimationDefinition;
import net.minecraft.client.animation.Keyframe;
import net.minecraft.client.animation.KeyframeAnimations;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class BatAnimation {
    public static final AnimationDefinition f_302981_ = AnimationDefinition.Builder.m_232275_(0.5F)
        .m_232274_()
        .m_232279_(
            "head",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(180.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "head",
            new AnimationChannel(
                AnimationChannel.Targets.f_232250_,
                new Keyframe(0.0F, KeyframeAnimations.m_253126_(0.0F, 0.5F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "body",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(180.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "body",
            new AnimationChannel(
                AnimationChannel.Targets.f_232250_,
                new Keyframe(0.0F, KeyframeAnimations.m_253126_(0.0F, 0.5F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "feet",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "right_wing",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "right_wing",
            new AnimationChannel(
                AnimationChannel.Targets.f_232250_,
                new Keyframe(0.0F, KeyframeAnimations.m_253126_(0.0F, 0.0F, 1.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "right_wing_tip",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(0.0F, -120.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "left_wing",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "left_wing",
            new AnimationChannel(
                AnimationChannel.Targets.f_232250_,
                new Keyframe(0.0F, KeyframeAnimations.m_253126_(0.0F, 0.0F, 1.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "left_wing_tip",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(0.0F, 120.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232282_();
    public static final AnimationDefinition f_302773_ = AnimationDefinition.Builder.m_232275_(0.5F)
        .m_232274_()
        .m_232279_(
            "head",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.125F, KeyframeAnimations.m_253186_(20.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.5F, KeyframeAnimations.m_253186_(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "head",
            new AnimationChannel(
                AnimationChannel.Targets.f_232250_,
                new Keyframe(0.0F, KeyframeAnimations.m_253126_(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.125F, KeyframeAnimations.m_253126_(0.0F, 2.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.25F, KeyframeAnimations.m_253126_(0.0F, 1.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.375F, KeyframeAnimations.m_253126_(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.4583F, KeyframeAnimations.m_253126_(0.0F, -1.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.5F, KeyframeAnimations.m_253126_(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "body",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(40.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.25F, KeyframeAnimations.m_253186_(52.5F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.5F, KeyframeAnimations.m_253186_(40.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "body",
            new AnimationChannel(
                AnimationChannel.Targets.f_232250_,
                new Keyframe(0.0F, KeyframeAnimations.m_253126_(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.125F, KeyframeAnimations.m_253126_(0.0F, 2.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.25F, KeyframeAnimations.m_253126_(0.0F, 1.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.375F, KeyframeAnimations.m_253126_(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.4583F, KeyframeAnimations.m_253126_(0.0F, -1.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.5F, KeyframeAnimations.m_253126_(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "feet",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(10.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.125F, KeyframeAnimations.m_253186_(-21.25F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.25F, KeyframeAnimations.m_253186_(-12.5F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.5F, KeyframeAnimations.m_253186_(10.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "right_wing",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(0.0F, 85.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.125F, KeyframeAnimations.m_253186_(0.0F, -55.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.25F, KeyframeAnimations.m_253186_(0.0F, 50.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.375F, KeyframeAnimations.m_253186_(0.0F, 70.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.5F, KeyframeAnimations.m_253186_(0.0F, 85.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "right_wing_tip",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(0.0F, 10.5F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.0417F, KeyframeAnimations.m_253186_(0.0F, 65.5F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.2083F, KeyframeAnimations.m_253186_(0.0F, -135.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.5F, KeyframeAnimations.m_253186_(0.0F, 10.5F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "left_wing",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(0.0F, -85.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.125F, KeyframeAnimations.m_253186_(0.0F, 55.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.25F, KeyframeAnimations.m_253186_(0.0F, -50.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.375F, KeyframeAnimations.m_253186_(0.0F, -70.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.5F, KeyframeAnimations.m_253186_(0.0F, -85.0F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232279_(
            "left_wing_tip",
            new AnimationChannel(
                AnimationChannel.Targets.f_232251_,
                new Keyframe(0.0F, KeyframeAnimations.m_253186_(0.0F, -10.5F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.0417F, KeyframeAnimations.m_253186_(0.0F, -65.5F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.2083F, KeyframeAnimations.m_253186_(0.0F, 135.0F, 0.0F), AnimationChannel.Interpolations.f_232229_),
                new Keyframe(0.5F, KeyframeAnimations.m_253186_(0.0F, -10.5F, 0.0F), AnimationChannel.Interpolations.f_232229_)
            )
        )
        .m_232282_();
}