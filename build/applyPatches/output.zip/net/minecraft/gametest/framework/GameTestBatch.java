package net.minecraft.gametest.framework;

import java.util.Collection;
import java.util.function.Consumer;
import net.minecraft.server.level.ServerLevel;

public record GameTestBatch(String f_127539_, Collection<GameTestInfo> f_314676_, Consumer<ServerLevel> f_127541_, Consumer<ServerLevel> f_177057_) {
    public static final String f_177056_ = "defaultBatch";

    public GameTestBatch(String f_127539_, Collection<GameTestInfo> f_314676_, Consumer<ServerLevel> f_127541_, Consumer<ServerLevel> f_177057_) {
        if (f_314676_.isEmpty()) {
            throw new IllegalArgumentException("A GameTestBatch must include at least one GameTestInfo!");
        } else {
            this.f_127539_ = f_127539_;
            this.f_314676_ = f_314676_;
            this.f_127541_ = f_127541_;
            this.f_177057_ = f_177057_;
        }
    }
}