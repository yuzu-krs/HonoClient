package net.minecraft.data.info;

import com.mojang.brigadier.CommandDispatcher;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.synchronization.ArgumentUtils;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;

public class CommandsReport implements DataProvider {
    private final PackOutput f_244606_;
    private final CompletableFuture<HolderLookup.Provider> f_254639_;

    public CommandsReport(PackOutput p_256167_, CompletableFuture<HolderLookup.Provider> p_256506_) {
        this.f_244606_ = p_256167_;
        this.f_254639_ = p_256506_;
    }

    @Override
    public CompletableFuture<?> m_213708_(CachedOutput p_253721_) {
        Path path = this.f_244606_.m_247566_(PackOutput.Target.REPORTS).resolve("commands.json");
        return this.f_254639_.thenCompose(p_256367_ -> {
            CommandDispatcher<CommandSourceStack> commanddispatcher = new Commands(Commands.CommandSelection.ALL, Commands.m_255082_(p_256367_)).m_82094_();
            return DataProvider.m_253162_(p_253721_, ArgumentUtils.m_235414_(commanddispatcher, commanddispatcher.getRoot()), path);
        });
    }

    @Override
    public final String m_6055_() {
        return "Command Syntax";
    }
}