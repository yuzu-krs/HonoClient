package net.minecraft.data.loot;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.IntStream;
import net.minecraft.advancements.critereon.BlockPredicate;
import net.minecraft.advancements.critereon.EnchantmentPredicate;
import net.minecraft.advancements.critereon.ItemEnchantmentsPredicate;
import net.minecraft.advancements.critereon.ItemPredicate;
import net.minecraft.advancements.critereon.ItemSubPredicates;
import net.minecraft.advancements.critereon.LocationPredicate;
import net.minecraft.advancements.critereon.MinMaxBounds;
import net.minecraft.advancements.critereon.StatePropertiesPredicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.BeehiveBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CandleBlock;
import net.minecraft.world.level.block.CaveVines;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.FlowerPotBlock;
import net.minecraft.world.level.block.MossyCarpetBlock;
import net.minecraft.world.level.block.MultifaceBlock;
import net.minecraft.world.level.block.PinkPetalsBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StemBlock;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.storage.loot.IntRange;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.entries.LootPoolEntryContainer;
import net.minecraft.world.level.storage.loot.entries.LootPoolSingletonContainer;
import net.minecraft.world.level.storage.loot.functions.ApplyBonusCount;
import net.minecraft.world.level.storage.loot.functions.ApplyExplosionDecay;
import net.minecraft.world.level.storage.loot.functions.CopyBlockState;
import net.minecraft.world.level.storage.loot.functions.CopyComponentsFunction;
import net.minecraft.world.level.storage.loot.functions.FunctionUserBuilder;
import net.minecraft.world.level.storage.loot.functions.LimitCount;
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction;
import net.minecraft.world.level.storage.loot.predicates.BonusLevelTableCondition;
import net.minecraft.world.level.storage.loot.predicates.ConditionUserBuilder;
import net.minecraft.world.level.storage.loot.predicates.ExplosionCondition;
import net.minecraft.world.level.storage.loot.predicates.LocationCheck;
import net.minecraft.world.level.storage.loot.predicates.LootItemBlockStatePropertyCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.predicates.MatchTool;
import net.minecraft.world.level.storage.loot.providers.number.BinomialDistributionGenerator;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.NumberProvider;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;

public abstract class BlockLootSubProvider implements LootTableSubProvider {
    protected final HolderLookup.Provider f_337332_;
    protected final Set<Item> f_243865_;
    protected final FeatureFlagSet f_243739_;
    protected final Map<ResourceKey<LootTable>, LootTable.Builder> f_244441_;
    protected static final float[] f_244509_ = new float[]{0.05F, 0.0625F, 0.083333336F, 0.1F};
    private static final float[] f_244531_ = new float[]{0.02F, 0.022222223F, 0.025F, 0.033333335F, 0.1F};

    protected LootItemCondition.Builder m_339433_() {
        HolderLookup.RegistryLookup<Enchantment> registrylookup = this.f_337332_.m_254974_(Registries.f_256762_);
        return MatchTool.m_81997_(
            ItemPredicate.Builder.m_45068_()
                .m_323078_(
                    ItemSubPredicates.f_315030_,
                    ItemEnchantmentsPredicate.m_319224_(
                        List.of(new EnchantmentPredicate(registrylookup.m_255043_(Enchantments.f_44985_), MinMaxBounds.Ints.m_55386_(1)))
                    )
                )
        );
    }

    protected LootItemCondition.Builder m_340528_() {
        return this.m_339433_().m_81807_();
    }

    protected LootItemCondition.Builder m_351776_() {
        return MatchTool.m_81997_(ItemPredicate.Builder.m_45068_().m_151445_(this.f_337332_.m_254974_(Registries.f_256913_), Items.f_42574_));
    }

    private LootItemCondition.Builder m_338918_() {
        return this.m_351776_().m_285888_(this.m_339433_());
    }

    private LootItemCondition.Builder m_338639_() {
        return this.m_338918_().m_81807_();
    }

    protected BlockLootSubProvider(Set<Item> p_281507_, FeatureFlagSet p_283552_, HolderLookup.Provider p_345174_) {
        this(p_281507_, p_283552_, new HashMap<>(), p_345174_);
    }

    protected BlockLootSubProvider(
        Set<Item> p_249153_, FeatureFlagSet p_251215_, Map<ResourceKey<LootTable>, LootTable.Builder> p_343991_, HolderLookup.Provider p_343444_
    ) {
        this.f_243865_ = p_249153_;
        this.f_243739_ = p_251215_;
        this.f_244441_ = p_343991_;
        this.f_337332_ = p_343444_;
    }

    protected <T extends FunctionUserBuilder<T>> T m_246108_(ItemLike p_248695_, FunctionUserBuilder<T> p_248548_) {
        return !this.f_243865_.contains(p_248695_.m_5456_()) ? p_248548_.m_79078_(ApplyExplosionDecay.m_80037_()) : p_248548_.m_79073_();
    }

    protected <T extends ConditionUserBuilder<T>> T m_247733_(ItemLike p_249717_, ConditionUserBuilder<T> p_248851_) {
        return !this.f_243865_.contains(p_249717_.m_5456_()) ? p_248851_.m_79080_(ExplosionCondition.m_81661_()) : p_248851_.m_79073_();
    }

    public LootTable.Builder m_247033_(ItemLike p_251912_) {
        return LootTable.m_79147_()
            .m_79161_(this.m_247733_(p_251912_, LootPool.m_79043_().m_165133_(ConstantValue.m_165692_(1.0F)).m_79076_(LootItem.m_79579_(p_251912_))));
    }

    private static LootTable.Builder m_246900_(Block p_252253_, LootItemCondition.Builder p_248764_, LootPoolEntryContainer.Builder<?> p_249146_) {
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_().m_165133_(ConstantValue.m_165692_(1.0F)).m_79076_(LootItem.m_79579_(p_252253_).m_79080_(p_248764_).m_7170_(p_249146_))
            );
    }

    protected LootTable.Builder m_247502_(Block p_250203_, LootPoolEntryContainer.Builder<?> p_252089_) {
        return m_246900_(p_250203_, this.m_339433_(), p_252089_);
    }

    protected LootTable.Builder m_247184_(Block p_252195_, LootPoolEntryContainer.Builder<?> p_250102_) {
        return m_246900_(p_252195_, this.m_351776_(), p_250102_);
    }

    protected LootTable.Builder m_246160_(Block p_250539_, LootPoolEntryContainer.Builder<?> p_251459_) {
        return m_246900_(p_250539_, this.m_338918_(), p_251459_);
    }

    protected LootTable.Builder m_245514_(Block p_249305_, ItemLike p_251905_) {
        return this.m_247502_(p_249305_, (LootPoolEntryContainer.Builder<?>)this.m_247733_(p_249305_, LootItem.m_79579_(p_251905_)));
    }

    protected LootTable.Builder m_245765_(ItemLike p_251584_, NumberProvider p_249865_) {
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_()
                    .m_165133_(ConstantValue.m_165692_(1.0F))
                    .m_79076_(
                        (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                            p_251584_, LootItem.m_79579_(p_251584_).m_79078_(SetItemCountFunction.m_165412_(p_249865_))
                        )
                    )
            );
    }

    protected LootTable.Builder m_245142_(Block p_251449_, ItemLike p_248558_, NumberProvider p_250047_) {
        return this.m_247502_(
            p_251449_,
            (LootPoolEntryContainer.Builder<?>)this.m_246108_(p_251449_, LootItem.m_79579_(p_248558_).m_79078_(SetItemCountFunction.m_165412_(p_250047_)))
        );
    }

    private LootTable.Builder m_245335_(ItemLike p_252216_) {
        return LootTable.m_79147_()
            .m_79161_(LootPool.m_79043_().m_79080_(this.m_339433_()).m_165133_(ConstantValue.m_165692_(1.0F)).m_79076_(LootItem.m_79579_(p_252216_)));
    }

    private LootTable.Builder m_245602_(ItemLike p_249395_) {
        return LootTable.m_79147_()
            .m_79161_(
                this.m_247733_(Blocks.f_50276_, LootPool.m_79043_().m_165133_(ConstantValue.m_165692_(1.0F)).m_79076_(LootItem.m_79579_(Blocks.f_50276_)))
            )
            .m_79161_(this.m_247733_(p_249395_, LootPool.m_79043_().m_165133_(ConstantValue.m_165692_(1.0F)).m_79076_(LootItem.m_79579_(p_249395_))));
    }

    protected LootTable.Builder m_247233_(Block p_251313_) {
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_()
                    .m_165133_(ConstantValue.m_165692_(1.0F))
                    .m_79076_(
                        (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                            p_251313_,
                            LootItem.m_79579_(p_251313_)
                                .m_79078_(
                                    SetItemCountFunction.m_165412_(ConstantValue.m_165692_(2.0F))
                                        .m_79080_(
                                            LootItemBlockStatePropertyCondition.m_81769_(p_251313_)
                                                .m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67697_(SlabBlock.f_56353_, SlabType.DOUBLE))
                                        )
                                )
                        )
                    )
            );
    }

    protected <T extends Comparable<T> & StringRepresentable> LootTable.Builder m_245178_(Block p_252154_, Property<T> p_250272_, T p_250292_) {
        return LootTable.m_79147_()
            .m_79161_(
                this.m_247733_(
                    p_252154_,
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(
                            LootItem.m_79579_(p_252154_)
                                .m_79080_(
                                    LootItemBlockStatePropertyCondition.m_81769_(p_252154_)
                                        .m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67697_(p_250272_, p_250292_))
                                )
                        )
                )
            );
    }

    protected LootTable.Builder m_246180_(Block p_252291_) {
        return LootTable.m_79147_()
            .m_79161_(
                this.m_247733_(
                    p_252291_,
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(
                            LootItem.m_79579_(p_252291_)
                                .m_79078_(CopyComponentsFunction.m_324952_(CopyComponentsFunction.Source.BLOCK_ENTITY).m_323761_(DataComponents.f_316016_))
                        )
                )
            );
    }

    protected LootTable.Builder m_247334_(Block p_252164_) {
        return LootTable.m_79147_()
            .m_79161_(
                this.m_247733_(
                    p_252164_,
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(
                            LootItem.m_79579_(p_252164_)
                                .m_79078_(
                                    CopyComponentsFunction.m_324952_(CopyComponentsFunction.Source.BLOCK_ENTITY)
                                        .m_323761_(DataComponents.f_316016_)
                                        .m_323761_(DataComponents.f_316065_)
                                        .m_323761_(DataComponents.f_315242_)
                                        .m_323761_(DataComponents.f_314304_)
                                )
                        )
                )
            );
    }

    protected LootTable.Builder m_246167_(Block p_251306_) {
        HolderLookup.RegistryLookup<Enchantment> registrylookup = this.f_337332_.m_254974_(Registries.f_256762_);
        return this.m_247502_(
            p_251306_,
            (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                p_251306_,
                LootItem.m_79579_(Items.f_151051_)
                    .m_79078_(SetItemCountFunction.m_165412_(UniformGenerator.m_165780_(2.0F, 5.0F)))
                    .m_79078_(ApplyBonusCount.m_79915_(registrylookup.m_255043_(Enchantments.f_316753_)))
            )
        );
    }

    protected LootTable.Builder m_246218_(Block p_251511_) {
        HolderLookup.RegistryLookup<Enchantment> registrylookup = this.f_337332_.m_254974_(Registries.f_256762_);
        return this.m_247502_(
            p_251511_,
            (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                p_251511_,
                LootItem.m_79579_(Items.f_42534_)
                    .m_79078_(SetItemCountFunction.m_165412_(UniformGenerator.m_165780_(4.0F, 9.0F)))
                    .m_79078_(ApplyBonusCount.m_79915_(registrylookup.m_255043_(Enchantments.f_316753_)))
            )
        );
    }

    protected LootTable.Builder m_245671_(Block p_251906_) {
        HolderLookup.RegistryLookup<Enchantment> registrylookup = this.f_337332_.m_254974_(Registries.f_256762_);
        return this.m_247502_(
            p_251906_,
            (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                p_251906_,
                LootItem.m_79579_(Items.f_42451_)
                    .m_79078_(SetItemCountFunction.m_165412_(UniformGenerator.m_165780_(4.0F, 5.0F)))
                    .m_79078_(ApplyBonusCount.m_79939_(registrylookup.m_255043_(Enchantments.f_316753_)))
            )
        );
    }

    protected LootTable.Builder m_247458_(Block p_249810_) {
        return LootTable.m_79147_()
            .m_79161_(
                this.m_247733_(
                    p_249810_,
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(
                            LootItem.m_79579_(p_249810_)
                                .m_79078_(
                                    CopyComponentsFunction.m_324952_(CopyComponentsFunction.Source.BLOCK_ENTITY)
                                        .m_323761_(DataComponents.f_316016_)
                                        .m_323761_(DataComponents.f_314548_)
                                        .m_323761_(DataComponents.f_316186_)
                                        .m_323761_(DataComponents.f_314522_)
                                        .m_323761_(DataComponents.f_315029_)
                                )
                        )
                )
            );
    }

    protected LootTable.Builder m_247273_(Block p_250988_) {
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_()
                    .m_79080_(this.m_339433_())
                    .m_165133_(ConstantValue.m_165692_(1.0F))
                    .m_79076_(
                        LootItem.m_79579_(p_250988_)
                            .m_79078_(CopyComponentsFunction.m_324952_(CopyComponentsFunction.Source.BLOCK_ENTITY).m_323761_(DataComponents.f_314066_))
                            .m_79078_(CopyBlockState.m_80062_(p_250988_).m_80084_(BeehiveBlock.f_49564_))
                    )
            );
    }

    protected LootTable.Builder m_247247_(Block p_248770_) {
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_()
                    .m_165133_(ConstantValue.m_165692_(1.0F))
                    .m_79076_(
                        LootItem.m_79579_(p_248770_)
                            .m_79080_(this.m_339433_())
                            .m_79078_(CopyComponentsFunction.m_324952_(CopyComponentsFunction.Source.BLOCK_ENTITY).m_323761_(DataComponents.f_314066_))
                            .m_79078_(CopyBlockState.m_80062_(p_248770_).m_80084_(BeehiveBlock.f_49564_))
                            .m_7170_(LootItem.m_79579_(p_248770_))
                    )
            );
    }

    protected LootTable.Builder m_245658_(Block p_251070_) {
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_()
                    .m_79076_(LootItem.m_79579_(Items.f_151079_))
                    .m_79080_(
                        LootItemBlockStatePropertyCondition.m_81769_(p_251070_)
                            .m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67703_(CaveVines.f_152949_, true))
                    )
            );
    }

    protected LootTable.Builder m_246109_(Block p_250450_, Item p_249745_) {
        HolderLookup.RegistryLookup<Enchantment> registrylookup = this.f_337332_.m_254974_(Registries.f_256762_);
        return this.m_247502_(
            p_250450_,
            (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                p_250450_, LootItem.m_79579_(p_249745_).m_79078_(ApplyBonusCount.m_79915_(registrylookup.m_255043_(Enchantments.f_316753_)))
            )
        );
    }

    protected LootTable.Builder m_245079_(Block p_249959_, ItemLike p_249315_) {
        return this.m_247502_(
            p_249959_,
            (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                p_249959_,
                LootItem.m_79579_(p_249315_)
                    .m_79078_(SetItemCountFunction.m_165412_(UniformGenerator.m_165780_(-6.0F, 2.0F)))
                    .m_79078_(LimitCount.m_165215_(IntRange.m_165026_(0)))
            )
        );
    }

    protected LootTable.Builder m_245349_(Block p_252139_) {
        HolderLookup.RegistryLookup<Enchantment> registrylookup = this.f_337332_.m_254974_(Registries.f_256762_);
        return this.m_247184_(
            p_252139_,
            (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                p_252139_,
                LootItem.m_79579_(Items.f_42404_)
                    .m_79080_(LootItemRandomChanceCondition.m_81927_(0.125F))
                    .m_79078_(ApplyBonusCount.m_79921_(registrylookup.m_255043_(Enchantments.f_316753_), 2))
            )
        );
    }

    public LootTable.Builder m_247642_(Block p_250957_, Item p_249098_) {
        return LootTable.m_79147_()
            .m_79161_(
                this.m_246108_(
                    p_250957_,
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(
                            LootItem.m_79579_(p_249098_)
                                .m_230984_(
                                    StemBlock.f_57013_.m_6908_(),
                                    p_249795_ -> SetItemCountFunction.m_165412_(BinomialDistributionGenerator.m_165659_(3, (float)(p_249795_ + 1) / 15.0F))
                                            .m_79080_(
                                                LootItemBlockStatePropertyCondition.m_81769_(p_250957_)
                                                    .m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67694_(StemBlock.f_57013_, p_249795_))
                                            )
                                )
                        )
                )
            );
    }

    public LootTable.Builder m_246312_(Block p_249778_, Item p_250678_) {
        return LootTable.m_79147_()
            .m_79161_(
                this.m_246108_(
                    p_249778_,
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(
                            LootItem.m_79579_(p_250678_).m_79078_(SetItemCountFunction.m_165412_(BinomialDistributionGenerator.m_165659_(3, 0.53333336F)))
                        )
                )
            );
    }

    protected LootTable.Builder m_245929_(ItemLike p_250684_) {
        return LootTable.m_79147_()
            .m_79161_(LootPool.m_79043_().m_165133_(ConstantValue.m_165692_(1.0F)).m_79080_(this.m_351776_()).m_79076_(LootItem.m_79579_(p_250684_)));
    }

    protected LootTable.Builder m_352977_(ItemLike p_364223_) {
        return LootTable.m_79147_()
            .m_79161_(LootPool.m_79043_().m_165133_(ConstantValue.m_165692_(1.0F)).m_79080_(this.m_338918_()).m_79076_(LootItem.m_79579_(p_364223_)));
    }

    protected LootTable.Builder m_246235_(Block p_249088_, LootItemCondition.Builder p_251535_) {
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_()
                    .m_79076_(
                        (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                            p_249088_,
                            LootItem.m_79579_(p_249088_)
                                .m_79080_(p_251535_)
                                .m_230987_(
                                    Direction.values(),
                                    p_251536_ -> SetItemCountFunction.m_165414_(ConstantValue.m_165692_(1.0F), true)
                                            .m_79080_(
                                                LootItemBlockStatePropertyCondition.m_81769_(p_249088_)
                                                    .m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67703_(MultifaceBlock.m_153933_(p_251536_), true))
                                            )
                                )
                                .m_79078_(SetItemCountFunction.m_165414_(ConstantValue.m_165692_(-1.0F), true))
                        )
                    )
            );
    }

    protected LootTable.Builder m_355030_(Block p_363021_) {
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_()
                    .m_79076_(
                        (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                            p_363021_,
                            LootItem.m_79579_(p_363021_)
                                .m_79080_(
                                    LootItemBlockStatePropertyCondition.m_81769_(p_363021_)
                                        .m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67703_(MossyCarpetBlock.f_348554_, true))
                                )
                        )
                    )
            );
    }

    protected LootTable.Builder m_246047_(Block p_250088_, Block p_250731_, float... p_248949_) {
        HolderLookup.RegistryLookup<Enchantment> registrylookup = this.f_337332_.m_254974_(Registries.f_256762_);
        return this.m_246160_(
                p_250088_,
                ((LootPoolSingletonContainer.Builder)this.m_247733_(p_250088_, LootItem.m_79579_(p_250731_)))
                    .m_79080_(BonusLevelTableCondition.m_81517_(registrylookup.m_255043_(Enchantments.f_316753_), p_248949_))
            )
            .m_79161_(
                LootPool.m_79043_()
                    .m_165133_(ConstantValue.m_165692_(1.0F))
                    .m_79080_(this.m_338639_())
                    .m_79076_(
                        ((LootPoolSingletonContainer.Builder)this.m_246108_(
                                p_250088_, LootItem.m_79579_(Items.f_42398_).m_79078_(SetItemCountFunction.m_165412_(UniformGenerator.m_165780_(1.0F, 2.0F)))
                            ))
                            .m_79080_(BonusLevelTableCondition.m_81517_(registrylookup.m_255043_(Enchantments.f_316753_), f_244531_))
                    )
            );
    }

    protected LootTable.Builder m_246142_(Block p_249535_, Block p_251505_, float... p_250753_) {
        HolderLookup.RegistryLookup<Enchantment> registrylookup = this.f_337332_.m_254974_(Registries.f_256762_);
        return this.m_246047_(p_249535_, p_251505_, p_250753_)
            .m_79161_(
                LootPool.m_79043_()
                    .m_165133_(ConstantValue.m_165692_(1.0F))
                    .m_79080_(this.m_338639_())
                    .m_79076_(
                        ((LootPoolSingletonContainer.Builder)this.m_247733_(p_249535_, LootItem.m_79579_(Items.f_42410_)))
                            .m_79080_(
                                BonusLevelTableCondition.m_81517_(
                                    registrylookup.m_255043_(Enchantments.f_316753_), 0.005F, 0.0055555557F, 0.00625F, 0.008333334F, 0.025F
                                )
                            )
                    )
            );
    }

    protected LootTable.Builder m_245170_(Block p_251103_) {
        HolderLookup.RegistryLookup<Enchantment> registrylookup = this.f_337332_.m_254974_(Registries.f_256762_);
        return this.m_246160_(
            p_251103_,
            ((LootPoolSingletonContainer.Builder)this.m_246108_(
                    Blocks.f_220838_, LootItem.m_79579_(Items.f_42398_).m_79078_(SetItemCountFunction.m_165412_(UniformGenerator.m_165780_(1.0F, 2.0F)))
                ))
                .m_79080_(BonusLevelTableCondition.m_81517_(registrylookup.m_255043_(Enchantments.f_316753_), f_244531_))
        );
    }

    protected LootTable.Builder m_245238_(Block p_249457_, Item p_248599_, Item p_251915_, LootItemCondition.Builder p_252202_) {
        HolderLookup.RegistryLookup<Enchantment> registrylookup = this.f_337332_.m_254974_(Registries.f_256762_);
        return this.m_246108_(
            p_249457_,
            LootTable.m_79147_()
                .m_79161_(LootPool.m_79043_().m_79076_(LootItem.m_79579_(p_248599_).m_79080_(p_252202_).m_7170_(LootItem.m_79579_(p_251915_))))
                .m_79161_(
                    LootPool.m_79043_()
                        .m_79080_(p_252202_)
                        .m_79076_(
                            LootItem.m_79579_(p_251915_).m_79078_(ApplyBonusCount.m_79917_(registrylookup.m_255043_(Enchantments.f_316753_), 0.5714286F, 3))
                        )
                )
        );
    }

    protected LootTable.Builder m_246463_(Block p_248678_) {
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_()
                    .m_79080_(this.m_351776_())
                    .m_79076_(LootItem.m_79579_(p_248678_).m_79078_(SetItemCountFunction.m_165412_(ConstantValue.m_165692_(2.0F))))
            );
    }

    protected LootTable.Builder m_246224_(Block p_248590_, Block p_248735_) {
        HolderLookup.RegistryLookup<Block> registrylookup = this.f_337332_.m_254974_(Registries.f_256747_);
        LootPoolEntryContainer.Builder<?> builder = LootItem.m_79579_(p_248735_)
            .m_79078_(SetItemCountFunction.m_165412_(ConstantValue.m_165692_(2.0F)))
            .m_79080_(this.m_351776_())
            .m_7170_(
                ((LootPoolSingletonContainer.Builder)this.m_247733_(p_248590_, LootItem.m_79579_(Items.f_42404_)))
                    .m_79080_(LootItemRandomChanceCondition.m_81927_(0.125F))
            );
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_()
                    .m_79076_(builder)
                    .m_79080_(
                        LootItemBlockStatePropertyCondition.m_81769_(p_248590_)
                            .m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67697_(DoublePlantBlock.f_52858_, DoubleBlockHalf.LOWER))
                    )
                    .m_79080_(
                        LocationCheck.m_81727_(
                            LocationPredicate.Builder.m_52651_()
                                .m_52652_(
                                    BlockPredicate.Builder.m_17924_()
                                        .m_204027_(registrylookup, p_248590_)
                                        .m_17929_(StatePropertiesPredicate.Builder.m_67693_().m_67697_(DoublePlantBlock.f_52858_, DoubleBlockHalf.UPPER))
                                ),
                            new BlockPos(0, 1, 0)
                        )
                    )
            )
            .m_79161_(
                LootPool.m_79043_()
                    .m_79076_(builder)
                    .m_79080_(
                        LootItemBlockStatePropertyCondition.m_81769_(p_248590_)
                            .m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67697_(DoublePlantBlock.f_52858_, DoubleBlockHalf.UPPER))
                    )
                    .m_79080_(
                        LocationCheck.m_81727_(
                            LocationPredicate.Builder.m_52651_()
                                .m_52652_(
                                    BlockPredicate.Builder.m_17924_()
                                        .m_204027_(registrylookup, p_248590_)
                                        .m_17929_(StatePropertiesPredicate.Builder.m_67693_().m_67697_(DoublePlantBlock.f_52858_, DoubleBlockHalf.LOWER))
                                ),
                            new BlockPos(0, -1, 0)
                        )
                    )
            );
    }

    protected LootTable.Builder m_245895_(Block p_250896_) {
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_()
                    .m_165133_(ConstantValue.m_165692_(1.0F))
                    .m_79076_(
                        (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                            p_250896_,
                            LootItem.m_79579_(p_250896_)
                                .m_230984_(
                                    List.of(2, 3, 4),
                                    p_249985_ -> SetItemCountFunction.m_165412_(ConstantValue.m_165692_((float)p_249985_.intValue()))
                                            .m_79080_(
                                                LootItemBlockStatePropertyCondition.m_81769_(p_250896_)
                                                    .m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67694_(CandleBlock.f_152790_, p_249985_))
                                            )
                                )
                        )
                    )
            );
    }

    protected LootTable.Builder m_271693_(Block p_273240_) {
        return LootTable.m_79147_()
            .m_79161_(
                LootPool.m_79043_()
                    .m_165133_(ConstantValue.m_165692_(1.0F))
                    .m_79076_(
                        (LootPoolEntryContainer.Builder<?>)this.m_246108_(
                            p_273240_,
                            LootItem.m_79579_(p_273240_)
                                .m_230984_(
                                    IntStream.rangeClosed(1, 4).boxed().toList(),
                                    p_272348_ -> SetItemCountFunction.m_165412_(ConstantValue.m_165692_((float)p_272348_.intValue()))
                                            .m_79080_(
                                                LootItemBlockStatePropertyCondition.m_81769_(p_273240_)
                                                    .m_81784_(StatePropertiesPredicate.Builder.m_67693_().m_67694_(PinkPetalsBlock.f_271373_, p_272348_))
                                            )
                                )
                        )
                    )
            );
    }

    protected static LootTable.Builder m_246838_(Block p_250280_) {
        return LootTable.m_79147_().m_79161_(LootPool.m_79043_().m_165133_(ConstantValue.m_165692_(1.0F)).m_79076_(LootItem.m_79579_(p_250280_)));
    }

    public static LootTable.Builder m_246386_() {
        return LootTable.m_79147_();
    }

    protected abstract void m_245660_();

    @Override
    public void m_245126_(BiConsumer<ResourceKey<LootTable>, LootTable.Builder> p_249322_) {
        this.m_245660_();
        Set<ResourceKey<LootTable>> set = new HashSet<>();

        for (Block block : BuiltInRegistries.f_256975_) {
            if (block.m_245993_(this.f_243739_)) {
                block.m_60589_()
                    .ifPresent(
                        p_358210_ -> {
                            if (set.add((ResourceKey<LootTable>)p_358210_)) {
                                LootTable.Builder loottable$builder = this.f_244441_.remove(p_358210_);
                                if (loottable$builder == null) {
                                    throw new IllegalStateException(
                                        String.format(
                                            Locale.ROOT, "Missing loottable '%s' for '%s'", p_358210_.m_135782_(), BuiltInRegistries.f_256975_.m_7981_(block)
                                        )
                                    );
                                }

                                p_249322_.accept((ResourceKey<LootTable>)p_358210_, loottable$builder);
                            }
                        }
                    );
            }
        }

        if (!this.f_244441_.isEmpty()) {
            throw new IllegalStateException("Created block loot tables for non-blocks: " + this.f_244441_.keySet());
        }
    }

    protected void m_245693_(Block p_252269_, Block p_250696_) {
        HolderLookup.RegistryLookup<Enchantment> registrylookup = this.f_337332_.m_254974_(Registries.f_256762_);
        LootTable.Builder loottable$builder = this.m_246160_(
            p_252269_,
            LootItem.m_79579_(p_252269_)
                .m_79080_(BonusLevelTableCondition.m_81517_(registrylookup.m_255043_(Enchantments.f_316753_), 0.33F, 0.55F, 0.77F, 1.0F))
        );
        this.m_247577_(p_252269_, loottable$builder);
        this.m_247577_(p_250696_, loottable$builder);
    }

    protected LootTable.Builder m_247398_(Block p_252166_) {
        return this.m_245178_(p_252166_, DoorBlock.f_52730_, DoubleBlockHalf.LOWER);
    }

    protected void m_246535_(Block p_251064_) {
        this.m_246481_(p_251064_, p_308498_ -> this.m_245602_(((FlowerPotBlock)p_308498_).m_304918_()));
    }

    protected void m_245854_(Block p_249932_, Block p_252053_) {
        this.m_247577_(p_249932_, this.m_245335_(p_252053_));
    }

    protected void m_246125_(Block p_248885_, ItemLike p_251883_) {
        this.m_247577_(p_248885_, this.m_247033_(p_251883_));
    }

    protected void m_245644_(Block p_250855_) {
        this.m_245854_(p_250855_, p_250855_);
    }

    protected void m_245724_(Block p_249181_) {
        this.m_246125_(p_249181_, p_249181_);
    }

    protected void m_246481_(Block p_251966_, Function<Block, LootTable.Builder> p_251699_) {
        this.m_247577_(p_251966_, p_251699_.apply(p_251966_));
    }

    protected void m_247577_(Block p_250610_, LootTable.Builder p_249817_) {
        this.f_244441_.put(p_250610_.m_60589_().orElseThrow(() -> new IllegalStateException("Block " + p_250610_ + " does not have loot table")), p_249817_);
    }
}