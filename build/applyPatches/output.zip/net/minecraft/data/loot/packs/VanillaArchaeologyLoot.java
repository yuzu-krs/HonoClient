package net.minecraft.data.loot.packs;

import java.util.function.BiConsumer;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.loot.LootTableSubProvider;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.SetStewEffectFunction;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;

public record VanillaArchaeologyLoot(HolderLookup.Provider f_336691_) implements LootTableSubProvider {
    @Override
    public void m_245126_(BiConsumer<ResourceKey<LootTable>, LootTable.Builder> p_278066_) {
        p_278066_.accept(
            BuiltInLootTables.f_276662_,
            LootTable.m_79147_()
                .m_79161_(
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(LootItem.m_79579_(Items.f_279634_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_279583_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42460_))
                        .m_79076_(LootItem.m_79579_(Items.f_42616_))
                        .m_79076_(LootItem.m_79579_(Items.f_42398_))
                        .m_79076_(
                            LootItem.m_79579_(Items.f_42718_)
                                .m_79078_(
                                    SetStewEffectFunction.m_81228_()
                                        .m_165472_(MobEffects.f_19611_, UniformGenerator.m_165780_(7.0F, 10.0F))
                                        .m_165472_(MobEffects.f_19603_, UniformGenerator.m_165780_(7.0F, 10.0F))
                                        .m_165472_(MobEffects.f_19613_, UniformGenerator.m_165780_(6.0F, 8.0F))
                                        .m_165472_(MobEffects.f_19610_, UniformGenerator.m_165780_(5.0F, 7.0F))
                                        .m_165472_(MobEffects.f_19614_, UniformGenerator.m_165780_(10.0F, 20.0F))
                                        .m_165472_(MobEffects.f_19618_, UniformGenerator.m_165780_(7.0F, 10.0F))
                                )
                        )
                )
        );
        p_278066_.accept(
            BuiltInLootTables.f_276661_,
            LootTable.m_79147_()
                .m_79161_(
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(LootItem.m_79579_(Items.f_279642_))
                        .m_79076_(LootItem.m_79579_(Items.f_279559_))
                        .m_79076_(LootItem.m_79579_(Items.f_279528_))
                        .m_79076_(LootItem.m_79579_(Items.f_279570_))
                        .m_79076_(LootItem.m_79579_(Items.f_42415_))
                        .m_79076_(LootItem.m_79579_(Items.f_41996_))
                        .m_79076_(LootItem.m_79579_(Items.f_42403_))
                        .m_79076_(LootItem.m_79579_(Items.f_42616_))
                )
        );
        p_278066_.accept(
            BuiltInLootTables.f_279573_,
            LootTable.m_79147_()
                .m_79161_(
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(LootItem.m_79579_(Items.f_42616_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42405_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42424_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_41983_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42460_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42539_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42494_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42538_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42535_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42536_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_151081_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_151080_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_151076_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_151078_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42178_))
                        .m_79076_(LootItem.m_79579_(Items.f_42182_))
                        .m_79076_(LootItem.m_79579_(Items.f_42187_))
                        .m_79076_(LootItem.m_79579_(Items.f_42179_))
                        .m_79076_(LootItem.m_79579_(Items.f_42190_))
                        .m_79076_(LootItem.m_79579_(Items.f_42180_))
                        .m_79076_(LootItem.m_79579_(Items.f_42186_))
                        .m_79076_(LootItem.m_79579_(Items.f_243963_))
                        .m_79076_(LootItem.m_79579_(Items.f_244406_))
                        .m_79076_(LootItem.m_79579_(Items.f_42587_))
                        .m_79076_(LootItem.m_79579_(Items.f_42413_))
                        .m_79076_(LootItem.m_79579_(Items.f_42404_))
                        .m_79076_(LootItem.m_79579_(Items.f_42733_))
                        .m_79076_(LootItem.m_79579_(Items.f_41866_))
                        .m_79076_(LootItem.m_79579_(Items.f_42618_))
                        .m_79076_(LootItem.m_79579_(Items.f_42401_))
                        .m_79076_(LootItem.m_79579_(Items.f_42655_))
                )
        );
        p_278066_.accept(
            BuiltInLootTables.f_279604_,
            LootTable.m_79147_()
                .m_79161_(
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(LootItem.m_79579_(Items.f_279650_))
                        .m_79076_(LootItem.m_79579_(Items.f_279619_))
                        .m_79076_(LootItem.m_79579_(Items.f_279584_))
                        .m_79076_(LootItem.m_79579_(Items.f_279623_))
                        .m_79076_(LootItem.m_79579_(Items.f_279606_))
                        .m_79076_(LootItem.m_79579_(Items.f_279598_))
                        .m_79076_(LootItem.m_79579_(Items.f_279545_))
                        .m_79076_(LootItem.m_79579_(Items.f_276612_))
                        .m_79076_(LootItem.m_79579_(Items.f_276465_))
                        .m_79076_(LootItem.m_79579_(Items.f_276546_))
                        .m_79076_(LootItem.m_79579_(Items.f_276433_))
                        .m_79076_(LootItem.m_79579_(Items.f_283830_))
                )
        );
        p_278066_.accept(
            BuiltInLootTables.f_276611_,
            LootTable.m_79147_()
                .m_79161_(
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(LootItem.m_79579_(Items.f_279633_))
                        .m_79076_(LootItem.m_79579_(Items.f_279529_))
                        .m_79076_(LootItem.m_79579_(Items.f_279636_))
                        .m_79076_(LootItem.m_79579_(Items.f_276468_))
                        .m_79076_(LootItem.m_79579_(Items.f_42386_))
                        .m_79076_(LootItem.m_79579_(Items.f_42616_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42405_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42424_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42413_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42587_).m_79707_(2))
                )
        );
        p_278066_.accept(
            BuiltInLootTables.f_276614_,
            LootTable.m_79147_()
                .m_79161_(
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(1.0F))
                        .m_79076_(LootItem.m_79579_(Items.f_279567_))
                        .m_79076_(LootItem.m_79579_(Items.f_279616_))
                        .m_79076_(LootItem.m_79579_(Items.f_279560_))
                        .m_79076_(LootItem.m_79579_(Items.f_279647_))
                        .m_79076_(LootItem.m_79579_(Items.f_42386_))
                        .m_79076_(LootItem.m_79579_(Items.f_42616_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42405_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42424_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42413_).m_79707_(2))
                        .m_79076_(LootItem.m_79579_(Items.f_42587_).m_79707_(2))
                )
        );
    }
}