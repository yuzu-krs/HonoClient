package net.minecraft.data.loot.packs;

import java.util.function.BiConsumer;
import net.minecraft.advancements.critereon.EntityPredicate;
import net.minecraft.advancements.critereon.EntitySubPredicates;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.loot.EntityLootSubProvider;
import net.minecraft.data.loot.LootTableSubProvider;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.animal.MushroomCow;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.AlternativesEntry;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.entries.NestedLootTable;
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction;
import net.minecraft.world.level.storage.loot.predicates.LootItemEntityPropertyCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;

public record VanillaShearingLoot(HolderLookup.Provider f_336892_) implements LootTableSubProvider {
    @Override
    public void m_245126_(BiConsumer<ResourceKey<LootTable>, LootTable.Builder> p_330494_) {
        p_330494_.accept(
            BuiltInLootTables.f_315144_,
            LootTable.m_79147_()
                .m_79161_(
                    LootPool.m_79043_()
                        .m_165133_(ConstantValue.m_165692_(2.0F))
                        .m_79076_(LootItem.m_79579_(Items.f_41952_).m_79078_(SetItemCountFunction.m_165412_(ConstantValue.m_165692_(1.0F))))
                        .m_79076_(LootItem.m_79579_(Items.f_41953_).m_79078_(SetItemCountFunction.m_165412_(ConstantValue.m_165692_(1.0F))))
                )
        );
        LootData.f_346713_
            .forEach(
                (p_368887_, p_367035_) -> p_330494_.accept(
                        BuiltInLootTables.f_346289_.get(p_368887_),
                        LootTable.m_79147_()
                            .m_79161_(LootPool.m_79043_().m_165133_(UniformGenerator.m_165780_(1.0F, 3.0F)).m_79076_(LootItem.m_79579_(p_367035_)))
                    )
            );
        p_330494_.accept(BuiltInLootTables.f_348744_, LootTable.m_79147_().m_79161_(EntityLootSubProvider.m_356131_(BuiltInLootTables.f_346289_)));
        p_330494_.accept(
            BuiltInLootTables.f_346238_,
            LootTable.m_79147_()
                .m_79161_(
                    LootPool.m_79043_()
                        .m_79076_(
                            AlternativesEntry.m_79395_(
                                NestedLootTable.m_320126_(BuiltInLootTables.f_348721_)
                                    .m_79080_(
                                        LootItemEntityPropertyCondition.m_81864_(
                                            LootContext.EntityTarget.THIS,
                                            EntityPredicate.Builder.m_36633_().m_218800_(EntitySubPredicates.f_315115_.m_320150_(MushroomCow.Variant.RED))
                                        )
                                    ),
                                NestedLootTable.m_320126_(BuiltInLootTables.f_348826_)
                                    .m_79080_(
                                        LootItemEntityPropertyCondition.m_81864_(
                                            LootContext.EntityTarget.THIS,
                                            EntityPredicate.Builder.m_36633_().m_218800_(EntitySubPredicates.f_315115_.m_320150_(MushroomCow.Variant.BROWN))
                                        )
                                    )
                            )
                        )
                )
        );
        p_330494_.accept(
            BuiltInLootTables.f_348721_,
            LootTable.m_79147_().m_79161_(LootPool.m_79043_().m_165133_(ConstantValue.m_165692_(5.0F)).m_79076_(LootItem.m_79579_(Items.f_41953_)))
        );
        p_330494_.accept(
            BuiltInLootTables.f_348826_,
            LootTable.m_79147_().m_79161_(LootPool.m_79043_().m_165133_(ConstantValue.m_165692_(5.0F)).m_79076_(LootItem.m_79579_(Items.f_41952_)))
        );
        p_330494_.accept(
            BuiltInLootTables.f_348157_,
            LootTable.m_79147_().m_79161_(LootPool.m_79043_().m_165133_(ConstantValue.m_165692_(1.0F)).m_79076_(LootItem.m_79579_(Items.f_42047_)))
        );
    }
}