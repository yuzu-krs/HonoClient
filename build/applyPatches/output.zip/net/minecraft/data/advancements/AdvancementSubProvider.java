package net.minecraft.data.advancements;

import java.util.function.Consumer;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.core.HolderLookup;
import net.minecraft.resources.ResourceLocation;

public interface AdvancementSubProvider {
    void m_245571_(HolderLookup.Provider p_255901_, Consumer<AdvancementHolder> p_250888_);

    static AdvancementHolder m_306985_(String p_312736_) {
        return Advancement.Builder.m_138353_().m_138403_(ResourceLocation.m_338530_(p_312736_));
    }
}