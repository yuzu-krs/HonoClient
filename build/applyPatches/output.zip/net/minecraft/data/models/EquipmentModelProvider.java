package net.minecraft.data.models;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.equipment.EquipmentModel;
import net.minecraft.world.item.equipment.EquipmentModels;

public class EquipmentModelProvider implements DataProvider {
    private final PackOutput.PathProvider f_349204_;

    public EquipmentModelProvider(PackOutput p_363709_) {
        this.f_349204_ = p_363709_.m_245269_(PackOutput.Target.RESOURCE_PACK, "models/equipment");
    }

    @Override
    public CompletableFuture<?> m_213708_(CachedOutput p_361266_) {
        Map<ResourceLocation, EquipmentModel> map = new HashMap<>();
        EquipmentModels.m_357010_((p_369842_, p_361854_) -> {
            if (map.putIfAbsent(p_369842_, p_361854_) != null) {
                throw new IllegalStateException("Tried to register equipment model twice for id: " + p_369842_);
            }
        });
        return DataProvider.m_356889_(p_361266_, EquipmentModel.f_349261_, this.f_349204_, map);
    }

    @Override
    public String m_6055_() {
        return "Equipment Model Definitions";
    }
}