package net.minecraft.data.registries;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistrySetBuilder;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.enchantment.providers.TradeRebalanceEnchantmentProviders;

public class TradeRebalanceRegistries {
    private static final RegistrySetBuilder f_337636_ = new RegistrySetBuilder().m_254916_(Registries.f_336718_, TradeRebalanceEnchantmentProviders::m_339794_);

    public static CompletableFuture<RegistrySetBuilder.PatchedRegistries> m_339855_(CompletableFuture<HolderLookup.Provider> p_342727_) {
        return RegistryPatchGenerator.m_305415_(p_342727_, f_337636_);
    }
}