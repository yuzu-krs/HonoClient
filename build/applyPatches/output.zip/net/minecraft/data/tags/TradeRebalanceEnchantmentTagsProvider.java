package net.minecraft.data.tags;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.PackOutput;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;

public class TradeRebalanceEnchantmentTagsProvider extends TagsProvider<Enchantment> {
    public TradeRebalanceEnchantmentTagsProvider(PackOutput p_343252_, CompletableFuture<HolderLookup.Provider> p_345008_) {
        super(p_343252_, Registries.f_256762_, p_345008_);
    }

    @Override
    protected void m_6577_(HolderLookup.Provider p_344003_) {
        this.m_206424_(EnchantmentTags.f_337091_).m_211101_(Enchantments.f_44966_, Enchantments.f_44972_, Enchantments.f_316098_);
        this.m_206424_(EnchantmentTags.f_337030_).m_211101_(Enchantments.f_315602_, Enchantments.f_44969_, Enchantments.f_314636_);
        this.m_206424_(EnchantmentTags.f_336780_).m_211101_(Enchantments.f_316860_, Enchantments.f_44978_, Enchantments.f_44979_);
        this.m_206424_(EnchantmentTags.f_337419_).m_211101_(Enchantments.f_44980_, Enchantments.f_44975_, Enchantments.f_44983_);
        this.m_206424_(EnchantmentTags.f_337060_).m_211101_(Enchantments.f_44971_, Enchantments.f_316023_, Enchantments.f_44974_);
        this.m_206424_(EnchantmentTags.f_336693_).m_211101_(Enchantments.f_44973_, Enchantments.f_44970_, Enchantments.f_44963_);
        this.m_206424_(EnchantmentTags.f_337145_).m_211101_(Enchantments.f_44968_, Enchantments.f_44981_, Enchantments.f_316779_);
        this.m_206424_(EnchantmentTags.f_337168_).m_255204_(Enchantments.f_316758_);
        this.m_206424_(EnchantmentTags.f_337098_).m_255204_(Enchantments.f_44986_);
        this.m_206424_(EnchantmentTags.f_337634_).m_255204_(Enchantments.f_314710_);
        this.m_206424_(EnchantmentTags.f_336990_).m_255204_(Enchantments.f_44977_);
        this.m_206424_(EnchantmentTags.f_337654_).m_255204_(Enchantments.f_44985_);
        this.m_206424_(EnchantmentTags.f_336638_).m_255204_(Enchantments.f_44962_);
        this.m_206424_(EnchantmentTags.f_336783_).m_255204_(Enchantments.f_316753_);
    }
}