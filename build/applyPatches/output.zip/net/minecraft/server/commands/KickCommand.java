package net.minecraft.server.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.Collection;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.MessageArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public class KickCommand {
    private static final SimpleCommandExceptionType f_302660_ = new SimpleCommandExceptionType(Component.m_237115_("commands.kick.owner.failed"));
    private static final SimpleCommandExceptionType f_302620_ = new SimpleCommandExceptionType(Component.m_237115_("commands.kick.singleplayer.failed"));

    public static void m_137795_(CommandDispatcher<CommandSourceStack> p_137796_) {
        p_137796_.register(
            Commands.m_82127_("kick")
                .requires(p_137800_ -> p_137800_.m_6761_(3))
                .then(
                    Commands.m_82129_("targets", EntityArgument.m_91470_())
                        .executes(
                            p_137806_ -> m_137801_(
                                    p_137806_.getSource(), EntityArgument.m_91477_(p_137806_, "targets"), Component.m_237115_("multiplayer.disconnect.kicked")
                                )
                        )
                        .then(
                            Commands.m_82129_("reason", MessageArgument.m_96832_())
                                .executes(
                                    p_137798_ -> m_137801_(
                                            p_137798_.getSource(), EntityArgument.m_91477_(p_137798_, "targets"), MessageArgument.m_96835_(p_137798_, "reason")
                                        )
                                )
                        )
                )
        );
    }

    private static int m_137801_(CommandSourceStack p_137802_, Collection<ServerPlayer> p_137803_, Component p_137804_) throws CommandSyntaxException {
        if (!p_137802_.m_81377_().m_6992_()) {
            throw f_302620_.create();
        } else {
            int i = 0;

            for (ServerPlayer serverplayer : p_137803_) {
                if (!p_137802_.m_81377_().m_7779_(serverplayer.m_36316_())) {
                    serverplayer.f_8906_.m_294716_(p_137804_);
                    p_137802_.m_288197_(() -> Component.m_237110_("commands.kick.success", serverplayer.m_5446_(), p_137804_), true);
                    i++;
                }
            }

            if (i == 0) {
                throw f_302660_.create();
            } else {
                return i;
            }
        }
    }
}