package net.minecraft.server.network.config;

import java.util.function.Consumer;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.configuration.ClientboundFinishConfigurationPacket;
import net.minecraft.server.network.ConfigurationTask;

public class JoinWorldTask implements ConfigurationTask {
    public static final ConfigurationTask.Type f_291484_ = new ConfigurationTask.Type("join_world");

    @Override
    public void m_293075_(Consumer<Packet<?>> p_299501_) {
        p_299501_.accept(ClientboundFinishConfigurationPacket.f_315319_);
    }

    @Override
    public ConfigurationTask.Type m_293172_() {
        return f_291484_;
    }
}