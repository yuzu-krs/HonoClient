package net.minecraft.world.phys.shapes;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.level.CollisionGetter;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;

public class MinecartCollisionContext extends EntityCollisionContext {
    @Nullable
    private BlockPos f_346915_;
    @Nullable
    private BlockPos f_346498_;

    protected MinecartCollisionContext(AbstractMinecart p_364249_, boolean p_363030_) {
        super(p_364249_, p_363030_);
        this.m_356755_(p_364249_);
    }

    private void m_356755_(AbstractMinecart p_363529_) {
        BlockPos blockpos = p_363529_.m_356679_();
        BlockState blockstate = p_363529_.m_9236_().m_8055_(blockpos);
        boolean flag = BaseRailBlock.m_49416_(blockstate);
        if (flag) {
            this.f_346915_ = blockpos.m_7495_();
            RailShape railshape = blockstate.m_61143_(((BaseRailBlock)blockstate.m_60734_()).m_7978_());
            if (railshape.m_61745_()) {
                this.f_346498_ = switch (railshape) {
                    case ASCENDING_EAST -> blockpos.m_122029_();
                    case ASCENDING_WEST -> blockpos.m_122024_();
                    case ASCENDING_NORTH -> blockpos.m_122012_();
                    case ASCENDING_SOUTH -> blockpos.m_122019_();
                    default -> null;
                };
            }
        }
    }

    @Override
    public VoxelShape m_353701_(BlockState p_361633_, CollisionGetter p_368990_, BlockPos p_365642_) {
        return !p_365642_.equals(this.f_346915_) && !p_365642_.equals(this.f_346498_) ? super.m_353701_(p_361633_, p_368990_, p_365642_) : Shapes.m_83040_();
    }
}