package net.minecraft.world.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.equipment.Equippable;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;

public interface EquipmentUser {
    void m_21035_(EquipmentSlot p_333752_, ItemStack p_331668_);

    ItemStack m_6844_(EquipmentSlot p_329199_);

    void m_21409_(EquipmentSlot p_331517_, float p_334697_);

    default void m_321661_(EquipmentTable p_331159_, LootParams p_332346_) {
        this.m_319719_(p_331159_.f_316700_(), p_332346_, p_331159_.f_315505_());
    }

    default void m_319719_(ResourceKey<LootTable> p_329232_, LootParams p_330675_, Map<EquipmentSlot, Float> p_328003_) {
        this.m_320583_(p_329232_, p_330675_, 0L, p_328003_);
    }

    default void m_320583_(ResourceKey<LootTable> p_331471_, LootParams p_333826_, long p_331881_, Map<EquipmentSlot, Float> p_328541_) {
        LootTable loottable = p_333826_.m_287182_().m_7654_().m_323018_().m_321428_(p_331471_);
        if (loottable != LootTable.f_79105_) {
            List<ItemStack> list = loottable.m_287214_(p_333826_, p_331881_);
            List<EquipmentSlot> list1 = new ArrayList<>();

            for (ItemStack itemstack : list) {
                EquipmentSlot equipmentslot = this.m_320137_(itemstack, list1);
                if (equipmentslot != null) {
                    ItemStack itemstack1 = equipmentslot.m_338803_(itemstack);
                    this.m_21035_(equipmentslot, itemstack1);
                    Float f = p_328541_.get(equipmentslot);
                    if (f != null) {
                        this.m_21409_(equipmentslot, f);
                    }

                    list1.add(equipmentslot);
                }
            }
        }
    }

    @Nullable
    default EquipmentSlot m_320137_(ItemStack p_329649_, List<EquipmentSlot> p_334449_) {
        if (p_329649_.m_41619_()) {
            return null;
        } else {
            Equippable equippable = p_329649_.m_323252_(DataComponents.f_348912_);
            if (equippable != null) {
                EquipmentSlot equipmentslot = equippable.f_346362_();
                if (!p_334449_.contains(equipmentslot)) {
                    return equipmentslot;
                }
            } else if (!p_334449_.contains(EquipmentSlot.MAINHAND)) {
                return EquipmentSlot.MAINHAND;
            }

            return null;
        }
    }
}