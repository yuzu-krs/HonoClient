package net.minecraft.world.entity.ai.behavior;

import java.util.Optional;
import java.util.function.Function;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.behavior.declarative.BehaviorBuilder;
import net.minecraft.world.entity.ai.behavior.declarative.MemoryAccessor;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.NearestVisibleLivingEntities;
import net.minecraft.world.entity.ai.memory.WalkTarget;

public class SetWalkTargetFromAttackTargetIfTargetOutOfReach {
    private static final int f_147903_ = 1;

    public static BehaviorControl<Mob> m_257469_(float p_259228_) {
        return m_257648_(p_147908_ -> p_259228_);
    }

    public static BehaviorControl<Mob> m_257648_(Function<LivingEntity, Float> p_259507_) {
        return BehaviorBuilder.m_258034_(
            p_258687_ -> p_258687_.group(
                        p_258687_.m_257492_(MemoryModuleType.f_26370_),
                        p_258687_.m_257492_(MemoryModuleType.f_26371_),
                        p_258687_.m_257495_(MemoryModuleType.f_26372_),
                        p_258687_.m_257492_(MemoryModuleType.f_148205_)
                    )
                    .apply(p_258687_, (p_258699_, p_258700_, p_258701_, p_258702_) -> (p_258694_, p_258695_, p_258696_) -> {
                            LivingEntity livingentity = p_258687_.m_258051_(p_258701_);
                            Optional<NearestVisibleLivingEntities> optional = p_258687_.m_257828_(p_258702_);
                            if (optional.isPresent() && optional.get().m_186107_(livingentity) && BehaviorUtils.m_22632_(p_258695_, livingentity, 1)) {
                                p_258699_.m_257971_();
                            } else {
                                p_258700_.m_257512_(new EntityTracker(livingentity, true));
                                p_258699_.m_257512_(new WalkTarget(new EntityTracker(livingentity, false), p_259507_.apply(p_258695_), 0));
                            }

                            return true;
                        })
        );
    }
}