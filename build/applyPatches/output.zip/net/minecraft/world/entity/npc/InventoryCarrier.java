package net.minecraft.world.entity.npc;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;

public interface InventoryCarrier {
    String f_252389_ = "Inventory";

    SimpleContainer m_35311_();

    static void m_219611_(ServerLevel p_361504_, Mob p_219612_, InventoryCarrier p_219613_, ItemEntity p_219614_) {
        ItemStack itemstack = p_219614_.m_32055_();
        if (p_219612_.m_7243_(p_361504_, itemstack)) {
            SimpleContainer simplecontainer = p_219613_.m_35311_();
            boolean flag = simplecontainer.m_19183_(itemstack);
            if (!flag) {
                return;
            }

            p_219612_.m_21053_(p_219614_);
            int i = itemstack.m_41613_();
            ItemStack itemstack1 = simplecontainer.m_19173_(itemstack);
            p_219612_.m_7938_(p_219614_, i - itemstack1.m_41613_());
            if (itemstack1.m_41619_()) {
                p_219614_.m_146870_();
            } else {
                itemstack.m_41764_(itemstack1.m_41613_());
            }
        }
    }

    default void m_253224_(CompoundTag p_253699_, HolderLookup.Provider p_331899_) {
        if (p_253699_.m_128425_("Inventory", 9)) {
            this.m_35311_().m_7797_(p_253699_.m_128437_("Inventory", 10), p_331899_);
        }
    }

    default void m_252802_(CompoundTag p_254428_, HolderLookup.Provider p_328974_) {
        p_254428_.m_128365_("Inventory", this.m_35311_().m_7927_(p_328974_));
    }
}