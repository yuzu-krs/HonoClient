package net.minecraft.world.entity.vehicle;

import com.mojang.datafixers.util.Pair;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.PoweredRailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class OldMinecartBehavior extends MinecartBehavior {
    private static final double f_346661_ = 0.01;
    private static final double f_346319_ = 0.2;
    private static final double f_347009_ = 0.4;
    private static final double f_347068_ = 0.4;
    private int f_346356_;
    private double f_347355_;
    private double f_348650_;
    private double f_348427_;
    private double f_346480_;
    private double f_348221_;
    private Vec3 f_347094_ = Vec3.f_82478_;

    public OldMinecartBehavior(AbstractMinecart p_368096_) {
        super(p_368096_);
    }

    @Override
    public void m_355155_() {
        this.f_346356_ = 0;
    }

    @Override
    public void m_354849_(double p_367842_, double p_362787_, double p_363573_, float p_367207_, float p_366673_, int p_365423_) {
        this.f_347355_ = p_367842_;
        this.f_348650_ = p_362787_;
        this.f_348427_ = p_363573_;
        this.f_346480_ = (double)p_367207_;
        this.f_348221_ = (double)p_366673_;
        this.f_346356_ = p_365423_ + 2;
        this.m_357144_(this.f_347094_);
    }

    @Override
    public double m_352433_() {
        return this.f_346356_ > 0 ? this.f_347355_ : this.f_349141_.m_20185_();
    }

    @Override
    public double m_354102_() {
        return this.f_346356_ > 0 ? this.f_348650_ : this.f_349141_.m_20186_();
    }

    @Override
    public double m_353738_() {
        return this.f_346356_ > 0 ? this.f_348427_ : this.f_349141_.m_20189_();
    }

    @Override
    public float m_352910_() {
        return this.f_346356_ > 0 ? (float)this.f_348221_ : this.m_353360_();
    }

    @Override
    public float m_354563_() {
        return this.f_346356_ > 0 ? (float)this.f_346480_ : this.m_354728_();
    }

    @Override
    public void m_352358_(double p_368086_, double p_368739_, double p_361323_) {
        this.f_347094_ = new Vec3(p_368086_, p_368739_, p_361323_);
        this.m_357144_(this.f_347094_);
    }

    @Override
    public void m_352175_() {
        if (this.m_354883_() instanceof ServerLevel serverlevel) {
            this.f_349141_.m_320756_();
            BlockPos blockpos = this.f_349141_.m_356679_();
            BlockState blockstate = this.m_354883_().m_8055_(blockpos);
            boolean $$4 = BaseRailBlock.m_49416_(blockstate);
            this.f_349141_.m_354709_($$4);
            if ($$4) {
                this.m_355605_(serverlevel);
                if (blockstate.m_60713_(Blocks.f_50285_)) {
                    this.f_349141_.m_6025_(blockpos.m_123341_(), blockpos.m_123342_(), blockpos.m_123343_(), blockstate.m_61143_(PoweredRailBlock.f_55215_));
                }
            } else {
                this.f_349141_.m_38163_(serverlevel);
            }

            this.f_349141_.m_352051_();
            this.m_353930_(0.0F);
            double d0 = this.f_349141_.f_19854_ - this.m_356065_();
            double d1 = this.f_349141_.f_19856_ - this.m_353526_();
            if (d0 * d0 + d1 * d1 > 0.001) {
                this.m_356170_((float)(Mth.m_14136_(d1, d0) * 180.0 / Math.PI));
                if (this.f_349141_.m_357074_()) {
                    this.m_356170_(this.m_354728_() + 180.0F);
                }
            }

            double d2 = (double)Mth.m_14177_(this.m_354728_() - this.f_349141_.f_19859_);
            if (d2 < -170.0 || d2 >= 170.0) {
                this.m_356170_(this.m_354728_() + 180.0F);
                this.f_349141_.m_355593_(!this.f_349141_.m_357074_());
            }

            this.m_353930_(this.m_353360_() % 360.0F);
            this.m_356170_(this.m_354728_() % 360.0F);
            this.m_354637_();
        } else {
            if (this.f_346356_ > 0) {
                this.f_349141_.m_293725_(this.f_346356_, this.f_347355_, this.f_348650_, this.f_348427_, this.f_346480_, this.f_348221_);
                this.f_346356_--;
            } else {
                this.f_349141_.m_20090_();
                this.m_353930_(this.m_353360_() % 360.0F);
                this.m_356170_(this.m_354728_() % 360.0F);
            }
        }
    }

    @Override
    public void m_355605_(ServerLevel p_366781_) {
        BlockPos blockpos = this.f_349141_.m_356679_();
        BlockState blockstate = this.m_354883_().m_8055_(blockpos);
        this.f_349141_.m_183634_();
        double d0 = this.f_349141_.m_20185_();
        double d1 = this.f_349141_.m_20186_();
        double d2 = this.f_349141_.m_20189_();
        Vec3 vec3 = this.m_351822_(d0, d1, d2);
        d1 = (double)blockpos.m_123342_();
        boolean flag = false;
        boolean flag1 = false;
        if (blockstate.m_60713_(Blocks.f_50030_)) {
            flag = blockstate.m_61143_(PoweredRailBlock.f_55215_);
            flag1 = !flag;
        }

        double d3 = 0.0078125;
        if (this.f_349141_.m_20069_()) {
            d3 *= 0.2;
        }

        Vec3 vec31 = this.m_355278_();
        RailShape railshape = blockstate.m_61143_(((BaseRailBlock)blockstate.m_60734_()).m_7978_());
        switch (railshape) {
            case ASCENDING_EAST:
                this.m_357144_(vec31.m_82520_(-d3, 0.0, 0.0));
                d1++;
                break;
            case ASCENDING_WEST:
                this.m_357144_(vec31.m_82520_(d3, 0.0, 0.0));
                d1++;
                break;
            case ASCENDING_NORTH:
                this.m_357144_(vec31.m_82520_(0.0, 0.0, d3));
                d1++;
                break;
            case ASCENDING_SOUTH:
                this.m_357144_(vec31.m_82520_(0.0, 0.0, -d3));
                d1++;
        }

        vec31 = this.m_355278_();
        Pair<Vec3i, Vec3i> pair = AbstractMinecart.m_38125_(railshape);
        Vec3i vec3i = pair.getFirst();
        Vec3i vec3i1 = pair.getSecond();
        double d4 = (double)(vec3i1.m_123341_() - vec3i.m_123341_());
        double d5 = (double)(vec3i1.m_123343_() - vec3i.m_123343_());
        double d6 = Math.sqrt(d4 * d4 + d5 * d5);
        double d7 = vec31.f_82479_ * d4 + vec31.f_82481_ * d5;
        if (d7 < 0.0) {
            d4 = -d4;
            d5 = -d5;
        }

        double d8 = Math.min(2.0, vec31.m_165924_());
        vec31 = new Vec3(d8 * d4 / d6, vec31.f_82480_, d8 * d5 / d6);
        this.m_357144_(vec31);
        Entity entity = this.f_349141_.m_146895_();
        Vec3 vec32;
        if (this.f_349141_.m_146895_() instanceof ServerPlayer serverplayer) {
            vec32 = serverplayer.m_352862_();
        } else {
            vec32 = Vec3.f_82478_;
        }

        if (entity instanceof Player && vec32.m_82556_() > 0.0) {
            Vec3 vec35 = vec32.m_82541_();
            double d22 = this.m_355278_().m_165925_();
            if (vec35.m_82556_() > 0.0 && d22 < 0.01) {
                this.m_357144_(this.m_355278_().m_82520_(vec32.f_82479_ * 0.001, 0.0, vec32.f_82481_ * 0.001));
                flag1 = false;
            }
        }

        if (flag1) {
            double d20 = this.m_355278_().m_165924_();
            if (d20 < 0.03) {
                this.m_357144_(Vec3.f_82478_);
            } else {
                this.m_357144_(this.m_355278_().m_82542_(0.5, 0.0, 0.5));
            }
        }

        double d21 = (double)blockpos.m_123341_() + 0.5 + (double)vec3i.m_123341_() * 0.5;
        double d9 = (double)blockpos.m_123343_() + 0.5 + (double)vec3i.m_123343_() * 0.5;
        double d10 = (double)blockpos.m_123341_() + 0.5 + (double)vec3i1.m_123341_() * 0.5;
        double d11 = (double)blockpos.m_123343_() + 0.5 + (double)vec3i1.m_123343_() * 0.5;
        d4 = d10 - d21;
        d5 = d11 - d9;
        double d12;
        if (d4 == 0.0) {
            d12 = d2 - (double)blockpos.m_123343_();
        } else if (d5 == 0.0) {
            d12 = d0 - (double)blockpos.m_123341_();
        } else {
            double d13 = d0 - d21;
            double d14 = d2 - d9;
            d12 = (d13 * d4 + d14 * d5) * 2.0;
        }

        d0 = d21 + d4 * d12;
        d2 = d9 + d5 * d12;
        this.m_352338_(d0, d1, d2);
        double d23 = this.f_349141_.m_20160_() ? 0.75 : 1.0;
        double d24 = this.f_349141_.m_7097_(p_366781_);
        vec31 = this.m_355278_();
        this.f_349141_.m_6478_(MoverType.SELF, new Vec3(Mth.m_14008_(d23 * vec31.f_82479_, -d24, d24), 0.0, Mth.m_14008_(d23 * vec31.f_82481_, -d24, d24)));
        if (vec3i.m_123342_() != 0
            && Mth.m_14107_(this.f_349141_.m_20185_()) - blockpos.m_123341_() == vec3i.m_123341_()
            && Mth.m_14107_(this.f_349141_.m_20189_()) - blockpos.m_123343_() == vec3i.m_123343_()) {
            this.m_352338_(this.f_349141_.m_20185_(), this.f_349141_.m_20186_() + (double)vec3i.m_123342_(), this.f_349141_.m_20189_());
        } else if (vec3i1.m_123342_() != 0
            && Mth.m_14107_(this.f_349141_.m_20185_()) - blockpos.m_123341_() == vec3i1.m_123341_()
            && Mth.m_14107_(this.f_349141_.m_20189_()) - blockpos.m_123343_() == vec3i1.m_123343_()) {
            this.m_352338_(this.f_349141_.m_20185_(), this.f_349141_.m_20186_() + (double)vec3i1.m_123342_(), this.f_349141_.m_20189_());
        }

        this.m_357144_(this.f_349141_.m_7114_(this.m_355278_()));
        Vec3 vec33 = this.m_351822_(this.f_349141_.m_20185_(), this.f_349141_.m_20186_(), this.f_349141_.m_20189_());
        if (vec33 != null && vec3 != null) {
            double d15 = (vec3.f_82480_ - vec33.f_82480_) * 0.05;
            Vec3 vec34 = this.m_355278_();
            double d16 = vec34.m_165924_();
            if (d16 > 0.0) {
                this.m_357144_(vec34.m_82542_((d16 + d15) / d16, 1.0, (d16 + d15) / d16));
            }

            this.m_352338_(this.f_349141_.m_20185_(), vec33.f_82480_, this.f_349141_.m_20189_());
        }

        int j = Mth.m_14107_(this.f_349141_.m_20185_());
        int i = Mth.m_14107_(this.f_349141_.m_20189_());
        if (j != blockpos.m_123341_() || i != blockpos.m_123343_()) {
            Vec3 vec36 = this.m_355278_();
            double d25 = vec36.m_165924_();
            this.m_351809_(d25 * (double)(j - blockpos.m_123341_()), vec36.f_82480_, d25 * (double)(i - blockpos.m_123343_()));
        }

        if (flag) {
            Vec3 vec37 = this.m_355278_();
            double d26 = vec37.m_165924_();
            if (d26 > 0.01) {
                double d17 = 0.06;
                this.m_357144_(vec37.m_82520_(vec37.f_82479_ / d26 * 0.06, 0.0, vec37.f_82481_ / d26 * 0.06));
            } else {
                Vec3 vec38 = this.m_355278_();
                double d18 = vec38.f_82479_;
                double d19 = vec38.f_82481_;
                if (railshape == RailShape.EAST_WEST) {
                    if (this.f_349141_.m_38129_(blockpos.m_122024_())) {
                        d18 = 0.02;
                    } else if (this.f_349141_.m_38129_(blockpos.m_122029_())) {
                        d18 = -0.02;
                    }
                } else {
                    if (railshape != RailShape.NORTH_SOUTH) {
                        return;
                    }

                    if (this.f_349141_.m_38129_(blockpos.m_122012_())) {
                        d19 = 0.02;
                    } else if (this.f_349141_.m_38129_(blockpos.m_122019_())) {
                        d19 = -0.02;
                    }
                }

                this.m_351809_(d18, vec38.f_82480_, d19);
            }
        }
    }

    @Nullable
    public Vec3 m_355656_(double p_361728_, double p_364195_, double p_366610_, double p_364609_) {
        int i = Mth.m_14107_(p_361728_);
        int j = Mth.m_14107_(p_364195_);
        int k = Mth.m_14107_(p_366610_);
        if (this.m_354883_().m_8055_(new BlockPos(i, j - 1, k)).m_204336_(BlockTags.f_13034_)) {
            j--;
        }

        BlockState blockstate = this.m_354883_().m_8055_(new BlockPos(i, j, k));
        if (BaseRailBlock.m_49416_(blockstate)) {
            RailShape railshape = blockstate.m_61143_(((BaseRailBlock)blockstate.m_60734_()).m_7978_());
            p_364195_ = (double)j;
            if (railshape.m_61745_()) {
                p_364195_ = (double)(j + 1);
            }

            Pair<Vec3i, Vec3i> pair = AbstractMinecart.m_38125_(railshape);
            Vec3i vec3i = pair.getFirst();
            Vec3i vec3i1 = pair.getSecond();
            double d0 = (double)(vec3i1.m_123341_() - vec3i.m_123341_());
            double d1 = (double)(vec3i1.m_123343_() - vec3i.m_123343_());
            double d2 = Math.sqrt(d0 * d0 + d1 * d1);
            d0 /= d2;
            d1 /= d2;
            p_361728_ += d0 * p_364609_;
            p_366610_ += d1 * p_364609_;
            if (vec3i.m_123342_() != 0 && Mth.m_14107_(p_361728_) - i == vec3i.m_123341_() && Mth.m_14107_(p_366610_) - k == vec3i.m_123343_()) {
                p_364195_ += (double)vec3i.m_123342_();
            } else if (vec3i1.m_123342_() != 0 && Mth.m_14107_(p_361728_) - i == vec3i1.m_123341_() && Mth.m_14107_(p_366610_) - k == vec3i1.m_123343_()) {
                p_364195_ += (double)vec3i1.m_123342_();
            }

            return this.m_351822_(p_361728_, p_364195_, p_366610_);
        } else {
            return null;
        }
    }

    @Nullable
    public Vec3 m_351822_(double p_364250_, double p_361662_, double p_364713_) {
        int i = Mth.m_14107_(p_364250_);
        int j = Mth.m_14107_(p_361662_);
        int k = Mth.m_14107_(p_364713_);
        if (this.m_354883_().m_8055_(new BlockPos(i, j - 1, k)).m_204336_(BlockTags.f_13034_)) {
            j--;
        }

        BlockState blockstate = this.m_354883_().m_8055_(new BlockPos(i, j, k));
        if (BaseRailBlock.m_49416_(blockstate)) {
            RailShape railshape = blockstate.m_61143_(((BaseRailBlock)blockstate.m_60734_()).m_7978_());
            Pair<Vec3i, Vec3i> pair = AbstractMinecart.m_38125_(railshape);
            Vec3i vec3i = pair.getFirst();
            Vec3i vec3i1 = pair.getSecond();
            double d0 = (double)i + 0.5 + (double)vec3i.m_123341_() * 0.5;
            double d1 = (double)j + 0.0625 + (double)vec3i.m_123342_() * 0.5;
            double d2 = (double)k + 0.5 + (double)vec3i.m_123343_() * 0.5;
            double d3 = (double)i + 0.5 + (double)vec3i1.m_123341_() * 0.5;
            double d4 = (double)j + 0.0625 + (double)vec3i1.m_123342_() * 0.5;
            double d5 = (double)k + 0.5 + (double)vec3i1.m_123343_() * 0.5;
            double d6 = d3 - d0;
            double d7 = (d4 - d1) * 2.0;
            double d8 = d5 - d2;
            double d9;
            if (d6 == 0.0) {
                d9 = p_364713_ - (double)k;
            } else if (d8 == 0.0) {
                d9 = p_364250_ - (double)i;
            } else {
                double d10 = p_364250_ - d0;
                double d11 = p_364713_ - d2;
                d9 = (d10 * d6 + d11 * d8) * 2.0;
            }

            p_364250_ = d0 + d6 * d9;
            p_361662_ = d1 + d7 * d9;
            p_364713_ = d2 + d8 * d9;
            if (d7 < 0.0) {
                p_361662_++;
            } else if (d7 > 0.0) {
                p_361662_ += 0.5;
            }

            return new Vec3(p_364250_, p_361662_, p_364713_);
        } else {
            return null;
        }
    }

    @Override
    public double m_353264_(BlockPos p_362453_, RailShape p_361823_, double p_366695_) {
        return 0.0;
    }

    @Override
    public boolean m_354637_() {
        AABB aabb = this.f_349141_.m_20191_().m_82377_(0.2F, 0.0, 0.2F);
        if (this.f_349141_.m_354195_() && this.m_355278_().m_165925_() >= 0.01) {
            List<Entity> list = this.m_354883_().m_6249_(this.f_349141_, aabb, EntitySelector.m_20421_(this.f_349141_));
            if (!list.isEmpty()) {
                for (Entity entity1 : list) {
                    if (!(entity1 instanceof Player)
                        && !(entity1 instanceof IronGolem)
                        && !(entity1 instanceof AbstractMinecart)
                        && !this.f_349141_.m_20160_()
                        && !entity1.m_20159_()) {
                        entity1.m_20329_(this.f_349141_);
                    } else {
                        entity1.m_7334_(this.f_349141_);
                    }
                }
            }
        } else {
            for (Entity entity : this.m_354883_().m_45933_(this.f_349141_, aabb)) {
                if (!this.f_349141_.m_20363_(entity) && entity.m_6094_() && entity instanceof AbstractMinecart) {
                    entity.m_7334_(this.f_349141_);
                }
            }
        }

        return false;
    }

    @Override
    public Direction m_351880_() {
        return this.f_349141_.m_357074_() ? this.f_349141_.m_6350_().m_122424_().m_122427_() : this.f_349141_.m_6350_().m_122427_();
    }

    @Override
    public Vec3 m_353032_(Vec3 p_367615_) {
        return new Vec3(Mth.m_14008_(p_367615_.f_82479_, -0.4, 0.4), p_367615_.f_82480_, Mth.m_14008_(p_367615_.f_82481_, -0.4, 0.4));
    }

    @Override
    public double m_351896_(ServerLevel p_362914_) {
        return this.f_349141_.m_20069_() ? 0.2 : 0.4;
    }

    @Override
    public double m_353778_() {
        return this.f_349141_.m_20160_() ? 0.997 : 0.96;
    }
}