package net.minecraft.world.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.phys.Vec3;

public abstract class PathfinderMob extends Mob {
    protected static final float f_186010_ = 0.0F;

    protected PathfinderMob(EntityType<? extends PathfinderMob> p_21683_, Level p_21684_) {
        super(p_21683_, p_21684_);
    }

    public float m_21692_(BlockPos p_21693_) {
        return this.m_5610_(p_21693_, this.m_9236_());
    }

    public float m_5610_(BlockPos p_21688_, LevelReader p_21689_) {
        return 0.0F;
    }

    @Override
    public boolean m_5545_(LevelAccessor p_21686_, EntitySpawnReason p_368415_) {
        return this.m_5610_(this.m_20183_(), p_21686_) >= 0.0F;
    }

    public boolean m_21691_() {
        return !this.m_21573_().m_26571_();
    }

    public boolean m_293628_() {
        if (this.f_20939_.m_21874_(MemoryModuleType.f_217768_)) {
            return this.f_20939_.m_21952_(MemoryModuleType.f_217768_).isPresent();
        } else {
            for (WrappedGoal wrappedgoal : this.f_21345_.m_148105_()) {
                if (wrappedgoal.m_7620_() && wrappedgoal.m_26015_() instanceof PanicGoal) {
                    return true;
                }
            }

            return false;
        }
    }

    protected boolean m_213814_() {
        return true;
    }

    @Override
    public void m_338827_(Entity p_343614_) {
        super.m_338827_(p_343614_);
        if (this.m_213814_() && !this.m_293628_()) {
            this.f_21345_.m_25374_(Goal.Flag.MOVE);
            float f = 2.0F;
            float f1 = this.m_20270_(p_343614_);
            Vec3 vec3 = new Vec3(p_343614_.m_20185_() - this.m_20185_(), p_343614_.m_20186_() - this.m_20186_(), p_343614_.m_20189_() - this.m_20189_())
                .m_82541_()
                .m_82490_((double)Math.max(f1 - 2.0F, 0.0F));
            this.m_21573_().m_26519_(this.m_20185_() + vec3.f_82479_, this.m_20186_() + vec3.f_82480_, this.m_20189_() + vec3.f_82481_, this.m_5823_());
        }
    }

    @Override
    public boolean m_338665_(Entity p_342865_, float p_344226_) {
        this.m_21446_(p_342865_.m_20183_(), 5);
        return true;
    }

    protected double m_5823_() {
        return 1.0;
    }
}