package net.minecraft.world.entity;

import io.netty.buffer.ByteBuf;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

public enum Relative {
    X(0),
    Y(1),
    Z(2),
    Y_ROT(3),
    X_ROT(4),
    DELTA_X(5),
    DELTA_Y(6),
    DELTA_Z(7),
    ROTATE_DELTA(8);

    public static final Set<Relative> f_348476_ = Set.of(values());
    public static final Set<Relative> f_349537_ = Set.of(X_ROT, Y_ROT);
    public static final Set<Relative> f_347586_ = Set.of(DELTA_X, DELTA_Y, DELTA_Z, ROTATE_DELTA);
    public static final StreamCodec<ByteBuf, Set<Relative>> f_347494_ = ByteBufCodecs.f_316612_.m_323038_(Relative::m_355792_, Relative::m_354009_);
    private final int f_348125_;

    @SafeVarargs
    public static Set<Relative> m_355984_(Set<Relative>... p_360861_) {
        HashSet<Relative> hashset = new HashSet<>();

        for (Set<Relative> set : p_360861_) {
            hashset.addAll(set);
        }

        return hashset;
    }

    private Relative(final int p_367418_) {
        this.f_348125_ = p_367418_;
    }

    private int m_354014_() {
        return 1 << this.f_348125_;
    }

    private boolean m_355932_(int p_364108_) {
        return (p_364108_ & this.m_354014_()) == this.m_354014_();
    }

    public static Set<Relative> m_355792_(int p_366469_) {
        Set<Relative> set = EnumSet.noneOf(Relative.class);

        for (Relative relative : values()) {
            if (relative.m_355932_(p_366469_)) {
                set.add(relative);
            }
        }

        return set;
    }

    public static int m_354009_(Set<Relative> p_370231_) {
        int i = 0;

        for (Relative relative : p_370231_) {
            i |= relative.m_354014_();
        }

        return i;
    }
}