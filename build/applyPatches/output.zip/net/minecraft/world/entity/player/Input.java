package net.minecraft.world.entity.player;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;

public record Input(boolean f_347331_, boolean f_346889_, boolean f_349339_, boolean f_347707_, boolean f_348085_, boolean f_347762_, boolean f_348481_) {
    private static final byte f_347433_ = 1;
    private static final byte f_348732_ = 2;
    private static final byte f_348415_ = 4;
    private static final byte f_347556_ = 8;
    private static final byte f_346727_ = 16;
    private static final byte f_348226_ = 32;
    private static final byte f_349516_ = 64;
    public static final StreamCodec<FriendlyByteBuf, Input> f_347303_ = new StreamCodec<FriendlyByteBuf, Input>() {
        public void m_318638_(FriendlyByteBuf p_362132_, Input p_369013_) {
            byte b0 = 0;
            b0 = (byte)(b0 | (p_369013_.f_347331_() ? 1 : 0));
            b0 = (byte)(b0 | (p_369013_.f_346889_() ? 2 : 0));
            b0 = (byte)(b0 | (p_369013_.f_349339_() ? 4 : 0));
            b0 = (byte)(b0 | (p_369013_.f_347707_() ? 8 : 0));
            b0 = (byte)(b0 | (p_369013_.f_348085_() ? 16 : 0));
            b0 = (byte)(b0 | (p_369013_.f_347762_() ? 32 : 0));
            b0 = (byte)(b0 | (p_369013_.f_348481_() ? 64 : 0));
            p_362132_.writeByte(b0);
        }

        public Input m_318688_(FriendlyByteBuf p_366245_) {
            byte b0 = p_366245_.readByte();
            boolean flag = (b0 & 1) != 0;
            boolean flag1 = (b0 & 2) != 0;
            boolean flag2 = (b0 & 4) != 0;
            boolean flag3 = (b0 & 8) != 0;
            boolean flag4 = (b0 & 16) != 0;
            boolean flag5 = (b0 & 32) != 0;
            boolean flag6 = (b0 & 64) != 0;
            return new Input(flag, flag1, flag2, flag3, flag4, flag5, flag6);
        }
    };
    public static Input f_346647_ = new Input(false, false, false, false, false, false, false);
}