package net.minecraft.world.entity.animal;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.pathfinder.PathType;

public abstract class AgeableWaterCreature extends AgeableMob {
    protected AgeableWaterCreature(EntityType<? extends AgeableWaterCreature> p_367291_, Level p_361850_) {
        super(p_367291_, p_361850_);
        this.m_21441_(PathType.WATER, 0.0F);
    }

    @Override
    public boolean m_6914_(LevelReader p_364787_) {
        return p_364787_.m_45784_(this);
    }

    @Override
    public int m_8100_() {
        return 120;
    }

    @Override
    public int m_213860_(ServerLevel p_361071_) {
        return 1 + this.f_19796_.m_188503_(3);
    }

    protected void m_28325_(int p_366101_) {
        if (this.m_6084_() && !this.m_20072_()) {
            this.m_20301_(p_366101_ - 1);
            if (this.m_20146_() == -20) {
                this.m_20301_(0);
                this.m_6469_(this.m_269291_().m_269063_(), 2.0F);
            }
        } else {
            this.m_20301_(300);
        }
    }

    @Override
    public void m_6075_() {
        int i = this.m_20146_();
        super.m_6075_();
        this.m_28325_(i);
    }

    @Override
    public boolean m_6063_() {
        return false;
    }

    @Override
    public boolean m_6573_() {
        return false;
    }

    public static boolean m_353055_(
        EntityType<? extends AgeableWaterCreature> p_369363_, LevelAccessor p_370080_, EntitySpawnReason p_367384_, BlockPos p_370200_, RandomSource p_362509_
    ) {
        int i = p_370080_.m_5736_();
        int j = i - 13;
        return p_370200_.m_123342_() >= j
            && p_370200_.m_123342_() <= i
            && p_370080_.m_6425_(p_370200_.m_7495_()).m_205070_(FluidTags.f_13131_)
            && p_370080_.m_8055_(p_370200_.m_7494_()).m_60713_(Blocks.f_49990_);
    }
}