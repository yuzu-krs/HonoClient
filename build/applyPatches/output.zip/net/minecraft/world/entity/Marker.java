package net.minecraft.world.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.PushReaction;

public class Marker extends Entity {
    private static final String f_147247_ = "data";
    private CompoundTag f_147248_ = new CompoundTag();

    public Marker(EntityType<?> p_147250_, Level p_147251_) {
        super(p_147250_, p_147251_);
        this.f_19794_ = true;
    }

    @Override
    public void m_8119_() {
    }

    @Override
    protected void m_8097_(SynchedEntityData.Builder p_334647_) {
    }

    @Override
    protected void m_7378_(CompoundTag p_147254_) {
        this.f_147248_ = p_147254_.m_128469_("data");
    }

    @Override
    protected void m_7380_(CompoundTag p_147257_) {
        p_147257_.m_128365_("data", this.f_147248_.m_6426_());
    }

    @Override
    public Packet<ClientGamePacketListener> m_5654_(ServerEntity p_345137_) {
        throw new IllegalStateException("Markers should never be sent");
    }

    @Override
    protected boolean m_7310_(Entity p_265289_) {
        return false;
    }

    @Override
    protected boolean m_269011_() {
        return false;
    }

    @Override
    protected void m_20348_(Entity p_270306_) {
        throw new IllegalStateException("Should never addPassenger without checking couldAcceptPassenger()");
    }

    @Override
    public PushReaction m_7752_() {
        return PushReaction.IGNORE;
    }

    @Override
    public boolean m_6090_() {
        return true;
    }

    @Override
    public final boolean m_351622_(ServerLevel p_366204_, DamageSource p_366965_, float p_363917_) {
        return false;
    }
}