package net.minecraft.world.inventory;

import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.StringUtil;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AnvilBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.slf4j.Logger;

public class AnvilMenu extends ItemCombinerMenu {
    public static final int f_265994_ = 0;
    public static final int f_265986_ = 1;
    public static final int f_266102_ = 2;
    private static final Logger f_38999_ = LogUtils.getLogger();
    private static final boolean f_150469_ = false;
    public static final int f_150468_ = 50;
    private int f_39000_;
    @Nullable
    private String f_39001_;
    private final DataSlot f_39002_ = DataSlot.m_39401_();
    private boolean f_346523_ = false;
    private static final int f_150470_ = 0;
    private static final int f_150471_ = 1;
    private static final int f_150472_ = 1;
    private static final int f_150464_ = 1;
    private static final int f_150465_ = 2;
    private static final int f_150466_ = 1;
    private static final int f_150467_ = 1;
    private static final int f_265898_ = 27;
    private static final int f_265878_ = 76;
    private static final int f_265992_ = 134;
    private static final int f_266013_ = 47;

    public AnvilMenu(int p_39005_, Inventory p_39006_) {
        this(p_39005_, p_39006_, ContainerLevelAccess.f_39287_);
    }

    public AnvilMenu(int p_39008_, Inventory p_39009_, ContainerLevelAccess p_39010_) {
        super(MenuType.f_39964_, p_39008_, p_39009_, p_39010_, m_266369_());
        this.m_38895_(this.f_39002_);
    }

    private static ItemCombinerMenuSlotDefinition m_266369_() {
        return ItemCombinerMenuSlotDefinition.m_266303_()
            .m_266197_(0, 27, 47, p_266635_ -> true)
            .m_266197_(1, 76, 47, p_266634_ -> true)
            .m_266198_(2, 134, 47)
            .m_266441_();
    }

    @Override
    protected boolean m_8039_(BlockState p_39019_) {
        return p_39019_.m_204336_(BlockTags.f_13033_);
    }

    @Override
    protected boolean m_6560_(Player p_39023_, boolean p_39024_) {
        return (p_39023_.m_322042_() || p_39023_.f_36078_ >= this.f_39002_.m_6501_()) && this.f_39002_.m_6501_() > 0;
    }

    @Override
    protected void m_142365_(Player p_150474_, ItemStack p_150475_) {
        if (!p_150474_.m_150110_().f_35937_) {
            p_150474_.m_6749_(-this.f_39002_.m_6501_());
        }

        if (this.f_39000_ > 0) {
            ItemStack itemstack = this.f_39769_.m_8020_(1);
            if (!itemstack.m_41619_() && itemstack.m_41613_() > this.f_39000_) {
                itemstack.m_41774_(this.f_39000_);
                this.f_39769_.m_6836_(1, itemstack);
            } else {
                this.f_39769_.m_6836_(1, ItemStack.f_41583_);
            }
        } else if (!this.f_346523_) {
            this.f_39769_.m_6836_(1, ItemStack.f_41583_);
        }

        this.f_39002_.m_6422_(0);
        this.f_39769_.m_6836_(0, ItemStack.f_41583_);
        this.f_39770_.m_39292_((p_150479_, p_150480_) -> {
            BlockState blockstate = p_150479_.m_8055_(p_150480_);
            if (!p_150474_.m_322042_() && blockstate.m_204336_(BlockTags.f_13033_) && p_150474_.m_339477_().m_188501_() < 0.12F) {
                BlockState blockstate1 = AnvilBlock.m_48824_(blockstate);
                if (blockstate1 == null) {
                    p_150479_.m_7471_(p_150480_, false);
                    p_150479_.m_46796_(1029, p_150480_, 0);
                } else {
                    p_150479_.m_7731_(p_150480_, blockstate1, 2);
                    p_150479_.m_46796_(1030, p_150480_, 0);
                }
            } else {
                p_150479_.m_46796_(1030, p_150480_, 0);
            }
        });
    }

    @Override
    public void m_6640_() {
        ItemStack itemstack = this.f_39769_.m_8020_(0);
        this.f_346523_ = false;
        this.f_39002_.m_6422_(1);
        int i = 0;
        long j = 0L;
        int k = 0;
        if (!itemstack.m_41619_() && EnchantmentHelper.m_320740_(itemstack)) {
            ItemStack itemstack1 = itemstack.m_41777_();
            ItemStack itemstack2 = this.f_39769_.m_8020_(1);
            ItemEnchantments.Mutable itemenchantments$mutable = new ItemEnchantments.Mutable(EnchantmentHelper.m_324152_(itemstack1));
            j += (long)itemstack.m_322304_(DataComponents.f_315107_, Integer.valueOf(0)).intValue()
                + (long)itemstack2.m_322304_(DataComponents.f_315107_, Integer.valueOf(0)).intValue();
            this.f_39000_ = 0;
            if (!itemstack2.m_41619_()) {
                boolean flag = itemstack2.m_319951_(DataComponents.f_314515_);
                if (itemstack1.m_41763_() && itemstack.m_357103_(itemstack2)) {
                    int l2 = Math.min(itemstack1.m_41773_(), itemstack1.m_41776_() / 4);
                    if (l2 <= 0) {
                        this.f_39768_.m_6836_(0, ItemStack.f_41583_);
                        this.f_39002_.m_6422_(0);
                        return;
                    }

                    int j3;
                    for (j3 = 0; l2 > 0 && j3 < itemstack2.m_41613_(); j3++) {
                        int k3 = itemstack1.m_41773_() - l2;
                        itemstack1.m_41721_(k3);
                        i++;
                        l2 = Math.min(itemstack1.m_41773_(), itemstack1.m_41776_() / 4);
                    }

                    this.f_39000_ = j3;
                } else {
                    if (!flag && (!itemstack1.m_150930_(itemstack2.m_41720_()) || !itemstack1.m_41763_())) {
                        this.f_39768_.m_6836_(0, ItemStack.f_41583_);
                        this.f_39002_.m_6422_(0);
                        return;
                    }

                    if (itemstack1.m_41763_() && !flag) {
                        int l = itemstack.m_41776_() - itemstack.m_41773_();
                        int i1 = itemstack2.m_41776_() - itemstack2.m_41773_();
                        int j1 = i1 + itemstack1.m_41776_() * 12 / 100;
                        int k1 = l + j1;
                        int l1 = itemstack1.m_41776_() - k1;
                        if (l1 < 0) {
                            l1 = 0;
                        }

                        if (l1 < itemstack1.m_41773_()) {
                            itemstack1.m_41721_(l1);
                            i += 2;
                        }
                    }

                    ItemEnchantments itemenchantments = EnchantmentHelper.m_324152_(itemstack2);
                    boolean flag2 = false;
                    boolean flag3 = false;

                    for (Entry<Holder<Enchantment>> entry : itemenchantments.m_320130_()) {
                        Holder<Enchantment> holder = entry.getKey();
                        int i2 = itemenchantments$mutable.m_319403_(holder);
                        int j2 = entry.getIntValue();
                        j2 = i2 == j2 ? j2 + 1 : Math.max(j2, i2);
                        Enchantment enchantment = holder.m_203334_();
                        boolean flag1 = enchantment.m_6081_(itemstack);
                        if (this.f_39771_.m_150110_().f_35937_ || itemstack.m_150930_(Items.f_42690_)) {
                            flag1 = true;
                        }

                        for (Holder<Enchantment> holder1 : itemenchantments$mutable.m_318718_()) {
                            if (!holder1.equals(holder) && !Enchantment.m_339848_(holder, holder1)) {
                                flag1 = false;
                                i++;
                            }
                        }

                        if (!flag1) {
                            flag3 = true;
                        } else {
                            flag2 = true;
                            if (j2 > enchantment.m_6586_()) {
                                j2 = enchantment.m_6586_();
                            }

                            itemenchantments$mutable.m_319152_(holder, j2);
                            int l3 = enchantment.m_320305_();
                            if (flag) {
                                l3 = Math.max(1, l3 / 2);
                            }

                            i += l3 * j2;
                            if (itemstack.m_41613_() > 1) {
                                i = 40;
                            }
                        }
                    }

                    if (flag3 && !flag2) {
                        this.f_39768_.m_6836_(0, ItemStack.f_41583_);
                        this.f_39002_.m_6422_(0);
                        return;
                    }
                }
            }

            if (this.f_39001_ != null && !StringUtil.m_320314_(this.f_39001_)) {
                if (!this.f_39001_.equals(itemstack.m_41786_().getString())) {
                    k = 1;
                    i += k;
                    itemstack1.m_322496_(DataComponents.f_316016_, Component.m_237113_(this.f_39001_));
                }
            } else if (itemstack.m_319951_(DataComponents.f_316016_)) {
                k = 1;
                i += k;
                itemstack1.m_319322_(DataComponents.f_316016_);
            }

            int k2 = i <= 0 ? 0 : (int)Mth.m_295574_(j + (long)i, 0L, 2147483647L);
            this.f_39002_.m_6422_(k2);
            if (i <= 0) {
                itemstack1 = ItemStack.f_41583_;
            }

            if (k == i && k > 0) {
                if (this.f_39002_.m_6501_() >= 40) {
                    this.f_39002_.m_6422_(39);
                }

                this.f_346523_ = true;
            }

            if (this.f_39002_.m_6501_() >= 40 && !this.f_39771_.m_150110_().f_35937_) {
                itemstack1 = ItemStack.f_41583_;
            }

            if (!itemstack1.m_41619_()) {
                int i3 = itemstack1.m_322304_(DataComponents.f_315107_, Integer.valueOf(0));
                if (i3 < itemstack2.m_322304_(DataComponents.f_315107_, Integer.valueOf(0))) {
                    i3 = itemstack2.m_322304_(DataComponents.f_315107_, Integer.valueOf(0));
                }

                if (k != i || k == 0) {
                    i3 = m_39025_(i3);
                }

                itemstack1.m_322496_(DataComponents.f_315107_, i3);
                EnchantmentHelper.m_44865_(itemstack1, itemenchantments$mutable.m_321565_());
            }

            this.f_39768_.m_6836_(0, itemstack1);
            this.m_38946_();
        } else {
            this.f_39768_.m_6836_(0, ItemStack.f_41583_);
            this.f_39002_.m_6422_(0);
        }
    }

    public static int m_39025_(int p_39026_) {
        return (int)Math.min((long)p_39026_ * 2L + 1L, 2147483647L);
    }

    public boolean m_39020_(String p_288970_) {
        String s = m_288226_(p_288970_);
        if (s != null && !s.equals(this.f_39001_)) {
            this.f_39001_ = s;
            if (this.m_38853_(2).m_6657_()) {
                ItemStack itemstack = this.m_38853_(2).m_7993_();
                if (StringUtil.m_320314_(s)) {
                    itemstack.m_319322_(DataComponents.f_316016_);
                } else {
                    itemstack.m_322496_(DataComponents.f_316016_, Component.m_237113_(s));
                }
            }

            this.m_6640_();
            return true;
        } else {
            return false;
        }
    }

    @Nullable
    private static String m_288226_(String p_288995_) {
        String s = StringUtil.m_319203_(p_288995_);
        return s.length() <= 50 ? s : null;
    }

    public int m_39028_() {
        return this.f_39002_.m_6501_();
    }
}