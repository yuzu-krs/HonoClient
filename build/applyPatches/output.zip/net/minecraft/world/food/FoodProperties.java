package net.minecraft.world.food;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.component.ConsumableListener;
import net.minecraft.world.level.Level;

public record FoodProperties(int f_38723_, float f_315723_, boolean f_38726_) implements ConsumableListener {
    public static final Codec<FoodProperties> f_316600_ = RecordCodecBuilder.create(
        p_359368_ -> p_359368_.group(
                    ExtraCodecs.f_144628_.fieldOf("nutrition").forGetter(FoodProperties::f_38723_),
                    Codec.FLOAT.fieldOf("saturation").forGetter(FoodProperties::f_315723_),
                    Codec.BOOL.optionalFieldOf("can_always_eat", Boolean.valueOf(false)).forGetter(FoodProperties::f_38726_)
                )
                .apply(p_359368_, FoodProperties::new)
    );
    public static final StreamCodec<RegistryFriendlyByteBuf, FoodProperties> f_317144_ = StreamCodec.m_321516_(
        ByteBufCodecs.f_316730_,
        FoodProperties::f_38723_,
        ByteBufCodecs.f_314734_,
        FoodProperties::f_315723_,
        ByteBufCodecs.f_315514_,
        FoodProperties::f_38726_,
        FoodProperties::new
    );

    @Override
    public void m_352612_(Level p_369423_, LivingEntity p_368675_, ItemStack p_365501_, Consumable p_363411_) {
        RandomSource randomsource = p_368675_.m_339477_();
        p_369423_.m_6263_(
            null,
            p_368675_.m_20185_(),
            p_368675_.m_20186_(),
            p_368675_.m_20189_(),
            p_363411_.f_346592_().m_203334_(),
            SoundSource.NEUTRAL,
            1.0F,
            randomsource.m_357040_(1.0F, 0.4F)
        );
        if (p_368675_ instanceof Player player) {
            player.m_36324_().m_38712_(this);
            p_369423_.m_6263_(
                null,
                player.m_20185_(),
                player.m_20186_(),
                player.m_20189_(),
                SoundEvents.f_12321_,
                SoundSource.PLAYERS,
                0.5F,
                Mth.m_216283_(randomsource, 0.9F, 1.0F)
            );
        }
    }

    public static class Builder {
        private int f_38750_;
        private float f_38751_;
        private boolean f_38753_;

        public FoodProperties.Builder m_38760_(int p_38761_) {
            this.f_38750_ = p_38761_;
            return this;
        }

        public FoodProperties.Builder m_38758_(float p_38759_) {
            this.f_38751_ = p_38759_;
            return this;
        }

        public FoodProperties.Builder m_38765_() {
            this.f_38753_ = true;
            return this;
        }

        public FoodProperties m_38767_() {
            float f = FoodConstants.m_324902_(this.f_38750_, this.f_38751_);
            return new FoodProperties(this.f_38750_, f, this.f_38753_);
        }
    }
}