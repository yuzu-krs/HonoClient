package net.minecraft.world.effect;

import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class MobEffects {
    private static final int f_216965_ = 22;
    public static final Holder<MobEffect> f_19596_ = m_19623_(
        "speed",
        new MobEffect(MobEffectCategory.BENEFICIAL, 3402751)
            .m_19472_(Attributes.f_22279_, ResourceLocation.m_340282_("effect.speed"), 0.2F, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL)
    );
    public static final Holder<MobEffect> f_19597_ = m_19623_(
        "slowness",
        new MobEffect(MobEffectCategory.HARMFUL, 9154528)
            .m_19472_(Attributes.f_22279_, ResourceLocation.m_340282_("effect.slowness"), -0.15F, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL)
    );
    public static final Holder<MobEffect> f_19598_ = m_19623_(
        "haste",
        new MobEffect(MobEffectCategory.BENEFICIAL, 14270531)
            .m_19472_(Attributes.f_22283_, ResourceLocation.m_340282_("effect.haste"), 0.1F, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL)
    );
    public static final Holder<MobEffect> f_19599_ = m_19623_(
        "mining_fatigue",
        new MobEffect(MobEffectCategory.HARMFUL, 4866583)
            .m_19472_(Attributes.f_22283_, ResourceLocation.m_340282_("effect.mining_fatigue"), -0.1F, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL)
    );
    public static final Holder<MobEffect> f_19600_ = m_19623_(
        "strength",
        new MobEffect(MobEffectCategory.BENEFICIAL, 16762624)
            .m_19472_(Attributes.f_22281_, ResourceLocation.m_340282_("effect.strength"), 3.0, AttributeModifier.Operation.ADD_VALUE)
    );
    public static final Holder<MobEffect> f_19601_ = m_19623_("instant_health", new HealOrHarmMobEffect(MobEffectCategory.BENEFICIAL, 16262179, false));
    public static final Holder<MobEffect> f_19602_ = m_19623_("instant_damage", new HealOrHarmMobEffect(MobEffectCategory.HARMFUL, 11101546, true));
    public static final Holder<MobEffect> f_19603_ = m_19623_(
        "jump_boost",
        new MobEffect(MobEffectCategory.BENEFICIAL, 16646020)
            .m_19472_(Attributes.f_315184_, ResourceLocation.m_340282_("effect.jump_boost"), 1.0, AttributeModifier.Operation.ADD_VALUE)
    );
    public static final Holder<MobEffect> f_19604_ = m_19623_("nausea", new MobEffect(MobEffectCategory.HARMFUL, 5578058));
    public static final Holder<MobEffect> f_19605_ = m_19623_("regeneration", new RegenerationMobEffect(MobEffectCategory.BENEFICIAL, 13458603));
    public static final Holder<MobEffect> f_19606_ = m_19623_("resistance", new MobEffect(MobEffectCategory.BENEFICIAL, 9520880));
    public static final Holder<MobEffect> f_19607_ = m_19623_("fire_resistance", new MobEffect(MobEffectCategory.BENEFICIAL, 16750848));
    public static final Holder<MobEffect> f_19608_ = m_19623_("water_breathing", new MobEffect(MobEffectCategory.BENEFICIAL, 10017472));
    public static final Holder<MobEffect> f_19609_ = m_19623_("invisibility", new MobEffect(MobEffectCategory.BENEFICIAL, 16185078));
    public static final Holder<MobEffect> f_19610_ = m_19623_("blindness", new MobEffect(MobEffectCategory.HARMFUL, 2039587));
    public static final Holder<MobEffect> f_19611_ = m_19623_("night_vision", new MobEffect(MobEffectCategory.BENEFICIAL, 12779366));
    public static final Holder<MobEffect> f_19612_ = m_19623_("hunger", new HungerMobEffect(MobEffectCategory.HARMFUL, 5797459));
    public static final Holder<MobEffect> f_19613_ = m_19623_(
        "weakness",
        new MobEffect(MobEffectCategory.HARMFUL, 4738376)
            .m_19472_(Attributes.f_22281_, ResourceLocation.m_340282_("effect.weakness"), -4.0, AttributeModifier.Operation.ADD_VALUE)
    );
    public static final Holder<MobEffect> f_19614_ = m_19623_("poison", new PoisonMobEffect(MobEffectCategory.HARMFUL, 8889187));
    public static final Holder<MobEffect> f_19615_ = m_19623_("wither", new WitherMobEffect(MobEffectCategory.HARMFUL, 7561558));
    public static final Holder<MobEffect> f_19616_ = m_19623_(
        "health_boost",
        new MobEffect(MobEffectCategory.BENEFICIAL, 16284963)
            .m_19472_(Attributes.f_22276_, ResourceLocation.m_340282_("effect.health_boost"), 4.0, AttributeModifier.Operation.ADD_VALUE)
    );
    public static final Holder<MobEffect> f_19617_ = m_19623_(
        "absorption",
        new AbsorptionMobEffect(MobEffectCategory.BENEFICIAL, 2445989)
            .m_19472_(Attributes.f_290864_, ResourceLocation.m_340282_("effect.absorption"), 4.0, AttributeModifier.Operation.ADD_VALUE)
    );
    public static final Holder<MobEffect> f_19618_ = m_19623_("saturation", new SaturationMobEffect(MobEffectCategory.BENEFICIAL, 16262179));
    public static final Holder<MobEffect> f_19619_ = m_19623_("glowing", new MobEffect(MobEffectCategory.NEUTRAL, 9740385));
    public static final Holder<MobEffect> f_19620_ = m_19623_("levitation", new MobEffect(MobEffectCategory.HARMFUL, 13565951));
    public static final Holder<MobEffect> f_19621_ = m_19623_(
        "luck",
        new MobEffect(MobEffectCategory.BENEFICIAL, 5882118)
            .m_19472_(Attributes.f_22286_, ResourceLocation.m_340282_("effect.luck"), 1.0, AttributeModifier.Operation.ADD_VALUE)
    );
    public static final Holder<MobEffect> f_19590_ = m_19623_(
        "unluck",
        new MobEffect(MobEffectCategory.HARMFUL, 12624973)
            .m_19472_(Attributes.f_22286_, ResourceLocation.m_340282_("effect.unluck"), -1.0, AttributeModifier.Operation.ADD_VALUE)
    );
    public static final Holder<MobEffect> f_19591_ = m_19623_("slow_falling", new MobEffect(MobEffectCategory.BENEFICIAL, 15978425));
    public static final Holder<MobEffect> f_19592_ = m_19623_("conduit_power", new MobEffect(MobEffectCategory.BENEFICIAL, 1950417));
    public static final Holder<MobEffect> f_19593_ = m_19623_("dolphins_grace", new MobEffect(MobEffectCategory.BENEFICIAL, 8954814));
    public static final Holder<MobEffect> f_19594_ = m_19623_(
        "bad_omen", new BadOmenMobEffect(MobEffectCategory.NEUTRAL, 745784).m_320304_(SoundEvents.f_315320_)
    );
    public static final Holder<MobEffect> f_19595_ = m_19623_("hero_of_the_village", new MobEffect(MobEffectCategory.BENEFICIAL, 4521796));
    public static final Holder<MobEffect> f_216964_ = m_19623_("darkness", new MobEffect(MobEffectCategory.HARMFUL, 2696993).m_321800_(22));
    public static final Holder<MobEffect> f_316051_ = m_19623_(
        "trial_omen", new MobEffect(MobEffectCategory.NEUTRAL, 1484454, ParticleTypes.f_317125_).m_320304_(SoundEvents.f_314995_)
    );
    public static final Holder<MobEffect> f_314945_ = m_19623_(
        "raid_omen", new RaidOmenMobEffect(MobEffectCategory.NEUTRAL, 14565464, ParticleTypes.f_314966_).m_320304_(SoundEvents.f_315515_)
    );
    public static final Holder<MobEffect> f_316711_ = m_19623_("wind_charged", new WindChargedMobEffect(MobEffectCategory.HARMFUL, 12438015));
    public static final Holder<MobEffect> f_315811_ = m_19623_(
        "weaving", new WeavingMobEffect(MobEffectCategory.HARMFUL, 7891290, p_326758_ -> Mth.m_216287_(p_326758_, 2, 3))
    );
    public static final Holder<MobEffect> f_314285_ = m_19623_("oozing", new OozingMobEffect(MobEffectCategory.HARMFUL, 10092451, p_326759_ -> 2));
    public static final Holder<MobEffect> f_316729_ = m_19623_(
        "infested", new InfestedMobEffect(MobEffectCategory.HARMFUL, 9214860, 0.1F, p_326757_ -> Mth.m_216287_(p_326757_, 1, 2))
    );

    private static Holder<MobEffect> m_19623_(String p_19625_, MobEffect p_19626_) {
        return Registry.m_263174_(BuiltInRegistries.f_256974_, ResourceLocation.m_340282_(p_19625_), p_19626_);
    }

    public static Holder<MobEffect> m_321241_(Registry<MobEffect> p_328044_) {
        return f_19596_;
    }
}