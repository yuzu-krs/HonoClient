package net.minecraft.world.item.crafting.display;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

public record RecipeDisplayId(int f_347292_) {
    public static final StreamCodec<ByteBuf, RecipeDisplayId> f_348632_ = StreamCodec.m_322204_(
        ByteBufCodecs.f_316730_, RecipeDisplayId::f_347292_, RecipeDisplayId::new
    );
}