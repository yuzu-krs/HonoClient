package net.minecraft.world.item.crafting;

import java.util.List;
import java.util.Optional;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.display.SlotDisplay;

public record SelectableRecipe<T extends Recipe<?>>(SlotDisplay f_349408_, Optional<RecipeHolder<T>> f_346239_) {
    public static <T extends Recipe<?>> StreamCodec<RegistryFriendlyByteBuf, SelectableRecipe<T>> m_352063_() {
        return StreamCodec.m_322204_(SlotDisplay.f_347576_, SelectableRecipe::f_349408_, p_367448_ -> new SelectableRecipe<>(p_367448_, Optional.empty()));
    }

    public static record SingleInputEntry<T extends Recipe<?>>(Ingredient f_348227_, SelectableRecipe<T> f_347759_) {
        public static <T extends Recipe<?>> StreamCodec<RegistryFriendlyByteBuf, SelectableRecipe.SingleInputEntry<T>> m_355609_() {
            return StreamCodec.m_320349_(
                Ingredient.f_317040_,
                SelectableRecipe.SingleInputEntry::f_348227_,
                SelectableRecipe.<T>m_352063_(),
                SelectableRecipe.SingleInputEntry::f_347759_,
                SelectableRecipe.SingleInputEntry::new
            );
        }
    }

    public static record SingleInputSet<T extends Recipe<?>>(List<SelectableRecipe.SingleInputEntry<T>> f_347473_) {
        public static <T extends Recipe<?>> SelectableRecipe.SingleInputSet<T> m_355921_() {
            return new SelectableRecipe.SingleInputSet<>(List.of());
        }

        public static <T extends Recipe<?>> StreamCodec<RegistryFriendlyByteBuf, SelectableRecipe.SingleInputSet<T>> m_352126_() {
            return StreamCodec.m_322204_(
                SelectableRecipe.SingleInputEntry.<T>m_355609_().m_321801_(ByteBufCodecs.m_324765_()),
                SelectableRecipe.SingleInputSet::f_347473_,
                SelectableRecipe.SingleInputSet::new
            );
        }

        public boolean m_354278_(ItemStack p_366997_) {
            return this.f_347473_.stream().anyMatch(p_368592_ -> p_368592_.f_348227_.test(p_366997_));
        }

        public SelectableRecipe.SingleInputSet<T> m_356983_(ItemStack p_368693_) {
            return new SelectableRecipe.SingleInputSet<>(this.f_347473_.stream().filter(p_364349_ -> p_364349_.f_348227_.test(p_368693_)).toList());
        }

        public boolean m_353342_() {
            return this.f_347473_.isEmpty();
        }

        public int m_354361_() {
            return this.f_347473_.size();
        }
    }
}
