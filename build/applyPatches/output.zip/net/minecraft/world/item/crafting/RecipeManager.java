package net.minecraft.world.item.crafting;

import com.google.common.annotations.VisibleForTesting;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.JsonOps;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.item.crafting.display.RecipeDisplay;
import net.minecraft.world.item.crafting.display.RecipeDisplayEntry;
import net.minecraft.world.item.crafting.display.RecipeDisplayId;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;

public class RecipeManager extends SimplePreparableReloadListener<RecipeMap> implements RecipeAccess {
    private static final Logger f_44006_ = LogUtils.getLogger();
    private static final Map<ResourceKey<RecipePropertySet>, RecipeManager.IngredientExtractor> f_347382_ = Map.of(
        RecipePropertySet.f_348593_,
        p_359832_ -> p_359832_ instanceof SmithingRecipe smithingrecipe ? smithingrecipe.m_352299_() : Optional.empty(),
        RecipePropertySet.f_346456_,
        p_359827_ -> p_359827_ instanceof SmithingRecipe smithingrecipe ? smithingrecipe.m_354833_() : Optional.empty(),
        RecipePropertySet.f_346277_,
        p_359833_ -> p_359833_ instanceof SmithingRecipe smithingrecipe ? smithingrecipe.m_353037_() : Optional.empty(),
        RecipePropertySet.f_348395_,
        m_357081_(RecipeType.f_44108_),
        RecipePropertySet.f_346264_,
        m_357081_(RecipeType.f_44109_),
        RecipePropertySet.f_346705_,
        m_357081_(RecipeType.f_44110_),
        RecipePropertySet.f_346730_,
        m_357081_(RecipeType.f_44111_)
    );
    private final HolderLookup.Provider f_314854_;
    private RecipeMap f_346395_ = RecipeMap.f_348327_;
    private Map<ResourceKey<RecipePropertySet>, RecipePropertySet> f_348877_ = Map.of();
    private SelectableRecipe.SingleInputSet<StonecutterRecipe> f_347679_ = SelectableRecipe.SingleInputSet.m_355921_();
    private List<RecipeManager.ServerDisplayInfo> f_346240_ = List.of();
    private Map<ResourceKey<Recipe<?>>, List<RecipeManager.ServerDisplayInfo>> f_346716_ = Map.of();

    public RecipeManager(HolderLookup.Provider p_330459_) {
        this.f_314854_ = p_330459_;
    }

    protected RecipeMap m_5944_(ResourceManager p_368640_, ProfilerFiller p_361102_) {
        SortedMap<ResourceLocation, Recipe<?>> sortedmap = new TreeMap<>();
        SimpleJsonResourceReloadListener.m_278771_(
            p_368640_, Registries.m_339951_(Registries.f_337225_), this.f_314854_.m_318927_(JsonOps.INSTANCE), Recipe.f_302387_, sortedmap
        );
        List<RecipeHolder<?>> list = new ArrayList<>(sortedmap.size());
        sortedmap.forEach((p_359835_, p_359836_) -> {
            ResourceKey<Recipe<?>> resourcekey = ResourceKey.m_135785_(Registries.f_337225_, p_359835_);
            RecipeHolder<?> recipeholder = new RecipeHolder<>(resourcekey, p_359836_);
            list.add(recipeholder);
        });
        return RecipeMap.m_354801_(list);
    }

    protected void m_5787_(RecipeMap p_369166_, ResourceManager p_44038_, ProfilerFiller p_44039_) {
        this.f_346395_ = p_369166_;
        f_44006_.info("Loaded {} recipes", p_369166_.m_352909_().size());
    }

    public void m_352914_(FeatureFlagSet p_360842_) {
        List<SelectableRecipe.SingleInputEntry<StonecutterRecipe>> list = new ArrayList<>();
        List<RecipeManager.IngredientCollector> list1 = f_347382_.entrySet()
            .stream()
            .map(p_359831_ -> new RecipeManager.IngredientCollector(p_359831_.getKey(), p_359831_.getValue()))
            .toList();
        this.f_346395_
            .m_352909_()
            .forEach(
                p_359840_ -> {
                    Recipe<?> recipe = p_359840_.f_291008_();
                    if (!recipe.m_5598_() && recipe.m_351808_().m_355310_()) {
                        f_44006_.warn("Recipe {} can't be placed due to empty ingredients and will be ignored", p_359840_.f_291676_().m_135782_());
                    } else {
                        list1.forEach(p_359842_ -> p_359842_.accept(recipe));
                        if (recipe instanceof StonecutterRecipe stonecutterrecipe
                            && m_353965_(p_360842_, stonecutterrecipe.m_351898_())
                            && stonecutterrecipe.m_353974_().m_354121_(p_360842_)) {
                            list.add(
                                new SelectableRecipe.SingleInputEntry<>(
                                    stonecutterrecipe.m_351898_(),
                                    new SelectableRecipe<>(stonecutterrecipe.m_353974_(), Optional.of((RecipeHolder<StonecutterRecipe>)p_359840_))
                                )
                            );
                        }
                    }
                }
            );
        this.f_348877_ = list1.stream().collect(Collectors.toUnmodifiableMap(p_359830_ -> p_359830_.f_348653_, p_359826_ -> p_359826_.m_352484_(p_360842_)));
        this.f_347679_ = new SelectableRecipe.SingleInputSet<>(list);
        this.f_346240_ = m_351620_(this.f_346395_.m_352909_(), p_360842_);
        this.f_346716_ = this.f_346240_
            .stream()
            .collect(Collectors.groupingBy(p_359820_ -> p_359820_.f_348416_.f_291676_(), IdentityHashMap::new, Collectors.toList()));
    }

    static List<Ingredient> m_354133_(FeatureFlagSet p_369580_, List<Ingredient> p_367920_) {
        p_367920_.removeIf(p_359829_ -> !m_353965_(p_369580_, p_359829_));
        return p_367920_;
    }

    private static boolean m_353965_(FeatureFlagSet p_361535_, Ingredient p_369900_) {
        return p_369900_.m_357234_().stream().allMatch(p_359822_ -> p_359822_.m_203334_().m_245993_(p_361535_));
    }

    public <I extends RecipeInput, T extends Recipe<I>> Optional<RecipeHolder<T>> m_220248_(
        RecipeType<T> p_220249_, I p_344518_, Level p_220251_, @Nullable ResourceKey<Recipe<?>> p_361142_
    ) {
        RecipeHolder<T> recipeholder = p_361142_ != null ? this.m_320711_(p_220249_, p_361142_) : null;
        return this.m_339836_(p_220249_, p_344518_, p_220251_, recipeholder);
    }

    public <I extends RecipeInput, T extends Recipe<I>> Optional<RecipeHolder<T>> m_339836_(
        RecipeType<T> p_343647_, I p_342793_, Level p_344483_, @Nullable RecipeHolder<T> p_345187_
    ) {
        return p_345187_ != null && p_345187_.f_291008_().m_5818_(p_342793_, p_344483_)
            ? Optional.of(p_345187_)
            : this.m_44015_(p_343647_, p_342793_, p_344483_);
    }

    public <I extends RecipeInput, T extends Recipe<I>> Optional<RecipeHolder<T>> m_44015_(RecipeType<T> p_44016_, I p_344358_, Level p_44018_) {
        return this.f_346395_.m_351836_(p_44016_, p_344358_, p_44018_).findFirst();
    }

    public Optional<RecipeHolder<?>> m_44043_(ResourceKey<Recipe<?>> p_364678_) {
        return Optional.ofNullable(this.f_346395_.m_353570_(p_364678_));
    }

    @Nullable
    private <T extends Recipe<?>> RecipeHolder<T> m_320711_(RecipeType<T> p_332930_, ResourceKey<Recipe<?>> p_367936_) {
        RecipeHolder<?> recipeholder = this.f_346395_.m_353570_(p_367936_);
        return (RecipeHolder<T>)(recipeholder != null && recipeholder.f_291008_().m_6671_().equals(p_332930_) ? recipeholder : null);
    }

    public Map<ResourceKey<RecipePropertySet>, RecipePropertySet> m_351610_() {
        return this.f_348877_;
    }

    public SelectableRecipe.SingleInputSet<StonecutterRecipe> m_355529_() {
        return this.f_347679_;
    }

    @Override
    public RecipePropertySet m_353891_(ResourceKey<RecipePropertySet> p_367484_) {
        return this.f_348877_.getOrDefault(p_367484_, RecipePropertySet.f_346317_);
    }

    @Override
    public SelectableRecipe.SingleInputSet<StonecutterRecipe> m_352810_() {
        return this.f_347679_;
    }

    public Collection<RecipeHolder<?>> m_44051_() {
        return this.f_346395_.m_352909_();
    }

    @Nullable
    public RecipeManager.ServerDisplayInfo m_354858_(RecipeDisplayId p_362633_) {
        return this.f_346240_.get(p_362633_.f_347292_());
    }

    public void m_357033_(ResourceKey<Recipe<?>> p_360782_, Consumer<RecipeDisplayEntry> p_368559_) {
        List<RecipeManager.ServerDisplayInfo> list = this.f_346716_.get(p_360782_);
        if (list != null) {
            list.forEach(p_359824_ -> p_368559_.accept(p_359824_.f_347719_));
        }
    }

    @VisibleForTesting
    protected static RecipeHolder<?> m_44045_(ResourceKey<Recipe<?>> p_366256_, JsonObject p_44047_, HolderLookup.Provider p_328308_) {
        Recipe<?> recipe = Recipe.f_302387_.parse(p_328308_.m_318927_(JsonOps.INSTANCE), p_44047_).getOrThrow(JsonParseException::new);
        return new RecipeHolder<>(p_366256_, recipe);
    }

    public static <I extends RecipeInput, T extends Recipe<I>> RecipeManager.CachedCheck<I, T> m_220267_(final RecipeType<T> p_220268_) {
        return new RecipeManager.CachedCheck<I, T>() {
            @Nullable
            private ResourceKey<Recipe<?>> f_220274_;

            @Override
            public Optional<RecipeHolder<T>> m_213657_(I p_343525_, ServerLevel p_364008_) {
                RecipeManager recipemanager = p_364008_.m_8879_();
                Optional<RecipeHolder<T>> optional = recipemanager.m_220248_(p_220268_, p_343525_, p_364008_, this.f_220274_);
                if (optional.isPresent()) {
                    RecipeHolder<T> recipeholder = optional.get();
                    this.f_220274_ = recipeholder.f_291676_();
                    return Optional.of(recipeholder);
                } else {
                    return Optional.empty();
                }
            }
        };
    }

    private static List<RecipeManager.ServerDisplayInfo> m_351620_(Iterable<RecipeHolder<?>> p_361848_, FeatureFlagSet p_362319_) {
        List<RecipeManager.ServerDisplayInfo> list = new ArrayList<>();
        Object2IntMap<String> object2intmap = new Object2IntOpenHashMap<>();

        for (RecipeHolder<?> recipeholder : p_361848_) {
            Recipe<?> recipe = recipeholder.f_291008_();
            OptionalInt optionalint;
            if (recipe.m_6076_().isEmpty()) {
                optionalint = OptionalInt.empty();
            } else {
                optionalint = OptionalInt.of(object2intmap.computeIfAbsent(recipe.m_6076_(), p_359844_ -> object2intmap.size()));
            }

            Optional<List<Ingredient>> optional;
            if (recipe.m_5598_()) {
                optional = Optional.empty();
            } else {
                optional = Optional.of(recipe.m_351808_().m_354762_());
            }

            for (RecipeDisplay recipedisplay : recipe.m_353294_()) {
                if (recipedisplay.m_354995_(p_362319_)) {
                    int i = list.size();
                    RecipeDisplayId recipedisplayid = new RecipeDisplayId(i);
                    RecipeDisplayEntry recipedisplayentry = new RecipeDisplayEntry(recipedisplayid, recipedisplay, optionalint, recipe.m_351608_(), optional);
                    list.add(new RecipeManager.ServerDisplayInfo(recipedisplayentry, recipeholder));
                }
            }
        }

        return list;
    }

    private static RecipeManager.IngredientExtractor m_357081_(RecipeType<? extends SingleItemRecipe> p_361054_) {
        return p_359846_ -> p_359846_.m_6671_() == p_361054_ && p_359846_ instanceof SingleItemRecipe singleitemrecipe
                ? Optional.of(singleitemrecipe.m_351898_())
                : Optional.empty();
    }

    public interface CachedCheck<I extends RecipeInput, T extends Recipe<I>> {
        Optional<RecipeHolder<T>> m_213657_(I p_343520_, ServerLevel p_367515_);
    }

    public static class IngredientCollector implements Consumer<Recipe<?>> {
        final ResourceKey<RecipePropertySet> f_348653_;
        private final RecipeManager.IngredientExtractor f_346361_;
        private final List<Ingredient> f_348035_ = new ArrayList<>();

        protected IngredientCollector(ResourceKey<RecipePropertySet> p_364661_, RecipeManager.IngredientExtractor p_368104_) {
            this.f_348653_ = p_364661_;
            this.f_346361_ = p_368104_;
        }

        public void accept(Recipe<?> p_361793_) {
            this.f_346361_.m_352812_(p_361793_).ifPresent(this.f_348035_::add);
        }

        public RecipePropertySet m_352484_(FeatureFlagSet p_363031_) {
            return RecipePropertySet.m_352979_(RecipeManager.m_354133_(p_363031_, this.f_348035_));
        }
    }

    @FunctionalInterface
    public interface IngredientExtractor {
        Optional<Ingredient> m_352812_(Recipe<?> p_363412_);
    }

    public static record ServerDisplayInfo(RecipeDisplayEntry f_347719_, RecipeHolder<?> f_348416_) {
    }
}