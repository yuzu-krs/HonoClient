package net.minecraft.world.item.crafting;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class RecipePropertySet {
    public static final ResourceKey<? extends Registry<RecipePropertySet>> f_348377_ = ResourceKey.m_135788_(ResourceLocation.m_340282_("recipe_property_set"));
    public static final ResourceKey<RecipePropertySet> f_346456_ = m_356910_("smithing_base");
    public static final ResourceKey<RecipePropertySet> f_346277_ = m_356910_("smithing_template");
    public static final ResourceKey<RecipePropertySet> f_348593_ = m_356910_("smithing_addition");
    public static final ResourceKey<RecipePropertySet> f_348395_ = m_356910_("furnace_input");
    public static final ResourceKey<RecipePropertySet> f_346264_ = m_356910_("blast_furnace_input");
    public static final ResourceKey<RecipePropertySet> f_346705_ = m_356910_("smoker_input");
    public static final ResourceKey<RecipePropertySet> f_346730_ = m_356910_("campfire_input");
    public static final StreamCodec<RegistryFriendlyByteBuf, RecipePropertySet> f_349433_ = ByteBufCodecs.m_322636_(Registries.f_256913_)
        .m_321801_(ByteBufCodecs.m_324765_())
        .m_323038_(p_365348_ -> new RecipePropertySet(Set.copyOf(p_365348_)), p_363184_ -> List.copyOf(p_363184_.f_348183_));
    public static final RecipePropertySet f_346317_ = new RecipePropertySet(Set.of());
    private final Set<Holder<Item>> f_348183_;

    private RecipePropertySet(Set<Holder<Item>> p_369942_) {
        this.f_348183_ = p_369942_;
    }

    private static ResourceKey<RecipePropertySet> m_356910_(String p_366068_) {
        return ResourceKey.m_135785_(f_348377_, ResourceLocation.m_340282_(p_366068_));
    }

    public boolean m_357406_(ItemStack p_363498_) {
        return this.f_348183_.contains(p_363498_.m_220173_());
    }

    static RecipePropertySet m_352979_(Collection<Ingredient> p_366318_) {
        Set<Holder<Item>> set = p_366318_.stream().flatMap(p_368276_ -> p_368276_.m_357234_().stream()).collect(Collectors.toUnmodifiableSet());
        return new RecipePropertySet(set);
    }
}