package net.minecraft.world.item.crafting;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.display.FurnaceRecipeDisplay;
import net.minecraft.world.item.crafting.display.RecipeDisplay;
import net.minecraft.world.item.crafting.display.SlotDisplay;

public abstract class AbstractCookingRecipe extends SingleItemRecipe {
    private final CookingBookCategory f_243702_;
    private final float f_43731_;
    private final int f_43732_;

    public AbstractCookingRecipe(String p_249518_, CookingBookCategory p_250891_, Ingredient p_251354_, ItemStack p_252185_, float p_252165_, int p_250256_) {
        super(p_249518_, p_251354_, p_252185_);
        this.f_243702_ = p_250891_;
        this.f_43731_ = p_252165_;
        this.f_43732_ = p_250256_;
    }

    @Override
    public abstract RecipeSerializer<? extends AbstractCookingRecipe> m_7707_();

    @Override
    public abstract RecipeType<? extends AbstractCookingRecipe> m_6671_();

    public float m_43750_() {
        return this.f_43731_;
    }

    public int m_43753_() {
        return this.f_43732_;
    }

    public CookingBookCategory m_245534_() {
        return this.f_243702_;
    }

    protected abstract Item m_352464_();

    @Override
    public List<RecipeDisplay> m_353294_() {
        return List.of(
            new FurnaceRecipeDisplay(
                this.m_351898_().m_356927_(),
                SlotDisplay.AnyFuel.f_349529_,
                new SlotDisplay.ItemStackSlotDisplay(this.m_44429_()),
                new SlotDisplay.ItemSlotDisplay(this.m_352464_()),
                this.f_43732_,
                this.f_43731_
            )
        );
    }

    @FunctionalInterface
    public interface Factory<T extends AbstractCookingRecipe> {
        T m_306886_(String p_310191_, CookingBookCategory p_311031_, Ingredient p_313122_, ItemStack p_312156_, float p_312177_, int p_311374_);
    }

    public static class Serializer<T extends AbstractCookingRecipe> implements RecipeSerializer<T> {
        private final MapCodec<T> f_346718_;
        private final StreamCodec<RegistryFriendlyByteBuf, T> f_346820_;

        public Serializer(AbstractCookingRecipe.Factory<T> p_368971_, int p_370210_) {
            this.f_346718_ = RecordCodecBuilder.mapCodec(
                p_361399_ -> p_361399_.group(
                            Codec.STRING.optionalFieldOf("group", "").forGetter(SingleItemRecipe::m_6076_),
                            CookingBookCategory.f_244271_.fieldOf("category").orElse(CookingBookCategory.MISC).forGetter(AbstractCookingRecipe::m_245534_),
                            Ingredient.f_291570_.fieldOf("ingredient").forGetter(SingleItemRecipe::m_351898_),
                            ItemStack.f_316270_.fieldOf("result").forGetter(SingleItemRecipe::m_44429_),
                            Codec.FLOAT.fieldOf("experience").orElse(0.0F).forGetter(AbstractCookingRecipe::m_43750_),
                            Codec.INT.fieldOf("cookingtime").orElse(p_370210_).forGetter(AbstractCookingRecipe::m_43753_)
                        )
                        .apply(p_361399_, p_368971_::m_306886_)
            );
            this.f_346820_ = StreamCodec.m_322230_(
                ByteBufCodecs.f_315450_,
                SingleItemRecipe::m_6076_,
                CookingBookCategory.f_346744_,
                AbstractCookingRecipe::m_245534_,
                Ingredient.f_317040_,
                SingleItemRecipe::m_351898_,
                ItemStack.f_315801_,
                SingleItemRecipe::m_44429_,
                ByteBufCodecs.f_314734_,
                AbstractCookingRecipe::m_43750_,
                ByteBufCodecs.f_316612_,
                AbstractCookingRecipe::m_43753_,
                p_368971_::m_306886_
            );
        }

        @Override
        public MapCodec<T> m_292673_() {
            return this.f_346718_;
        }

        @Override
        public StreamCodec<RegistryFriendlyByteBuf, T> m_318841_() {
            return this.f_346820_;
        }
    }
}