package net.minecraft.world.item;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentUtils;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.component.TooltipProvider;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.JukeboxBlock;
import net.minecraft.world.level.block.entity.JukeboxBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;

public record JukeboxPlayable(EitherHolder<JukeboxSong> f_337112_, boolean f_336721_) implements TooltipProvider {
    public static final Codec<JukeboxPlayable> f_337315_ = RecordCodecBuilder.create(
        p_342357_ -> p_342357_.group(
                    EitherHolder.m_340220_(Registries.f_337466_, JukeboxSong.f_337351_).fieldOf("song").forGetter(JukeboxPlayable::f_337112_),
                    Codec.BOOL.optionalFieldOf("show_in_tooltip", Boolean.valueOf(true)).forGetter(JukeboxPlayable::f_336721_)
                )
                .apply(p_342357_, JukeboxPlayable::new)
    );
    public static final StreamCodec<RegistryFriendlyByteBuf, JukeboxPlayable> f_337415_ = StreamCodec.m_320349_(
        EitherHolder.m_338499_(Registries.f_337466_, JukeboxSong.f_337152_),
        JukeboxPlayable::f_337112_,
        ByteBufCodecs.f_315514_,
        JukeboxPlayable::f_336721_,
        JukeboxPlayable::new
    );

    @Override
    public void m_319025_(Item.TooltipContext p_343529_, Consumer<Component> p_344027_, TooltipFlag p_344530_) {
        HolderLookup.Provider holderlookup$provider = p_343529_.m_320287_();
        if (this.f_336721_ && holderlookup$provider != null) {
            this.f_337112_.m_340095_(holderlookup$provider).ifPresent(p_343443_ -> {
                MutableComponent mutablecomponent = p_343443_.m_203334_().f_337519_().m_6881_();
                ComponentUtils.m_130750_(mutablecomponent, Style.f_131099_.m_131140_(ChatFormatting.GRAY));
                p_344027_.accept(mutablecomponent);
            });
        }
    }

    public JukeboxPlayable m_340314_(boolean p_343241_) {
        return new JukeboxPlayable(this.f_337112_, p_343241_);
    }

    public static InteractionResult m_339307_(Level p_342790_, BlockPos p_344904_, ItemStack p_345065_, Player p_342036_) {
        JukeboxPlayable jukeboxplayable = p_345065_.m_323252_(DataComponents.f_336668_);
        if (jukeboxplayable == null) {
            return InteractionResult.f_348895_;
        } else {
            BlockState blockstate = p_342790_.m_8055_(p_344904_);
            if (blockstate.m_60713_(Blocks.f_50131_) && !blockstate.m_61143_(JukeboxBlock.f_54254_)) {
                if (!p_342790_.f_46443_) {
                    ItemStack itemstack = p_345065_.m_338460_(1, p_342036_);
                    if (p_342790_.m_7702_(p_344904_) instanceof JukeboxBlockEntity jukeboxblockentity) {
                        jukeboxblockentity.m_305072_(itemstack);
                        p_342790_.m_322719_(GameEvent.f_157792_, p_344904_, GameEvent.Context.m_223719_(p_342036_, blockstate));
                    }

                    p_342036_.m_36220_(Stats.f_12965_);
                }

                return InteractionResult.f_19068_;
            } else {
                return InteractionResult.f_348895_;
            }
        }
    }
}