package net.minecraft.world.item.enchantment;

import com.mojang.serialization.Codec;
import java.util.List;
import java.util.function.UnaryOperator;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Unit;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.enchantment.effects.DamageImmunity;
import net.minecraft.world.item.enchantment.effects.EnchantmentAttributeEffect;
import net.minecraft.world.item.enchantment.effects.EnchantmentEntityEffect;
import net.minecraft.world.item.enchantment.effects.EnchantmentLocationBasedEffect;
import net.minecraft.world.item.enchantment.effects.EnchantmentValueEffect;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;

public interface EnchantmentEffectComponents {
    Codec<DataComponentType<?>> f_337677_ = Codec.lazyInitialized(() -> BuiltInRegistries.f_337117_.m_194605_());
    Codec<DataComponentMap> f_337588_ = DataComponentMap.m_338433_(f_337677_);
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_337120_ = m_338438_(
        "damage_protection",
        p_343083_ -> p_343083_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_336863_).listOf())
    );
    DataComponentType<List<ConditionalEffect<DamageImmunity>>> f_337071_ = m_338438_(
        "damage_immunity", p_342369_ -> p_342369_.m_319357_(ConditionalEffect.m_340218_(DamageImmunity.f_337694_, LootContextParamSets.f_336863_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_336808_ = m_338438_(
        "damage", p_343665_ -> p_343665_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_336863_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_336648_ = m_338438_(
        "smash_damage_per_fallen_block",
        p_342204_ -> p_342204_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_336863_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_336652_ = m_338438_(
        "knockback", p_342778_ -> p_342778_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_336863_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_337003_ = m_338438_(
        "armor_effectiveness",
        p_342687_ -> p_342687_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_336863_).listOf())
    );
    DataComponentType<List<TargetedConditionalEffect<EnchantmentEntityEffect>>> f_337512_ = m_338438_(
        "post_attack",
        p_344691_ -> p_344691_.m_319357_(TargetedConditionalEffect.m_339236_(EnchantmentEntityEffect.f_337325_, LootContextParamSets.f_336863_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentEntityEffect>>> f_337526_ = m_338438_(
        "hit_block", p_343726_ -> p_343726_.m_319357_(ConditionalEffect.m_340218_(EnchantmentEntityEffect.f_337325_, LootContextParamSets.f_337548_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_336904_ = m_338438_(
        "item_damage", p_344724_ -> p_344724_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_337455_).listOf())
    );
    DataComponentType<List<EnchantmentAttributeEffect>> f_337300_ = m_338438_(
        "attributes", p_342151_ -> p_342151_.m_319357_(EnchantmentAttributeEffect.f_336678_.codec().listOf())
    );
    DataComponentType<List<TargetedConditionalEffect<EnchantmentValueEffect>>> f_336866_ = m_338438_(
        "equipment_drops",
        p_342441_ -> p_342441_.m_319357_(TargetedConditionalEffect.m_339725_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_336863_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentLocationBasedEffect>>> f_337527_ = m_338438_(
        "location_changed",
        p_344782_ -> p_344782_.m_319357_(ConditionalEffect.m_340218_(EnchantmentLocationBasedEffect.f_336895_, LootContextParamSets.f_337139_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentEntityEffect>>> f_336723_ = m_338438_(
        "tick", p_345201_ -> p_345201_.m_319357_(ConditionalEffect.m_340218_(EnchantmentEntityEffect.f_337325_, LootContextParamSets.f_337285_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_337385_ = m_338438_(
        "ammo_use", p_343745_ -> p_343745_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_337455_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_337536_ = m_338438_(
        "projectile_piercing",
        p_344537_ -> p_344537_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_337455_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentEntityEffect>>> f_336685_ = m_338438_(
        "projectile_spawned",
        p_345464_ -> p_345464_.m_319357_(ConditionalEffect.m_340218_(EnchantmentEntityEffect.f_337325_, LootContextParamSets.f_337285_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_336697_ = m_338438_(
        "projectile_spread",
        p_342569_ -> p_342569_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_337285_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_336729_ = m_338438_(
        "projectile_count",
        p_344670_ -> p_344670_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_337285_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_336727_ = m_338438_(
        "trident_return_acceleration",
        p_342620_ -> p_342620_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_337285_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_337049_ = m_338438_(
        "fishing_time_reduction",
        p_342994_ -> p_342994_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_337285_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_336735_ = m_338438_(
        "fishing_luck_bonus",
        p_345348_ -> p_345348_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_337285_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_336894_ = m_338438_(
        "block_experience",
        p_344214_ -> p_344214_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_337455_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_337738_ = m_338438_(
        "mob_experience",
        p_344594_ -> p_344594_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_337285_).listOf())
    );
    DataComponentType<List<ConditionalEffect<EnchantmentValueEffect>>> f_337452_ = m_338438_(
        "repair_with_xp",
        p_344261_ -> p_344261_.m_319357_(ConditionalEffect.m_340218_(EnchantmentValueEffect.f_337575_, LootContextParamSets.f_337455_).listOf())
    );
    DataComponentType<EnchantmentValueEffect> f_336604_ = m_338438_("crossbow_charge_time", p_344938_ -> p_344938_.m_319357_(EnchantmentValueEffect.f_337575_));
    DataComponentType<List<CrossbowItem.ChargingSounds>> f_337250_ = m_338438_(
        "crossbow_charging_sounds", p_344355_ -> p_344355_.m_319357_(CrossbowItem.ChargingSounds.f_336988_.listOf())
    );
    DataComponentType<List<Holder<SoundEvent>>> f_336670_ = m_338438_("trident_sound", p_345273_ -> p_345273_.m_319357_(SoundEvent.f_263130_.listOf()));
    DataComponentType<Unit> f_337159_ = m_338438_("prevent_equipment_drop", p_345068_ -> p_345068_.m_319357_(Unit.f_336987_));
    DataComponentType<Unit> f_337286_ = m_338438_("prevent_armor_change", p_344955_ -> p_344955_.m_319357_(Unit.f_336987_));
    DataComponentType<EnchantmentValueEffect> f_337143_ = m_338438_(
        "trident_spin_attack_strength", p_343362_ -> p_343362_.m_319357_(EnchantmentValueEffect.f_337575_)
    );

    static DataComponentType<?> m_340296_(Registry<DataComponentType<?>> p_342462_) {
        return f_337120_;
    }

    private static <T> DataComponentType<T> m_338438_(String p_342959_, UnaryOperator<DataComponentType.Builder<T>> p_345175_) {
        return Registry.m_122961_(BuiltInRegistries.f_337117_, p_342959_, p_345175_.apply(DataComponentType.m_320209_()).m_318929_());
    }
}