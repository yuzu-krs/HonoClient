package net.minecraft.world.item.enchantment.effects;

import com.google.common.collect.HashMultimap;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.item.enchantment.EnchantedItemInUse;
import net.minecraft.world.item.enchantment.LevelBasedValue;
import net.minecraft.world.phys.Vec3;

public record EnchantmentAttributeEffect(
    ResourceLocation f_337022_, Holder<Attribute> f_337199_, LevelBasedValue f_336750_, AttributeModifier.Operation f_336935_
) implements EnchantmentLocationBasedEffect {
    public static final MapCodec<EnchantmentAttributeEffect> f_336678_ = RecordCodecBuilder.mapCodec(
        p_344407_ -> p_344407_.group(
                    ResourceLocation.f_135803_.fieldOf("id").forGetter(EnchantmentAttributeEffect::f_337022_),
                    Attribute.f_337502_.fieldOf("attribute").forGetter(EnchantmentAttributeEffect::f_337199_),
                    LevelBasedValue.f_337468_.fieldOf("amount").forGetter(EnchantmentAttributeEffect::f_336750_),
                    AttributeModifier.Operation.f_290595_.fieldOf("operation").forGetter(EnchantmentAttributeEffect::f_336935_)
                )
                .apply(p_344407_, EnchantmentAttributeEffect::new)
    );

    private ResourceLocation m_339896_(StringRepresentable p_345417_) {
        return this.f_337022_.m_266382_("/" + p_345417_.m_7912_());
    }

    public AttributeModifier m_338573_(int p_342709_, StringRepresentable p_342150_) {
        return new AttributeModifier(this.m_339896_(p_342150_), (double)this.f_336750_().m_338646_(p_342709_), this.f_336935_());
    }

    @Override
    public void m_339697_(ServerLevel p_342233_, int p_343426_, EnchantedItemInUse p_344251_, Entity p_342367_, Vec3 p_343372_, boolean p_342530_) {
        if (p_342530_ && p_342367_ instanceof LivingEntity livingentity) {
            livingentity.m_21204_().m_338988_(this.m_339104_(p_343426_, p_344251_.f_337013_()));
        }
    }

    @Override
    public void m_338378_(EnchantedItemInUse p_343672_, Entity p_343519_, Vec3 p_342547_, int p_343187_) {
        if (p_343519_ instanceof LivingEntity livingentity) {
            livingentity.m_21204_().m_338497_(this.m_339104_(p_343187_, p_343672_.f_337013_()));
        }
    }

    private HashMultimap<Holder<Attribute>, AttributeModifier> m_339104_(int p_342373_, EquipmentSlot p_343561_) {
        HashMultimap<Holder<Attribute>, AttributeModifier> hashmultimap = HashMultimap.create();
        hashmultimap.put(this.f_337199_, this.m_338573_(p_342373_, p_343561_));
        return hashmultimap;
    }

    @Override
    public MapCodec<EnchantmentAttributeEffect> m_338403_() {
        return f_336678_;
    }
}