package net.minecraft.world.item.enchantment.effects;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.enchantment.EnchantedItemInUse;
import net.minecraft.world.item.enchantment.LevelBasedValue;
import net.minecraft.world.phys.Vec3;

public record DamageEntity(LevelBasedValue f_336763_, LevelBasedValue f_336715_, Holder<DamageType> f_336703_) implements EnchantmentEntityEffect {
    public static final MapCodec<DamageEntity> f_336657_ = RecordCodecBuilder.mapCodec(
        p_342476_ -> p_342476_.group(
                    LevelBasedValue.f_337468_.fieldOf("min_damage").forGetter(DamageEntity::f_336763_),
                    LevelBasedValue.f_337468_.fieldOf("max_damage").forGetter(DamageEntity::f_336715_),
                    DamageType.f_336772_.fieldOf("damage_type").forGetter(DamageEntity::f_336703_)
                )
                .apply(p_342476_, DamageEntity::new)
    );

    @Override
    public void m_338607_(ServerLevel p_344348_, int p_344737_, EnchantedItemInUse p_343017_, Entity p_343629_, Vec3 p_342181_) {
        float f = Mth.m_216283_(p_343629_.m_339477_(), this.f_336763_.m_338646_(p_344737_), this.f_336715_.m_338646_(p_344737_));
        p_343629_.m_351622_(p_344348_, new DamageSource(this.f_336703_, p_343017_.f_337580_()), f);
    }

    @Override
    public MapCodec<DamageEntity> m_338403_() {
        return f_336657_;
    }
}