package net.minecraft.world.item.alchemy;

import com.mojang.serialization.Codec;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.flag.FeatureElement;
import net.minecraft.world.flag.FeatureFlag;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.flag.FeatureFlags;

public class Potion implements FeatureElement {
    public static final Codec<Holder<Potion>> f_337035_ = BuiltInRegistries.f_256980_.m_206110_();
    public static final StreamCodec<RegistryFriendlyByteBuf, Holder<Potion>> f_337510_ = ByteBufCodecs.m_322636_(Registries.f_256973_);
    private final String f_43481_;
    private final List<MobEffectInstance> f_43482_;
    private FeatureFlagSet f_315259_ = FeatureFlags.f_244377_;

    public Potion(String p_43484_, MobEffectInstance... p_43485_) {
        this.f_43481_ = p_43484_;
        this.f_43482_ = List.of(p_43485_);
    }

    public Potion m_319158_(FeatureFlag... p_331264_) {
        this.f_315259_ = FeatureFlags.f_244280_.m_245769_(p_331264_);
        return this;
    }

    @Override
    public FeatureFlagSet m_245183_() {
        return this.f_315259_;
    }

    public List<MobEffectInstance> m_43488_() {
        return this.f_43482_;
    }

    public String m_355490_() {
        return this.f_43481_;
    }

    public boolean m_43491_() {
        for (MobEffectInstance mobeffectinstance : this.f_43482_) {
            if (mobeffectinstance.m_19544_().m_203334_().m_8093_()) {
                return true;
            }
        }

        return false;
    }
}