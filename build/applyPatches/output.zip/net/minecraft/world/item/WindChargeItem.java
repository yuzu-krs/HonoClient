package net.minecraft.world.item;

import net.minecraft.core.Direction;
import net.minecraft.core.Position;
import net.minecraft.core.dispenser.BlockSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.windcharge.WindCharge;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.phys.Vec3;

public class WindChargeItem extends Item implements ProjectileItem {
    public WindChargeItem(Item.Properties p_333764_) {
        super(p_333764_);
    }

    @Override
    public InteractionResult m_7203_(Level p_333953_, Player p_328676_, InteractionHand p_332155_) {
        ItemStack itemstack = p_328676_.m_21120_(p_332155_);
        if (p_333953_ instanceof ServerLevel serverlevel) {
            Projectile.m_355573_(
                (p_359797_, p_359798_, p_359799_) -> new WindCharge(
                        p_328676_, p_333953_, p_328676_.m_20182_().m_7096_(), p_328676_.m_146892_().m_7098_(), p_328676_.m_20182_().m_7094_()
                    ),
                serverlevel,
                itemstack,
                p_328676_,
                0.0F,
                1.5F,
                1.0F
            );
        }

        p_333953_.m_6263_(
            null,
            p_328676_.m_20185_(),
            p_328676_.m_20186_(),
            p_328676_.m_20189_(),
            SoundEvents.f_316553_,
            SoundSource.NEUTRAL,
            0.5F,
            0.4F / (p_333953_.m_213780_().m_188501_() * 0.4F + 0.8F)
        );
        p_328676_.m_36246_(Stats.f_12982_.m_12902_(this));
        itemstack.m_321439_(1, p_328676_);
        return InteractionResult.f_19068_;
    }

    @Override
    public Projectile m_319847_(Level p_335187_, Position p_334268_, ItemStack p_330980_, Direction p_331337_) {
        RandomSource randomsource = p_335187_.m_213780_();
        double d0 = randomsource.m_216328_((double)p_331337_.m_122429_(), 0.11485000000000001);
        double d1 = randomsource.m_216328_((double)p_331337_.m_122430_(), 0.11485000000000001);
        double d2 = randomsource.m_216328_((double)p_331337_.m_122431_(), 0.11485000000000001);
        Vec3 vec3 = new Vec3(d0, d1, d2);
        WindCharge windcharge = new WindCharge(p_335187_, p_334268_.m_7096_(), p_334268_.m_7098_(), p_334268_.m_7094_(), vec3);
        windcharge.m_20256_(vec3);
        return windcharge;
    }

    @Override
    public void m_319015_(Projectile p_331638_, double p_331384_, double p_329200_, double p_331035_, float p_335278_, float p_332729_) {
    }

    @Override
    public ProjectileItem.DispenseConfig m_320420_() {
        return ProjectileItem.DispenseConfig.m_321505_()
            .m_321513_((p_335953_, p_334773_) -> DispenserBlock.m_321992_(p_335953_, 1.0, Vec3.f_82478_))
            .m_324742_(6.6666665F)
            .m_318910_(1.0F)
            .m_323513_(1051)
            .m_321407_();
    }
}