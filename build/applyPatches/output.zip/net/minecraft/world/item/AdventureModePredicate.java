package net.minecraft.world.item;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.critereon.BlockPredicate;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.level.block.state.pattern.BlockInWorld;

public class AdventureModePredicate {
    private static final Codec<AdventureModePredicate> f_316464_ = BlockPredicate.f_291811_
        .flatComapMap(p_334782_ -> new AdventureModePredicate(List.of(p_334782_), true), p_329449_ -> DataResult.error(() -> "Cannot encode"));
    private static final Codec<AdventureModePredicate> f_316127_ = RecordCodecBuilder.create(
        p_329746_ -> p_329746_.group(
                    ExtraCodecs.m_144637_(BlockPredicate.f_291811_.listOf()).fieldOf("predicates").forGetter(p_329117_ -> p_329117_.f_316891_),
                    Codec.BOOL.optionalFieldOf("show_in_tooltip", Boolean.valueOf(true)).forGetter(AdventureModePredicate::m_324667_)
                )
                .apply(p_329746_, AdventureModePredicate::new)
    );
    public static final Codec<AdventureModePredicate> f_314196_ = Codec.withAlternative(f_316127_, f_316464_);
    public static final StreamCodec<RegistryFriendlyByteBuf, AdventureModePredicate> f_315519_ = StreamCodec.m_320349_(
        BlockPredicate.f_315415_.m_321801_(ByteBufCodecs.m_324765_()),
        p_333442_ -> p_333442_.f_316891_,
        ByteBufCodecs.f_315514_,
        AdventureModePredicate::m_324667_,
        AdventureModePredicate::new
    );
    public static final Component f_315565_ = Component.m_237115_("item.canBreak").m_130940_(ChatFormatting.GRAY);
    public static final Component f_314797_ = Component.m_237115_("item.canPlace").m_130940_(ChatFormatting.GRAY);
    private static final Component f_314193_ = Component.m_237115_("item.canUse.unknown").m_130940_(ChatFormatting.GRAY);
    private final List<BlockPredicate> f_316891_;
    private final boolean f_316745_;
    @Nullable
    private List<Component> f_346417_;
    @Nullable
    private BlockInWorld f_314808_;
    private boolean f_316657_;
    private boolean f_314757_;

    public AdventureModePredicate(List<BlockPredicate> p_336068_, boolean p_330877_) {
        this.f_316891_ = p_336068_;
        this.f_316745_ = p_330877_;
    }

    private static boolean m_323601_(BlockInWorld p_330769_, @Nullable BlockInWorld p_330025_, boolean p_331117_) {
        if (p_330025_ == null || p_330769_.m_61168_() != p_330025_.m_61168_()) {
            return false;
        } else if (!p_331117_) {
            return true;
        } else if (p_330769_.m_61174_() == null && p_330025_.m_61174_() == null) {
            return true;
        } else if (p_330769_.m_61174_() != null && p_330025_.m_61174_() != null) {
            RegistryAccess registryaccess = p_330769_.m_61175_().m_9598_();
            return Objects.equals(p_330769_.m_61174_().m_187481_(registryaccess), p_330025_.m_61174_().m_187481_(registryaccess));
        } else {
            return false;
        }
    }

    public boolean m_322201_(BlockInWorld p_333716_) {
        if (m_323601_(p_333716_, this.f_314808_, this.f_314757_)) {
            return this.f_316657_;
        } else {
            this.f_314808_ = p_333716_;
            this.f_314757_ = false;

            for (BlockPredicate blockpredicate : this.f_316891_) {
                if (blockpredicate.m_321461_(p_333716_)) {
                    this.f_314757_ = this.f_314757_ | blockpredicate.m_324452_();
                    this.f_316657_ = true;
                    return true;
                }
            }

            this.f_316657_ = false;
            return false;
        }
    }

    private List<Component> m_352465_() {
        if (this.f_346417_ == null) {
            this.f_346417_ = m_322824_(this.f_316891_);
        }

        return this.f_346417_;
    }

    public void m_318685_(Consumer<Component> p_334654_) {
        this.m_352465_().forEach(p_334654_);
    }

    public AdventureModePredicate m_322095_(boolean p_335029_) {
        return new AdventureModePredicate(this.f_316891_, p_335029_);
    }

    private static List<Component> m_322824_(List<BlockPredicate> p_328947_) {
        for (BlockPredicate blockpredicate : p_328947_) {
            if (blockpredicate.f_146710_().isEmpty()) {
                return List.of(f_314193_);
            }
        }

        return p_328947_.stream()
            .flatMap(p_333785_ -> p_333785_.f_146710_().orElseThrow().m_203614_())
            .distinct()
            .map(p_335858_ -> (Component)p_335858_.m_203334_().m_49954_().m_130940_(ChatFormatting.DARK_GRAY))
            .toList();
    }

    public boolean m_324667_() {
        return this.f_316745_;
    }

    @Override
    public boolean equals(Object p_331232_) {
        if (this == p_331232_) {
            return true;
        } else {
            return !(p_331232_ instanceof AdventureModePredicate adventuremodepredicate)
                ? false
                : this.f_316891_.equals(adventuremodepredicate.f_316891_) && this.f_316745_ == adventuremodepredicate.f_316745_;
        }
    }

    @Override
    public int hashCode() {
        return this.f_316891_.hashCode() * 31 + (this.f_316745_ ? 1 : 0);
    }

    @Override
    public String toString() {
        return "AdventureModePredicate{predicates=" + this.f_316891_ + ", showInTooltip=" + this.f_316745_ + "}";
    }
}
