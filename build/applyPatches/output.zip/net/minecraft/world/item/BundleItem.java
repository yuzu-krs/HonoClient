package net.minecraft.world.item;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickAction;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.tooltip.BundleTooltip;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.component.BundleContents;
import net.minecraft.world.level.Level;
import org.apache.commons.lang3.math.Fraction;

public class BundleItem extends Item {
    public static final int f_347396_ = 4;
    public static final int f_347910_ = 3;
    public static final int f_348585_ = 12;
    public static final int f_346939_ = 11;
    private static final int f_347287_ = ARGB.m_353391_(1.0F, 1.0F, 0.33F, 0.33F);
    private static final int f_150723_ = ARGB.m_353391_(1.0F, 0.44F, 0.53F, 1.0F);
    private static final int f_346530_ = 10;
    private static final int f_347711_ = 2;
    private static final int f_347495_ = 200;
    private final ResourceLocation f_346346_;
    private final ResourceLocation f_349012_;

    public BundleItem(ResourceLocation p_365260_, ResourceLocation p_369763_, Item.Properties p_150726_) {
        super(p_150726_);
        this.f_346346_ = p_365260_;
        this.f_349012_ = p_369763_;
    }

    public static float m_150766_(ItemStack p_150767_) {
        BundleContents bundlecontents = p_150767_.m_322304_(DataComponents.f_315394_, BundleContents.f_316266_);
        return bundlecontents.m_320631_().floatValue();
    }

    public ResourceLocation m_357172_() {
        return this.f_346346_;
    }

    public ResourceLocation m_352137_() {
        return this.f_349012_;
    }

    @Override
    public boolean m_142207_(ItemStack p_150733_, Slot p_150734_, ClickAction p_150735_, Player p_150736_) {
        BundleContents bundlecontents = p_150733_.m_323252_(DataComponents.f_315394_);
        if (bundlecontents == null) {
            return false;
        } else {
            ItemStack itemstack = p_150734_.m_7993_();
            BundleContents.Mutable bundlecontents$mutable = new BundleContents.Mutable(bundlecontents);
            if (p_150735_ == ClickAction.PRIMARY && !itemstack.m_41619_()) {
                if (bundlecontents$mutable.m_325088_(p_150734_, p_150736_) > 0) {
                    m_186351_(p_150736_);
                } else {
                    m_357198_(p_150736_);
                }

                p_150733_.m_322496_(DataComponents.f_315394_, bundlecontents$mutable.m_322369_());
                this.m_352999_(p_150736_);
                return true;
            } else if (p_150735_ == ClickAction.SECONDARY && itemstack.m_41619_()) {
                ItemStack itemstack1 = bundlecontents$mutable.m_324664_();
                if (itemstack1 != null) {
                    ItemStack itemstack2 = p_150734_.m_150659_(itemstack1);
                    if (itemstack2.m_41613_() > 0) {
                        bundlecontents$mutable.m_319811_(itemstack2);
                    } else {
                        m_186342_(p_150736_);
                    }
                }

                p_150733_.m_322496_(DataComponents.f_315394_, bundlecontents$mutable.m_322369_());
                this.m_352999_(p_150736_);
                return true;
            } else {
                return false;
            }
        }
    }

    @Override
    public boolean m_142305_(ItemStack p_150742_, ItemStack p_150743_, Slot p_150744_, ClickAction p_150745_, Player p_150746_, SlotAccess p_150747_) {
        if (p_150745_ == ClickAction.PRIMARY && p_150743_.m_41619_()) {
            m_355417_(p_150742_, -1);
            return false;
        } else {
            BundleContents bundlecontents = p_150742_.m_323252_(DataComponents.f_315394_);
            if (bundlecontents == null) {
                return false;
            } else {
                BundleContents.Mutable bundlecontents$mutable = new BundleContents.Mutable(bundlecontents);
                if (p_150745_ == ClickAction.PRIMARY && !p_150743_.m_41619_()) {
                    if (p_150744_.m_150651_(p_150746_) && bundlecontents$mutable.m_319811_(p_150743_) > 0) {
                        m_186351_(p_150746_);
                    } else {
                        m_357198_(p_150746_);
                    }

                    p_150742_.m_322496_(DataComponents.f_315394_, bundlecontents$mutable.m_322369_());
                    this.m_352999_(p_150746_);
                    return true;
                } else if (p_150745_ == ClickAction.SECONDARY && p_150743_.m_41619_()) {
                    if (p_150744_.m_150651_(p_150746_)) {
                        ItemStack itemstack = bundlecontents$mutable.m_324664_();
                        if (itemstack != null) {
                            m_186342_(p_150746_);
                            p_150747_.m_142104_(itemstack);
                        }
                    }

                    p_150742_.m_322496_(DataComponents.f_315394_, bundlecontents$mutable.m_322369_());
                    this.m_352999_(p_150746_);
                    return true;
                } else {
                    m_355417_(p_150742_, -1);
                    return false;
                }
            }
        }
    }

    @Override
    public InteractionResult m_7203_(Level p_150760_, Player p_150761_, InteractionHand p_150762_) {
        if (p_150760_.f_46443_) {
            return InteractionResult.f_19069_;
        } else {
            p_150761_.m_6672_(p_150762_);
            return InteractionResult.f_349050_;
        }
    }

    private void m_357259_(Level p_369525_, Player p_369321_, ItemStack p_365964_) {
        if (this.m_356605_(p_365964_, p_369321_)) {
            m_186353_(p_369525_, p_369321_);
            p_369321_.m_36246_(Stats.f_12982_.m_12902_(this));
        }
    }

    @Override
    public boolean m_142522_(ItemStack p_150769_) {
        BundleContents bundlecontents = p_150769_.m_322304_(DataComponents.f_315394_, BundleContents.f_316266_);
        return bundlecontents.m_320631_().compareTo(Fraction.ZERO) > 0;
    }

    @Override
    public int m_142158_(ItemStack p_150771_) {
        BundleContents bundlecontents = p_150771_.m_322304_(DataComponents.f_315394_, BundleContents.f_316266_);
        return Math.min(1 + Mth.m_320106_(bundlecontents.m_320631_(), 12), 13);
    }

    @Override
    public int m_142159_(ItemStack p_150773_) {
        BundleContents bundlecontents = p_150773_.m_322304_(DataComponents.f_315394_, BundleContents.f_316266_);
        return bundlecontents.m_320631_().compareTo(Fraction.ONE) >= 0 ? f_347287_ : f_150723_;
    }

    public static void m_355417_(ItemStack p_369957_, int p_362067_) {
        BundleContents bundlecontents = p_369957_.m_323252_(DataComponents.f_315394_);
        if (bundlecontents != null) {
            BundleContents.Mutable bundlecontents$mutable = new BundleContents.Mutable(bundlecontents);
            bundlecontents$mutable.m_353030_(p_362067_);
            p_369957_.m_322496_(DataComponents.f_315394_, bundlecontents$mutable.m_322369_());
        }
    }

    public static boolean m_356052_(ItemStack p_369004_) {
        BundleContents bundlecontents = p_369004_.m_322304_(DataComponents.f_315394_, BundleContents.f_316266_);
        return bundlecontents.m_356300_() != -1;
    }

    public static int m_352788_(ItemStack p_368122_) {
        BundleContents bundlecontents = p_368122_.m_322304_(DataComponents.f_315394_, BundleContents.f_316266_);
        return bundlecontents.m_356300_();
    }

    public static ItemStack m_355315_(ItemStack p_363510_) {
        BundleContents bundlecontents = p_363510_.m_322304_(DataComponents.f_315394_, BundleContents.f_316266_);
        return bundlecontents.m_321524_(bundlecontents.m_356300_());
    }

    public static int m_351870_(ItemStack p_363807_) {
        BundleContents bundlecontents = p_363807_.m_322304_(DataComponents.f_315394_, BundleContents.f_316266_);
        return bundlecontents.m_353699_();
    }

    private boolean m_356605_(ItemStack p_366961_, Player p_369586_) {
        BundleContents bundlecontents = p_366961_.m_323252_(DataComponents.f_315394_);
        if (bundlecontents != null && !bundlecontents.m_319610_()) {
            Optional<ItemStack> optional = m_351877_(p_366961_, p_369586_, bundlecontents);
            if (optional.isPresent()) {
                p_369586_.m_36176_(optional.get(), true);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private static Optional<ItemStack> m_351877_(ItemStack p_366514_, Player p_363747_, BundleContents p_363035_) {
        BundleContents.Mutable bundlecontents$mutable = new BundleContents.Mutable(p_363035_);
        ItemStack itemstack = bundlecontents$mutable.m_324664_();
        if (itemstack != null) {
            m_186342_(p_363747_);
            p_366514_.m_322496_(DataComponents.f_315394_, bundlecontents$mutable.m_322369_());
            return Optional.of(itemstack);
        } else {
            return Optional.empty();
        }
    }

    @Override
    public void m_5929_(Level p_369274_, LivingEntity p_365864_, ItemStack p_364728_, int p_366618_) {
        if (!p_369274_.f_46443_ && p_365864_ instanceof Player player) {
            int i = this.m_8105_(p_364728_, p_365864_);
            boolean flag = p_366618_ == i;
            if (flag || p_366618_ < i - 10 && p_366618_ % 2 == 0) {
                this.m_357259_(p_369274_, player, p_364728_);
            }
        }
    }

    @Override
    public int m_8105_(ItemStack p_363914_, LivingEntity p_368133_) {
        return 200;
    }

    @Override
    public Optional<TooltipComponent> m_142422_(ItemStack p_150775_) {
        return !p_150775_.m_319951_(DataComponents.f_314049_) && !p_150775_.m_319951_(DataComponents.f_316186_)
            ? Optional.ofNullable(p_150775_.m_323252_(DataComponents.f_315394_)).map(BundleTooltip::new)
            : Optional.empty();
    }

    @Override
    public void m_142023_(ItemEntity p_150728_) {
        BundleContents bundlecontents = p_150728_.m_32055_().m_323252_(DataComponents.f_315394_);
        if (bundlecontents != null) {
            p_150728_.m_32055_().m_322496_(DataComponents.f_315394_, BundleContents.f_316266_);
            ItemUtils.m_150952_(p_150728_, bundlecontents.m_322107_());
        }
    }

    public static List<BundleItem> m_354062_() {
        return Stream.of(
                Items.f_151058_,
                Items.f_348203_,
                Items.f_346296_,
                Items.f_346671_,
                Items.f_347817_,
                Items.f_347885_,
                Items.f_349079_,
                Items.f_346373_,
                Items.f_348449_,
                Items.f_347987_,
                Items.f_347553_,
                Items.f_347431_,
                Items.f_346720_,
                Items.f_349538_,
                Items.f_347493_,
                Items.f_349468_,
                Items.f_349374_
            )
            .map(p_359381_ -> (BundleItem)p_359381_)
            .toList();
    }

    public static Item m_357055_(DyeColor p_369131_) {
        return switch (p_369131_) {
            case WHITE -> Items.f_348203_;
            case ORANGE -> Items.f_346296_;
            case MAGENTA -> Items.f_346671_;
            case LIGHT_BLUE -> Items.f_347817_;
            case YELLOW -> Items.f_347885_;
            case LIME -> Items.f_349079_;
            case PINK -> Items.f_346373_;
            case GRAY -> Items.f_348449_;
            case LIGHT_GRAY -> Items.f_347987_;
            case CYAN -> Items.f_347553_;
            case BLUE -> Items.f_349468_;
            case BROWN -> Items.f_346720_;
            case GREEN -> Items.f_349538_;
            case RED -> Items.f_347493_;
            case BLACK -> Items.f_347431_;
            case PURPLE -> Items.f_349374_;
        };
    }

    private static void m_186342_(Entity p_186343_) {
        p_186343_.m_5496_(SoundEvents.f_184216_, 0.8F, 0.8F + p_186343_.m_9236_().m_213780_().m_188501_() * 0.4F);
    }

    private static void m_186351_(Entity p_186352_) {
        p_186352_.m_5496_(SoundEvents.f_184215_, 0.8F, 0.8F + p_186352_.m_9236_().m_213780_().m_188501_() * 0.4F);
    }

    private static void m_357198_(Entity p_367200_) {
        p_367200_.m_5496_(SoundEvents.f_347970_, 1.0F, 1.0F);
    }

    private static void m_186353_(Level p_362376_, Entity p_186354_) {
        p_362376_.m_5594_(
            null, p_186354_.m_20183_(), SoundEvents.f_184214_, SoundSource.PLAYERS, 0.8F, 0.8F + p_186354_.m_9236_().m_213780_().m_188501_() * 0.4F
        );
    }

    private void m_352999_(Player p_365714_) {
        AbstractContainerMenu abstractcontainermenu = p_365714_.f_36096_;
        if (abstractcontainermenu != null) {
            abstractcontainermenu.m_6199_(p_365714_.m_150109_());
        }
    }
}