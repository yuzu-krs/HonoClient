package net.minecraft.world.level.block;

import com.google.common.collect.Maps;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Shulker;
import net.minecraft.world.entity.monster.piglin.PiglinAi;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class ShulkerBoxBlock extends BaseEntityBlock {
    public static final MapCodec<ShulkerBoxBlock> f_303219_ = RecordCodecBuilder.mapCodec(
        p_360450_ -> p_360450_.group(DyeColor.f_262211_.optionalFieldOf("color").forGetter(p_309293_ -> Optional.ofNullable(p_309293_.f_56185_)), m_305607_())
                .apply(p_360450_, (p_309290_, p_309291_) -> new ShulkerBoxBlock(p_309290_.orElse(null), p_309291_))
    );
    private static final Component f_315728_ = Component.m_237115_("container.shulkerBox.unknownContents");
    private static final float f_256820_ = 1.0F;
    private static final VoxelShape f_256853_ = Block.m_49796_(0.0, 15.0, 0.0, 16.0, 16.0, 16.0);
    private static final VoxelShape f_256795_ = Block.m_49796_(0.0, 0.0, 0.0, 16.0, 1.0, 16.0);
    private static final VoxelShape f_256800_ = Block.m_49796_(0.0, 0.0, 0.0, 1.0, 16.0, 16.0);
    private static final VoxelShape f_257037_ = Block.m_49796_(15.0, 0.0, 0.0, 16.0, 16.0, 16.0);
    private static final VoxelShape f_256867_ = Block.m_49796_(0.0, 0.0, 0.0, 16.0, 16.0, 1.0);
    private static final VoxelShape f_256794_ = Block.m_49796_(0.0, 0.0, 15.0, 16.0, 16.0, 16.0);
    private static final Map<Direction, VoxelShape> f_256830_ = Util.m_137469_(Maps.newEnumMap(Direction.class), p_258974_ -> {
        p_258974_.put(Direction.NORTH, f_256867_);
        p_258974_.put(Direction.EAST, f_257037_);
        p_258974_.put(Direction.SOUTH, f_256794_);
        p_258974_.put(Direction.WEST, f_256800_);
        p_258974_.put(Direction.UP, f_256853_);
        p_258974_.put(Direction.DOWN, f_256795_);
    });
    public static final EnumProperty<Direction> f_56183_ = DirectionalBlock.f_52588_;
    public static final ResourceLocation f_56184_ = ResourceLocation.m_340282_("contents");
    @Nullable
    private final DyeColor f_56185_;

    @Override
    public MapCodec<ShulkerBoxBlock> m_304657_() {
        return f_303219_;
    }

    public ShulkerBoxBlock(@Nullable DyeColor p_56188_, BlockBehaviour.Properties p_56189_) {
        super(p_56189_);
        this.f_56185_ = p_56188_;
        this.m_49959_(this.f_49792_.m_61090_().m_61124_(f_56183_, Direction.UP));
    }

    @Override
    public BlockEntity m_142194_(BlockPos p_154552_, BlockState p_154553_) {
        return new ShulkerBoxBlockEntity(this.f_56185_, p_154552_, p_154553_);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> m_142354_(Level p_154543_, BlockState p_154544_, BlockEntityType<T> p_154545_) {
        return m_152132_(p_154545_, BlockEntityType.f_58939_, ShulkerBoxBlockEntity::m_155672_);
    }

    @Override
    protected RenderShape m_7514_(BlockState p_56255_) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    @Override
    protected InteractionResult m_6227_(BlockState p_56227_, Level p_56228_, BlockPos p_56229_, Player p_56230_, BlockHitResult p_56232_) {
        if (p_56228_ instanceof ServerLevel serverlevel
            && p_56228_.m_7702_(p_56229_) instanceof ShulkerBoxBlockEntity shulkerboxblockentity
            && m_154546_(p_56227_, p_56228_, p_56229_, shulkerboxblockentity)) {
            p_56230_.m_5893_(shulkerboxblockentity);
            p_56230_.m_36220_(Stats.f_12970_);
            PiglinAi.m_34873_(serverlevel, p_56230_, true);
        }

        return InteractionResult.f_19068_;
    }

    private static boolean m_154546_(BlockState p_154547_, Level p_154548_, BlockPos p_154549_, ShulkerBoxBlockEntity p_154550_) {
        if (p_154550_.m_59700_() != ShulkerBoxBlockEntity.AnimationStatus.CLOSED) {
            return true;
        } else {
            AABB aabb = Shulker.m_149793_(1.0F, p_154547_.m_61143_(f_56183_), 0.0F, 0.5F).m_82338_(p_154549_).m_82406_(1.0E-6);
            return p_154548_.m_45772_(aabb);
        }
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext p_56198_) {
        return this.m_49966_().m_61124_(f_56183_, p_56198_.m_43719_());
    }

    @Override
    protected void m_7926_(StateDefinition.Builder<Block, BlockState> p_56249_) {
        p_56249_.m_61104_(f_56183_);
    }

    @Override
    public BlockState m_5707_(Level p_56212_, BlockPos p_56213_, BlockState p_56214_, Player p_56215_) {
        BlockEntity blockentity = p_56212_.m_7702_(p_56213_);
        if (blockentity instanceof ShulkerBoxBlockEntity shulkerboxblockentity) {
            if (!p_56212_.f_46443_ && p_56215_.m_7500_() && !shulkerboxblockentity.m_7983_()) {
                ItemStack itemstack = m_56250_(this.m_56261_());
                itemstack.m_323474_(blockentity.m_321843_());
                ItemEntity itementity = new ItemEntity(
                    p_56212_, (double)p_56213_.m_123341_() + 0.5, (double)p_56213_.m_123342_() + 0.5, (double)p_56213_.m_123343_() + 0.5, itemstack
                );
                itementity.m_32060_();
                p_56212_.m_7967_(itementity);
            } else {
                shulkerboxblockentity.m_306438_(p_56215_);
            }
        }

        return super.m_5707_(p_56212_, p_56213_, p_56214_, p_56215_);
    }

    @Override
    protected List<ItemStack> m_49635_(BlockState p_287632_, LootParams.Builder p_287691_) {
        BlockEntity blockentity = p_287691_.m_287159_(LootContextParams.f_81462_);
        if (blockentity instanceof ShulkerBoxBlockEntity shulkerboxblockentity) {
            p_287691_ = p_287691_.m_287145_(f_56184_, p_56219_ -> {
                for (int i = 0; i < shulkerboxblockentity.m_6643_(); i++) {
                    p_56219_.accept(shulkerboxblockentity.m_8020_(i));
                }
            });
        }

        return super.m_49635_(p_287632_, p_287691_);
    }

    @Override
    protected void m_6810_(BlockState p_56234_, Level p_56235_, BlockPos p_56236_, BlockState p_56237_, boolean p_56238_) {
        if (!p_56234_.m_60713_(p_56237_.m_60734_())) {
            BlockEntity blockentity = p_56235_.m_7702_(p_56236_);
            super.m_6810_(p_56234_, p_56235_, p_56236_, p_56237_, p_56238_);
            if (blockentity instanceof ShulkerBoxBlockEntity) {
                p_56235_.m_46717_(p_56236_, p_56234_.m_60734_());
            }
        }
    }

    @Override
    public void m_5871_(ItemStack p_56193_, Item.TooltipContext p_334789_, List<Component> p_56195_, TooltipFlag p_56196_) {
        super.m_5871_(p_56193_, p_334789_, p_56195_, p_56196_);
        if (p_56193_.m_319951_(DataComponents.f_314304_)) {
            p_56195_.add(f_315728_);
        }

        int i = 0;
        int j = 0;

        for (ItemStack itemstack : p_56193_.m_322304_(DataComponents.f_316065_, ItemContainerContents.f_316619_).m_318832_()) {
            j++;
            if (i <= 4) {
                i++;
                p_56195_.add(Component.m_237110_("container.shulkerBox.itemCount", itemstack.m_41786_(), itemstack.m_41613_()));
            }
        }

        if (j - i > 0) {
            p_56195_.add(Component.m_237110_("container.shulkerBox.more", j - i).m_130940_(ChatFormatting.ITALIC));
        }
    }

    @Override
    protected VoxelShape m_7947_(BlockState p_259177_, BlockGetter p_260305_, BlockPos p_259168_) {
        if (p_260305_.m_7702_(p_259168_) instanceof ShulkerBoxBlockEntity shulkerboxblockentity && !shulkerboxblockentity.m_59702_()) {
            return f_256830_.get(p_259177_.m_61143_(f_56183_).m_122424_());
        }

        return Shapes.m_83144_();
    }

    @Override
    protected VoxelShape m_5940_(BlockState p_56257_, BlockGetter p_56258_, BlockPos p_56259_, CollisionContext p_56260_) {
        BlockEntity blockentity = p_56258_.m_7702_(p_56259_);
        return blockentity instanceof ShulkerBoxBlockEntity ? Shapes.m_83064_(((ShulkerBoxBlockEntity)blockentity).m_59666_(p_56257_)) : Shapes.m_83144_();
    }

    @Override
    protected boolean m_49099_(BlockState p_330948_) {
        return false;
    }

    @Override
    protected boolean m_7278_(BlockState p_56221_) {
        return true;
    }

    @Override
    protected int m_6782_(BlockState p_56223_, Level p_56224_, BlockPos p_56225_) {
        return AbstractContainerMenu.m_38918_(p_56224_.m_7702_(p_56225_));
    }

    @Override
    public ItemStack m_7397_(LevelReader p_313060_, BlockPos p_56203_, BlockState p_56204_) {
        ItemStack itemstack = super.m_7397_(p_313060_, p_56203_, p_56204_);
        p_313060_.m_141902_(p_56203_, BlockEntityType.f_58939_).ifPresent(p_327266_ -> p_327266_.m_187476_(itemstack, p_313060_.m_9598_()));
        return itemstack;
    }

    @Nullable
    public static DyeColor m_56252_(Item p_56253_) {
        return m_56262_(Block.m_49814_(p_56253_));
    }

    @Nullable
    public static DyeColor m_56262_(Block p_56263_) {
        return p_56263_ instanceof ShulkerBoxBlock ? ((ShulkerBoxBlock)p_56263_).m_56261_() : null;
    }

    public static Block m_56190_(@Nullable DyeColor p_56191_) {
        if (p_56191_ == null) {
            return Blocks.f_50456_;
        } else {
            return switch (p_56191_) {
                case WHITE -> Blocks.f_50457_;
                case ORANGE -> Blocks.f_50458_;
                case MAGENTA -> Blocks.f_50459_;
                case LIGHT_BLUE -> Blocks.f_50460_;
                case YELLOW -> Blocks.f_50461_;
                case LIME -> Blocks.f_50462_;
                case PINK -> Blocks.f_50463_;
                case GRAY -> Blocks.f_50464_;
                case LIGHT_GRAY -> Blocks.f_50465_;
                case CYAN -> Blocks.f_50466_;
                case BLUE -> Blocks.f_50521_;
                case BROWN -> Blocks.f_50522_;
                case GREEN -> Blocks.f_50523_;
                case RED -> Blocks.f_50524_;
                case BLACK -> Blocks.f_50525_;
                case PURPLE -> Blocks.f_50520_;
            };
        }
    }

    @Nullable
    public DyeColor m_56261_() {
        return this.f_56185_;
    }

    public static ItemStack m_56250_(@Nullable DyeColor p_56251_) {
        return new ItemStack(m_56190_(p_56251_));
    }

    @Override
    protected BlockState m_6843_(BlockState p_56243_, Rotation p_56244_) {
        return p_56243_.m_61124_(f_56183_, p_56244_.m_55954_(p_56243_.m_61143_(f_56183_)));
    }

    @Override
    protected BlockState m_6943_(BlockState p_56240_, Mirror p_56241_) {
        return p_56240_.m_60717_(p_56241_.m_54846_(p_56240_.m_61143_(f_56183_)));
    }
}