package net.minecraft.world.level.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.stream.IntStream;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.StairsShape;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class StairBlock extends Block implements SimpleWaterloggedBlock {
    public static final MapCodec<StairBlock> f_303622_ = RecordCodecBuilder.mapCodec(
        p_360454_ -> p_360454_.group(BlockState.f_61039_.fieldOf("base_state").forGetter(p_309296_ -> p_309296_.f_56859_), m_305607_())
                .apply(p_360454_, StairBlock::new)
    );
    public static final EnumProperty<Direction> f_56841_ = HorizontalDirectionalBlock.f_54117_;
    public static final EnumProperty<Half> f_56842_ = BlockStateProperties.f_61402_;
    public static final EnumProperty<StairsShape> f_56843_ = BlockStateProperties.f_61398_;
    public static final BooleanProperty f_56844_ = BlockStateProperties.f_61362_;
    protected static final VoxelShape f_56845_ = SlabBlock.f_56356_;
    protected static final VoxelShape f_56846_ = SlabBlock.f_56355_;
    protected static final VoxelShape f_56847_ = Block.m_49796_(0.0, 0.0, 0.0, 8.0, 8.0, 8.0);
    protected static final VoxelShape f_56848_ = Block.m_49796_(0.0, 0.0, 8.0, 8.0, 8.0, 16.0);
    protected static final VoxelShape f_56849_ = Block.m_49796_(0.0, 8.0, 0.0, 8.0, 16.0, 8.0);
    protected static final VoxelShape f_56850_ = Block.m_49796_(0.0, 8.0, 8.0, 8.0, 16.0, 16.0);
    protected static final VoxelShape f_56851_ = Block.m_49796_(8.0, 0.0, 0.0, 16.0, 8.0, 8.0);
    protected static final VoxelShape f_56852_ = Block.m_49796_(8.0, 0.0, 8.0, 16.0, 8.0, 16.0);
    protected static final VoxelShape f_56853_ = Block.m_49796_(8.0, 8.0, 0.0, 16.0, 16.0, 8.0);
    protected static final VoxelShape f_56854_ = Block.m_49796_(8.0, 8.0, 8.0, 16.0, 16.0, 16.0);
    protected static final VoxelShape[] f_56855_ = m_56933_(f_56845_, f_56847_, f_56851_, f_56848_, f_56852_);
    protected static final VoxelShape[] f_56856_ = m_56933_(f_56846_, f_56849_, f_56853_, f_56850_, f_56854_);
    private static final int[] f_56857_ = new int[]{12, 5, 3, 10, 14, 13, 7, 11, 13, 7, 11, 14, 8, 4, 1, 2, 4, 1, 2, 8};
    private final Block f_56858_;
    protected final BlockState f_56859_;

    @Override
    public MapCodec<? extends StairBlock> m_304657_() {
        return f_303622_;
    }

    private static VoxelShape[] m_56933_(VoxelShape p_56934_, VoxelShape p_56935_, VoxelShape p_56936_, VoxelShape p_56937_, VoxelShape p_56938_) {
        return IntStream.range(0, 16).mapToObj(p_56945_ -> m_56864_(p_56945_, p_56934_, p_56935_, p_56936_, p_56937_, p_56938_)).toArray(VoxelShape[]::new);
    }

    private static VoxelShape m_56864_(int p_56865_, VoxelShape p_56866_, VoxelShape p_56867_, VoxelShape p_56868_, VoxelShape p_56869_, VoxelShape p_56870_) {
        VoxelShape voxelshape = p_56866_;
        if ((p_56865_ & 1) != 0) {
            voxelshape = Shapes.m_83110_(p_56866_, p_56867_);
        }

        if ((p_56865_ & 2) != 0) {
            voxelshape = Shapes.m_83110_(voxelshape, p_56868_);
        }

        if ((p_56865_ & 4) != 0) {
            voxelshape = Shapes.m_83110_(voxelshape, p_56869_);
        }

        if ((p_56865_ & 8) != 0) {
            voxelshape = Shapes.m_83110_(voxelshape, p_56870_);
        }

        return voxelshape;
    }

    protected StairBlock(BlockState p_56862_, BlockBehaviour.Properties p_56863_) {
        super(p_56863_);
        this.m_49959_(
            this.f_49792_
                .m_61090_()
                .m_61124_(f_56841_, Direction.NORTH)
                .m_61124_(f_56842_, Half.BOTTOM)
                .m_61124_(f_56843_, StairsShape.STRAIGHT)
                .m_61124_(f_56844_, Boolean.valueOf(false))
        );
        this.f_56858_ = p_56862_.m_60734_();
        this.f_56859_ = p_56862_;
    }

    @Override
    protected boolean m_7923_(BlockState p_56967_) {
        return true;
    }

    @Override
    protected VoxelShape m_5940_(BlockState p_56956_, BlockGetter p_56957_, BlockPos p_56958_, CollisionContext p_56959_) {
        return (p_56956_.m_61143_(f_56842_) == Half.TOP ? f_56855_ : f_56856_)[f_56857_[this.m_56982_(p_56956_)]];
    }

    private int m_56982_(BlockState p_56983_) {
        return p_56983_.m_61143_(f_56843_).ordinal() * 4 + p_56983_.m_61143_(f_56841_).m_122416_();
    }

    @Override
    public float m_7325_() {
        return this.f_56858_.m_7325_();
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext p_56872_) {
        Direction direction = p_56872_.m_43719_();
        BlockPos blockpos = p_56872_.m_8083_();
        FluidState fluidstate = p_56872_.m_43725_().m_6425_(blockpos);
        BlockState blockstate = this.m_49966_()
            .m_61124_(f_56841_, p_56872_.m_8125_())
            .m_61124_(
                f_56842_,
                direction != Direction.DOWN && (direction == Direction.UP || !(p_56872_.m_43720_().f_82480_ - (double)blockpos.m_123342_() > 0.5))
                    ? Half.BOTTOM
                    : Half.TOP
            )
            .m_61124_(f_56844_, Boolean.valueOf(fluidstate.m_76152_() == Fluids.f_76193_));
        return blockstate.m_61124_(f_56843_, m_56976_(blockstate, p_56872_.m_43725_(), blockpos));
    }

    @Override
    protected BlockState m_7417_(
        BlockState p_56925_,
        LevelReader p_369543_,
        ScheduledTickAccess p_369679_,
        BlockPos p_56929_,
        Direction p_56926_,
        BlockPos p_56930_,
        BlockState p_56927_,
        RandomSource p_367682_
    ) {
        if (p_56925_.m_61143_(f_56844_)) {
            p_369679_.m_356268_(p_56929_, Fluids.f_76193_, Fluids.f_76193_.m_6718_(p_369543_));
        }

        return p_56926_.m_122434_().m_122479_()
            ? p_56925_.m_61124_(f_56843_, m_56976_(p_56925_, p_369543_, p_56929_))
            : super.m_7417_(p_56925_, p_369543_, p_369679_, p_56929_, p_56926_, p_56930_, p_56927_, p_367682_);
    }

    private static StairsShape m_56976_(BlockState p_56977_, BlockGetter p_56978_, BlockPos p_56979_) {
        Direction direction = p_56977_.m_61143_(f_56841_);
        BlockState blockstate = p_56978_.m_8055_(p_56979_.m_121945_(direction));
        if (m_56980_(blockstate) && p_56977_.m_61143_(f_56842_) == blockstate.m_61143_(f_56842_)) {
            Direction direction1 = blockstate.m_61143_(f_56841_);
            if (direction1.m_122434_() != p_56977_.m_61143_(f_56841_).m_122434_() && m_56970_(p_56977_, p_56978_, p_56979_, direction1.m_122424_())) {
                if (direction1 == direction.m_122428_()) {
                    return StairsShape.OUTER_LEFT;
                }

                return StairsShape.OUTER_RIGHT;
            }
        }

        BlockState blockstate1 = p_56978_.m_8055_(p_56979_.m_121945_(direction.m_122424_()));
        if (m_56980_(blockstate1) && p_56977_.m_61143_(f_56842_) == blockstate1.m_61143_(f_56842_)) {
            Direction direction2 = blockstate1.m_61143_(f_56841_);
            if (direction2.m_122434_() != p_56977_.m_61143_(f_56841_).m_122434_() && m_56970_(p_56977_, p_56978_, p_56979_, direction2)) {
                if (direction2 == direction.m_122428_()) {
                    return StairsShape.INNER_LEFT;
                }

                return StairsShape.INNER_RIGHT;
            }
        }

        return StairsShape.STRAIGHT;
    }

    private static boolean m_56970_(BlockState p_56971_, BlockGetter p_56972_, BlockPos p_56973_, Direction p_56974_) {
        BlockState blockstate = p_56972_.m_8055_(p_56973_.m_121945_(p_56974_));
        return !m_56980_(blockstate)
            || blockstate.m_61143_(f_56841_) != p_56971_.m_61143_(f_56841_)
            || blockstate.m_61143_(f_56842_) != p_56971_.m_61143_(f_56842_);
    }

    public static boolean m_56980_(BlockState p_56981_) {
        return p_56981_.m_60734_() instanceof StairBlock;
    }

    @Override
    protected BlockState m_6843_(BlockState p_56922_, Rotation p_56923_) {
        return p_56922_.m_61124_(f_56841_, p_56923_.m_55954_(p_56922_.m_61143_(f_56841_)));
    }

    @Override
    protected BlockState m_6943_(BlockState p_56919_, Mirror p_56920_) {
        Direction direction = p_56919_.m_61143_(f_56841_);
        StairsShape stairsshape = p_56919_.m_61143_(f_56843_);
        switch (p_56920_) {
            case LEFT_RIGHT:
                if (direction.m_122434_() == Direction.Axis.Z) {
                    switch (stairsshape) {
                        case INNER_LEFT:
                            return p_56919_.m_60717_(Rotation.CLOCKWISE_180).m_61124_(f_56843_, StairsShape.INNER_RIGHT);
                        case INNER_RIGHT:
                            return p_56919_.m_60717_(Rotation.CLOCKWISE_180).m_61124_(f_56843_, StairsShape.INNER_LEFT);
                        case OUTER_LEFT:
                            return p_56919_.m_60717_(Rotation.CLOCKWISE_180).m_61124_(f_56843_, StairsShape.OUTER_RIGHT);
                        case OUTER_RIGHT:
                            return p_56919_.m_60717_(Rotation.CLOCKWISE_180).m_61124_(f_56843_, StairsShape.OUTER_LEFT);
                        default:
                            return p_56919_.m_60717_(Rotation.CLOCKWISE_180);
                    }
                }
                break;
            case FRONT_BACK:
                if (direction.m_122434_() == Direction.Axis.X) {
                    switch (stairsshape) {
                        case INNER_LEFT:
                            return p_56919_.m_60717_(Rotation.CLOCKWISE_180).m_61124_(f_56843_, StairsShape.INNER_LEFT);
                        case INNER_RIGHT:
                            return p_56919_.m_60717_(Rotation.CLOCKWISE_180).m_61124_(f_56843_, StairsShape.INNER_RIGHT);
                        case OUTER_LEFT:
                            return p_56919_.m_60717_(Rotation.CLOCKWISE_180).m_61124_(f_56843_, StairsShape.OUTER_RIGHT);
                        case OUTER_RIGHT:
                            return p_56919_.m_60717_(Rotation.CLOCKWISE_180).m_61124_(f_56843_, StairsShape.OUTER_LEFT);
                        case STRAIGHT:
                            return p_56919_.m_60717_(Rotation.CLOCKWISE_180);
                    }
                }
        }

        return super.m_6943_(p_56919_, p_56920_);
    }

    @Override
    protected void m_7926_(StateDefinition.Builder<Block, BlockState> p_56932_) {
        p_56932_.m_61104_(f_56841_, f_56842_, f_56843_, f_56844_);
    }

    @Override
    protected FluidState m_5888_(BlockState p_56969_) {
        return p_56969_.m_61143_(f_56844_) ? Fluids.f_76193_.m_76068_(false) : super.m_5888_(p_56969_);
    }

    @Override
    protected boolean m_7357_(BlockState p_56891_, PathComputationType p_56894_) {
        return false;
    }
}