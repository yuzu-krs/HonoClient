package net.minecraft.world.level.block;

import com.mojang.serialization.MapCodec;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.FrontAndTop;
import net.minecraft.core.dispenser.DefaultDispenseItemBehavior;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeCache;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.CrafterBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.redstone.Orientation;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class CrafterBlock extends BaseEntityBlock {
    public static final MapCodec<CrafterBlock> f_303783_ = m_306223_(CrafterBlock::new);
    public static final BooleanProperty f_302342_ = BlockStateProperties.f_303070_;
    public static final BooleanProperty f_303414_ = BlockStateProperties.f_61360_;
    private static final EnumProperty<FrontAndTop> f_303600_ = BlockStateProperties.f_61375_;
    private static final int f_303278_ = 6;
    private static final int f_303006_ = 4;
    private static final RecipeCache f_302794_ = new RecipeCache(10);
    private static final int f_314105_ = 17;

    public CrafterBlock(BlockBehaviour.Properties p_310228_) {
        super(p_310228_);
        this.m_49959_(
            this.f_49792_
                .m_61090_()
                .m_61124_(f_303600_, FrontAndTop.NORTH_UP)
                .m_61124_(f_303414_, Boolean.valueOf(false))
                .m_61124_(f_302342_, Boolean.valueOf(false))
        );
    }

    @Override
    protected MapCodec<CrafterBlock> m_304657_() {
        return f_303783_;
    }

    @Override
    protected boolean m_7278_(BlockState p_309929_) {
        return true;
    }

    @Override
    protected int m_6782_(BlockState p_311332_, Level p_310277_, BlockPos p_312038_) {
        return p_310277_.m_7702_(p_312038_) instanceof CrafterBlockEntity crafterblockentity ? crafterblockentity.m_304952_() : 0;
    }

    @Override
    protected void m_6861_(BlockState p_309741_, Level p_312714_, BlockPos p_310958_, Block p_313237_, @Nullable Orientation p_364282_, boolean p_309615_) {
        boolean flag = p_312714_.m_276867_(p_310958_);
        boolean flag1 = p_309741_.m_61143_(f_303414_);
        BlockEntity blockentity = p_312714_.m_7702_(p_310958_);
        if (flag && !flag1) {
            p_312714_.m_352153_(p_310958_, this, 4);
            p_312714_.m_7731_(p_310958_, p_309741_.m_61124_(f_303414_, Boolean.valueOf(true)), 2);
            this.m_306927_(blockentity, true);
        } else if (!flag && flag1) {
            p_312714_.m_7731_(p_310958_, p_309741_.m_61124_(f_303414_, Boolean.valueOf(false)).m_61124_(f_302342_, Boolean.valueOf(false)), 2);
            this.m_306927_(blockentity, false);
        }
    }

    @Override
    protected void m_213897_(BlockState p_310321_, ServerLevel p_312701_, BlockPos p_311281_, RandomSource p_311092_) {
        this.m_305705_(p_310321_, p_312701_, p_311281_);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> m_142354_(Level p_310928_, BlockState p_311648_, BlockEntityType<T> p_310343_) {
        return p_310928_.f_46443_ ? null : m_152132_(p_310343_, BlockEntityType.f_302698_, CrafterBlockEntity::m_307890_);
    }

    private void m_306927_(@Nullable BlockEntity p_312888_, boolean p_312611_) {
        if (p_312888_ instanceof CrafterBlockEntity crafterblockentity) {
            crafterblockentity.m_305342_(p_312611_);
        }
    }

    @Override
    public BlockEntity m_142194_(BlockPos p_311818_, BlockState p_310225_) {
        CrafterBlockEntity crafterblockentity = new CrafterBlockEntity(p_311818_, p_310225_);
        crafterblockentity.m_305342_(p_310225_.m_61138_(f_303414_) && p_310225_.m_61143_(f_303414_));
        return crafterblockentity;
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext p_311294_) {
        Direction direction = p_311294_.m_7820_().m_122424_();

        Direction direction1 = switch (direction) {
            case DOWN -> p_311294_.m_8125_().m_122424_();
            case UP -> p_311294_.m_8125_();
            case NORTH, SOUTH, WEST, EAST -> Direction.UP;
        };
        return this.m_49966_()
            .m_61124_(f_303600_, FrontAndTop.m_122622_(direction, direction1))
            .m_61124_(f_303414_, Boolean.valueOf(p_311294_.m_43725_().m_276867_(p_311294_.m_8083_())));
    }

    @Override
    public void m_6402_(Level p_311617_, BlockPos p_313069_, BlockState p_310230_, LivingEntity p_310379_, ItemStack p_311227_) {
        if (p_310230_.m_61143_(f_303414_)) {
            p_311617_.m_352153_(p_313069_, this, 4);
        }
    }

    @Override
    protected void m_6810_(BlockState p_310019_, Level p_310489_, BlockPos p_312335_, BlockState p_311081_, boolean p_310350_) {
        Containers.m_307148_(p_310019_, p_311081_, p_310489_, p_312335_);
        super.m_6810_(p_310019_, p_310489_, p_312335_, p_311081_, p_310350_);
    }

    @Override
    protected InteractionResult m_6227_(BlockState p_309704_, Level p_312700_, BlockPos p_310945_, Player p_312953_, BlockHitResult p_309965_) {
        if (!p_312700_.f_46443_ && p_312700_.m_7702_(p_310945_) instanceof CrafterBlockEntity crafterblockentity) {
            p_312953_.m_5893_(crafterblockentity);
        }

        return InteractionResult.f_19068_;
    }

    protected void m_305705_(BlockState p_313036_, ServerLevel p_310451_, BlockPos p_310774_) {
        if (p_310451_.m_7702_(p_310774_) instanceof CrafterBlockEntity crafterblockentity) {
            CraftingInput craftinginput = crafterblockentity.m_339147_();
            Optional<RecipeHolder<CraftingRecipe>> optional = m_305919_(p_310451_, craftinginput);
            if (optional.isEmpty()) {
                p_310451_.m_46796_(1050, p_310774_, 0);
            } else {
                RecipeHolder<CraftingRecipe> recipeholder = optional.get();
                ItemStack itemstack = recipeholder.f_291008_().m_5874_(craftinginput, p_310451_.m_9598_());
                if (itemstack.m_41619_()) {
                    p_310451_.m_46796_(1050, p_310774_, 0);
                } else {
                    crafterblockentity.m_305296_(6);
                    p_310451_.m_7731_(p_310774_, p_313036_.m_61124_(f_302342_, Boolean.valueOf(true)), 2);
                    itemstack.m_305085_(p_310451_);
                    this.m_304843_(p_310451_, p_310774_, crafterblockentity, itemstack, p_313036_, recipeholder);

                    for (ItemStack itemstack1 : recipeholder.f_291008_().m_43790_(craftinginput)) {
                        if (!itemstack1.m_41619_()) {
                            this.m_304843_(p_310451_, p_310774_, crafterblockentity, itemstack1, p_313036_, recipeholder);
                        }
                    }

                    crafterblockentity.m_58617_().forEach(p_312802_ -> {
                        if (!p_312802_.m_41619_()) {
                            p_312802_.m_41774_(1);
                        }
                    });
                    crafterblockentity.m_6596_();
                }
            }
        }
    }

    public static Optional<RecipeHolder<CraftingRecipe>> m_305919_(ServerLevel p_367007_, CraftingInput p_342419_) {
        return f_302794_.m_304754_(p_367007_, p_342419_);
    }

    private void m_304843_(
        ServerLevel p_336186_, BlockPos p_312358_, CrafterBlockEntity p_309887_, ItemStack p_310474_, BlockState p_310667_, RecipeHolder<?> p_329387_
    ) {
        Direction direction = p_310667_.m_61143_(f_303600_).m_122625_();
        Container container = HopperBlockEntity.m_59390_(p_336186_, p_312358_.m_121945_(direction));
        ItemStack itemstack = p_310474_.m_41777_();
        if (container != null && (container instanceof CrafterBlockEntity || p_310474_.m_41613_() > container.m_322387_(p_310474_))) {
            while (!itemstack.m_41619_()) {
                ItemStack itemstack2 = itemstack.m_255036_(1);
                ItemStack itemstack1 = HopperBlockEntity.m_59326_(p_309887_, container, itemstack2, direction.m_122424_());
                if (!itemstack1.m_41619_()) {
                    break;
                }

                itemstack.m_41774_(1);
            }
        } else if (container != null) {
            while (!itemstack.m_41619_()) {
                int i = itemstack.m_41613_();
                itemstack = HopperBlockEntity.m_59326_(p_309887_, container, itemstack, direction.m_122424_());
                if (i == itemstack.m_41613_()) {
                    break;
                }
            }
        }

        if (!itemstack.m_41619_()) {
            Vec3 vec3 = Vec3.m_82512_(p_312358_);
            Vec3 vec31 = vec3.m_231075_(direction, 0.7);
            DefaultDispenseItemBehavior.m_123378_(p_336186_, itemstack, 6, direction, vec31);

            for (ServerPlayer serverplayer : p_336186_.m_45976_(ServerPlayer.class, AABB.m_165882_(vec3, 17.0, 17.0, 17.0))) {
                CriteriaTriggers.f_315310_.m_280437_(serverplayer, p_329387_.f_291676_(), p_309887_.m_58617_());
            }

            p_336186_.m_46796_(1049, p_312358_, 0);
            p_336186_.m_46796_(2010, p_312358_, direction.m_122411_());
        }
    }

    @Override
    protected RenderShape m_7514_(BlockState p_311546_) {
        return RenderShape.MODEL;
    }

    @Override
    protected BlockState m_6843_(BlockState p_312403_, Rotation p_309910_) {
        return p_312403_.m_61124_(f_303600_, p_309910_.m_55948_().m_56530_(p_312403_.m_61143_(f_303600_)));
    }

    @Override
    protected BlockState m_6943_(BlockState p_310178_, Mirror p_311418_) {
        return p_310178_.m_61124_(f_303600_, p_311418_.m_54842_().m_56530_(p_310178_.m_61143_(f_303600_)));
    }

    @Override
    protected void m_7926_(StateDefinition.Builder<Block, BlockState> p_310076_) {
        p_310076_.m_61104_(f_303600_, f_303414_, f_302342_);
    }
}