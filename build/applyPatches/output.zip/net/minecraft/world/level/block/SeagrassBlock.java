package net.minecraft.world.level.block;

import com.mojang.serialization.MapCodec;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class SeagrassBlock extends BushBlock implements BonemealableBlock, LiquidBlockContainer {
    public static final MapCodec<SeagrassBlock> f_303240_ = m_306223_(SeagrassBlock::new);
    protected static final float f_154492_ = 6.0F;
    protected static final VoxelShape f_154493_ = Block.m_49796_(2.0, 0.0, 2.0, 14.0, 12.0, 14.0);

    @Override
    public MapCodec<SeagrassBlock> m_304657_() {
        return f_303240_;
    }

    protected SeagrassBlock(BlockBehaviour.Properties p_154496_) {
        super(p_154496_);
    }

    @Override
    protected VoxelShape m_5940_(BlockState p_154525_, BlockGetter p_154526_, BlockPos p_154527_, CollisionContext p_154528_) {
        return f_154493_;
    }

    @Override
    protected boolean m_6266_(BlockState p_154539_, BlockGetter p_154540_, BlockPos p_154541_) {
        return p_154539_.m_60783_(p_154540_, p_154541_, Direction.UP) && !p_154539_.m_60713_(Blocks.f_50450_);
    }

    @Nullable
    @Override
    public BlockState m_5573_(BlockPlaceContext p_154503_) {
        FluidState fluidstate = p_154503_.m_43725_().m_6425_(p_154503_.m_8083_());
        return fluidstate.m_205070_(FluidTags.f_13131_) && fluidstate.m_76186_() == 8 ? super.m_5573_(p_154503_) : null;
    }

    @Override
    protected BlockState m_7417_(
        BlockState p_154530_,
        LevelReader p_364898_,
        ScheduledTickAccess p_361517_,
        BlockPos p_154534_,
        Direction p_154531_,
        BlockPos p_154535_,
        BlockState p_154532_,
        RandomSource p_362464_
    ) {
        BlockState blockstate = super.m_7417_(p_154530_, p_364898_, p_361517_, p_154534_, p_154531_, p_154535_, p_154532_, p_362464_);
        if (!blockstate.m_60795_()) {
            p_361517_.m_356268_(p_154534_, Fluids.f_76193_, Fluids.f_76193_.m_6718_(p_364898_));
        }

        return blockstate;
    }

    @Override
    public boolean m_7370_(LevelReader p_298898_, BlockPos p_154506_, BlockState p_154507_) {
        return p_298898_.m_8055_(p_154506_.m_7494_()).m_60713_(Blocks.f_49990_);
    }

    @Override
    public boolean m_214167_(Level p_222428_, RandomSource p_222429_, BlockPos p_222430_, BlockState p_222431_) {
        return true;
    }

    @Override
    protected FluidState m_5888_(BlockState p_154537_) {
        return Fluids.f_76193_.m_76068_(false);
    }

    @Override
    public void m_214148_(ServerLevel p_222423_, RandomSource p_222424_, BlockPos p_222425_, BlockState p_222426_) {
        BlockState blockstate = Blocks.f_50038_.m_49966_();
        BlockState blockstate1 = blockstate.m_61124_(TallSeagrassBlock.f_154740_, DoubleBlockHalf.UPPER);
        BlockPos blockpos = p_222425_.m_7494_();
        p_222423_.m_7731_(p_222425_, blockstate, 2);
        p_222423_.m_7731_(blockpos, blockstate1, 2);
    }

    @Override
    public boolean m_6044_(@Nullable Player p_297962_, BlockGetter p_299850_, BlockPos p_154511_, BlockState p_154512_, Fluid p_299663_) {
        return false;
    }

    @Override
    public boolean m_7361_(LevelAccessor p_154520_, BlockPos p_154521_, BlockState p_154522_, FluidState p_154523_) {
        return false;
    }
}