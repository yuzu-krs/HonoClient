package net.minecraft.world.level.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class CakeBlock extends Block {
    public static final MapCodec<CakeBlock> f_303361_ = m_306223_(CakeBlock::new);
    public static final int f_152742_ = 6;
    public static final IntegerProperty f_51180_ = BlockStateProperties.f_61412_;
    public static final int f_152743_ = m_152746_(0);
    protected static final float f_152744_ = 1.0F;
    protected static final float f_152745_ = 2.0F;
    protected static final VoxelShape[] f_51181_ = new VoxelShape[]{
        Block.m_49796_(1.0, 0.0, 1.0, 15.0, 8.0, 15.0),
        Block.m_49796_(3.0, 0.0, 1.0, 15.0, 8.0, 15.0),
        Block.m_49796_(5.0, 0.0, 1.0, 15.0, 8.0, 15.0),
        Block.m_49796_(7.0, 0.0, 1.0, 15.0, 8.0, 15.0),
        Block.m_49796_(9.0, 0.0, 1.0, 15.0, 8.0, 15.0),
        Block.m_49796_(11.0, 0.0, 1.0, 15.0, 8.0, 15.0),
        Block.m_49796_(13.0, 0.0, 1.0, 15.0, 8.0, 15.0)
    };

    @Override
    public MapCodec<CakeBlock> m_304657_() {
        return f_303361_;
    }

    protected CakeBlock(BlockBehaviour.Properties p_51184_) {
        super(p_51184_);
        this.m_49959_(this.f_49792_.m_61090_().m_61124_(f_51180_, Integer.valueOf(0)));
    }

    @Override
    protected VoxelShape m_5940_(BlockState p_51222_, BlockGetter p_51223_, BlockPos p_51224_, CollisionContext p_51225_) {
        return f_51181_[p_51222_.m_61143_(f_51180_)];
    }

    @Override
    protected InteractionResult m_51273_(
        ItemStack p_332983_, BlockState p_333266_, Level p_328017_, BlockPos p_332811_, Player p_327926_, InteractionHand p_330281_, BlockHitResult p_332277_
    ) {
        Item item = p_332983_.m_41720_();
        if (p_332983_.m_204117_(ItemTags.f_144319_) && p_333266_.m_61143_(f_51180_) == 0 && Block.m_49814_(item) instanceof CandleBlock candleblock) {
            p_332983_.m_321439_(1, p_327926_);
            p_328017_.m_5594_(null, p_332811_, SoundEvents.f_144090_, SoundSource.BLOCKS, 1.0F, 1.0F);
            p_328017_.m_46597_(p_332811_, CandleCakeBlock.m_152865_(candleblock));
            p_328017_.m_142346_(p_327926_, GameEvent.f_157792_, p_332811_);
            p_327926_.m_36246_(Stats.f_12982_.m_12902_(item));
            return InteractionResult.f_19068_;
        } else {
            return InteractionResult.f_348895_;
        }
    }

    @Override
    protected InteractionResult m_6227_(BlockState p_331745_, Level p_334119_, BlockPos p_330552_, Player p_332095_, BlockHitResult p_329702_) {
        if (p_334119_.f_46443_) {
            if (m_51185_(p_334119_, p_330552_, p_331745_, p_332095_).m_19077_()) {
                return InteractionResult.f_19068_;
            }

            if (p_332095_.m_21120_(InteractionHand.MAIN_HAND).m_41619_()) {
                return InteractionResult.f_19069_;
            }
        }

        return m_51185_(p_334119_, p_330552_, p_331745_, p_332095_);
    }

    protected static InteractionResult m_51185_(LevelAccessor p_51186_, BlockPos p_51187_, BlockState p_51188_, Player p_51189_) {
        if (!p_51189_.m_36391_(false)) {
            return InteractionResult.f_19070_;
        } else {
            p_51189_.m_36220_(Stats.f_12942_);
            p_51189_.m_36324_().m_38707_(2, 0.1F);
            int i = p_51188_.m_61143_(f_51180_);
            p_51186_.m_142346_(p_51189_, GameEvent.f_157806_, p_51187_);
            if (i < 6) {
                p_51186_.m_7731_(p_51187_, p_51188_.m_61124_(f_51180_, Integer.valueOf(i + 1)), 3);
            } else {
                p_51186_.m_7471_(p_51187_, false);
                p_51186_.m_142346_(p_51189_, GameEvent.f_157794_, p_51187_);
            }

            return InteractionResult.f_19068_;
        }
    }

    @Override
    protected BlockState m_7417_(
        BlockState p_51213_,
        LevelReader p_366089_,
        ScheduledTickAccess p_363263_,
        BlockPos p_51217_,
        Direction p_51214_,
        BlockPos p_51218_,
        BlockState p_51215_,
        RandomSource p_363935_
    ) {
        return p_51214_ == Direction.DOWN && !p_51213_.m_60710_(p_366089_, p_51217_)
            ? Blocks.f_50016_.m_49966_()
            : super.m_7417_(p_51213_, p_366089_, p_363263_, p_51217_, p_51214_, p_51218_, p_51215_, p_363935_);
    }

    @Override
    protected boolean m_7898_(BlockState p_51209_, LevelReader p_51210_, BlockPos p_51211_) {
        return p_51210_.m_8055_(p_51211_.m_7495_()).m_280296_();
    }

    @Override
    protected void m_7926_(StateDefinition.Builder<Block, BlockState> p_51220_) {
        p_51220_.m_61104_(f_51180_);
    }

    @Override
    protected int m_6782_(BlockState p_51198_, Level p_51199_, BlockPos p_51200_) {
        return m_152746_(p_51198_.m_61143_(f_51180_));
    }

    public static int m_152746_(int p_152747_) {
        return (7 - p_152747_) * 2;
    }

    @Override
    protected boolean m_7278_(BlockState p_51191_) {
        return true;
    }

    @Override
    protected boolean m_7357_(BlockState p_51193_, PathComputationType p_51196_) {
        return false;
    }
}