package net.minecraft.world.level.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BrushableBlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.Vec3;

public class BrushableBlock extends BaseEntityBlock implements Fallable {
    public static final MapCodec<BrushableBlock> f_302569_ = RecordCodecBuilder.mapCodec(
        p_360401_ -> p_360401_.group(
                    BuiltInRegistries.f_256975_.m_194605_().fieldOf("turns_into").forGetter(BrushableBlock::m_277074_),
                    BuiltInRegistries.f_256894_.m_194605_().fieldOf("brush_sound").forGetter(BrushableBlock::m_276856_),
                    BuiltInRegistries.f_256894_.m_194605_().fieldOf("brush_completed_sound").forGetter(BrushableBlock::m_277154_),
                    m_305607_()
                )
                .apply(p_360401_, BrushableBlock::new)
    );
    private static final IntegerProperty f_276488_ = BlockStateProperties.f_271112_;
    public static final int f_276547_ = 2;
    private final Block f_276601_;
    private final SoundEvent f_276507_;
    private final SoundEvent f_276618_;

    @Override
    public MapCodec<BrushableBlock> m_304657_() {
        return f_302569_;
    }

    public BrushableBlock(Block p_277629_, SoundEvent p_278060_, SoundEvent p_277352_, BlockBehaviour.Properties p_277373_) {
        super(p_277373_);
        this.f_276601_ = p_277629_;
        this.f_276507_ = p_278060_;
        this.f_276618_ = p_277352_;
        this.m_49959_(this.f_49792_.m_61090_().m_61124_(f_276488_, Integer.valueOf(0)));
    }

    @Override
    protected void m_7926_(StateDefinition.Builder<Block, BlockState> p_277623_) {
        p_277623_.m_61104_(f_276488_);
    }

    @Override
    public RenderShape m_7514_(BlockState p_277553_) {
        return RenderShape.MODEL;
    }

    @Override
    public void m_6807_(BlockState p_277817_, Level p_277984_, BlockPos p_277869_, BlockState p_277926_, boolean p_277736_) {
        p_277984_.m_352153_(p_277869_, this, 2);
    }

    @Override
    public BlockState m_7417_(
        BlockState p_277801_,
        LevelReader p_365867_,
        ScheduledTickAccess p_367791_,
        BlockPos p_278111_,
        Direction p_277455_,
        BlockPos p_277904_,
        BlockState p_277832_,
        RandomSource p_364049_
    ) {
        p_367791_.m_352153_(p_278111_, this, 2);
        return super.m_7417_(p_277801_, p_365867_, p_367791_, p_278111_, p_277455_, p_277904_, p_277832_, p_364049_);
    }

    @Override
    public void m_213897_(BlockState p_277544_, ServerLevel p_277779_, BlockPos p_278019_, RandomSource p_277471_) {
        if (p_277779_.m_7702_(p_278019_) instanceof BrushableBlockEntity brushableblockentity) {
            brushableblockentity.m_277175_(p_277779_);
        }

        if (FallingBlock.m_53241_(p_277779_.m_8055_(p_278019_.m_7495_())) && p_278019_.m_123342_() >= p_277779_.m_141937_()) {
            FallingBlockEntity fallingblockentity = FallingBlockEntity.m_201971_(p_277779_, p_278019_, p_277544_);
            fallingblockentity.m_272001_();
        }
    }

    @Override
    public void m_142525_(Level p_278097_, BlockPos p_277734_, FallingBlockEntity p_277539_) {
        Vec3 vec3 = p_277539_.m_20191_().m_82399_();
        p_278097_.m_46796_(2001, BlockPos.m_274446_(vec3), Block.m_49956_(p_277539_.m_31980_()));
        p_278097_.m_220400_(p_277539_, GameEvent.f_157794_, vec3);
    }

    @Override
    public void m_214162_(BlockState p_277390_, Level p_277525_, BlockPos p_278107_, RandomSource p_277574_) {
        if (p_277574_.m_188503_(16) == 0) {
            BlockPos blockpos = p_278107_.m_7495_();
            if (FallingBlock.m_53241_(p_277525_.m_8055_(blockpos))) {
                double d0 = (double)p_278107_.m_123341_() + p_277574_.m_188500_();
                double d1 = (double)p_278107_.m_123342_() - 0.05;
                double d2 = (double)p_278107_.m_123343_() + p_277574_.m_188500_();
                p_277525_.m_7106_(new BlockParticleOption(ParticleTypes.f_123814_, p_277390_), d0, d1, d2, 0.0, 0.0, 0.0);
            }
        }
    }

    @Nullable
    @Override
    public BlockEntity m_142194_(BlockPos p_277683_, BlockState p_277381_) {
        return new BrushableBlockEntity(p_277683_, p_277381_);
    }

    public Block m_277074_() {
        return this.f_276601_;
    }

    public SoundEvent m_276856_() {
        return this.f_276507_;
    }

    public SoundEvent m_277154_() {
        return this.f_276618_;
    }
}