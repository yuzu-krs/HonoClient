package net.minecraft.world.level.block.entity;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.SeededContainerLoot;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootTable;

public abstract class RandomizableContainerBlockEntity extends BaseContainerBlockEntity implements RandomizableContainer {
    @Nullable
    protected ResourceKey<LootTable> f_59605_;
    protected long f_59606_ = 0L;

    protected RandomizableContainerBlockEntity(BlockEntityType<?> p_155629_, BlockPos p_155630_, BlockState p_155631_) {
        super(p_155629_, p_155630_, p_155631_);
    }

    @Nullable
    @Override
    public ResourceKey<LootTable> m_305426_() {
        return this.f_59605_;
    }

    @Override
    public void m_59626_(@Nullable ResourceKey<LootTable> p_328444_) {
        this.f_59605_ = p_328444_;
    }

    @Override
    public long m_305628_() {
        return this.f_59606_;
    }

    @Override
    public void m_305699_(long p_311658_) {
        this.f_59606_ = p_311658_;
    }

    @Override
    public boolean m_7983_() {
        this.m_306438_(null);
        return super.m_7983_();
    }

    @Override
    public ItemStack m_8020_(int p_59611_) {
        this.m_306438_(null);
        return super.m_8020_(p_59611_);
    }

    @Override
    public ItemStack m_7407_(int p_59613_, int p_59614_) {
        this.m_306438_(null);
        return super.m_7407_(p_59613_, p_59614_);
    }

    @Override
    public ItemStack m_8016_(int p_59630_) {
        this.m_306438_(null);
        return super.m_8016_(p_59630_);
    }

    @Override
    public void m_6836_(int p_59616_, ItemStack p_59617_) {
        this.m_306438_(null);
        super.m_6836_(p_59616_, p_59617_);
    }

    @Override
    public boolean m_7525_(Player p_59643_) {
        return super.m_7525_(p_59643_) && (this.f_59605_ == null || !p_59643_.m_5833_());
    }

    @Nullable
    @Override
    public AbstractContainerMenu m_7208_(int p_59637_, Inventory p_59638_, Player p_59639_) {
        if (this.m_7525_(p_59639_)) {
            this.m_306438_(p_59638_.f_35978_);
            return this.m_6555_(p_59637_, p_59638_);
        } else {
            return null;
        }
    }

    @Override
    protected void m_318741_(BlockEntity.DataComponentInput p_330597_) {
        super.m_318741_(p_330597_);
        SeededContainerLoot seededcontainerloot = p_330597_.m_319293_(DataComponents.f_314304_);
        if (seededcontainerloot != null) {
            this.f_59605_ = seededcontainerloot.f_314778_();
            this.f_59606_ = seededcontainerloot.f_314296_();
        }
    }

    @Override
    protected void m_318837_(DataComponentMap.Builder p_329123_) {
        super.m_318837_(p_329123_);
        if (this.f_59605_ != null) {
            p_329123_.m_322739_(DataComponents.f_314304_, new SeededContainerLoot(this.f_59605_, this.f_59606_));
        }
    }

    @Override
    public void m_318942_(CompoundTag p_331651_) {
        super.m_318942_(p_331651_);
        p_331651_.m_128473_("LootTable");
        p_331651_.m_128473_("LootTableSeed");
    }
}