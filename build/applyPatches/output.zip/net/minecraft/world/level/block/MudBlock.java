package net.minecraft.world.level.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class MudBlock extends Block {
    public static final MapCodec<MudBlock> f_302855_ = m_306223_(MudBlock::new);
    protected static final VoxelShape f_221542_ = Block.m_49796_(0.0, 0.0, 0.0, 16.0, 14.0, 16.0);

    @Override
    public MapCodec<MudBlock> m_304657_() {
        return f_302855_;
    }

    public MudBlock(BlockBehaviour.Properties p_221545_) {
        super(p_221545_);
    }

    @Override
    protected VoxelShape m_5939_(BlockState p_221561_, BlockGetter p_221562_, BlockPos p_221563_, CollisionContext p_221564_) {
        return f_221542_;
    }

    @Override
    protected VoxelShape m_7947_(BlockState p_221566_, BlockGetter p_221567_, BlockPos p_221568_) {
        return Shapes.m_83144_();
    }

    @Override
    protected VoxelShape m_5909_(BlockState p_221556_, BlockGetter p_221557_, BlockPos p_221558_, CollisionContext p_221559_) {
        return Shapes.m_83144_();
    }

    @Override
    protected boolean m_7357_(BlockState p_221547_, PathComputationType p_221550_) {
        return false;
    }

    @Override
    protected float m_7749_(BlockState p_221552_, BlockGetter p_221553_, BlockPos p_221554_) {
        return 0.2F;
    }
}