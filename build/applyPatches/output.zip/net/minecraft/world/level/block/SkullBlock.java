package net.minecraft.world.level.block;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.RotationSegment;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class SkullBlock extends AbstractSkullBlock {
    public static final MapCodec<SkullBlock> f_303836_ = RecordCodecBuilder.mapCodec(
        p_360451_ -> p_360451_.group(SkullBlock.Type.f_302410_.fieldOf("kind").forGetter(AbstractSkullBlock::m_48754_), m_305607_())
                .apply(p_360451_, SkullBlock::new)
    );
    public static final int f_154563_ = RotationSegment.m_247348_();
    private static final int f_154564_ = f_154563_ + 1;
    public static final IntegerProperty f_56314_ = BlockStateProperties.f_61390_;
    protected static final VoxelShape f_56315_ = Block.m_49796_(4.0, 0.0, 4.0, 12.0, 8.0, 12.0);
    protected static final VoxelShape f_260503_ = Block.m_49796_(3.0, 0.0, 3.0, 13.0, 8.0, 13.0);

    @Override
    public MapCodec<? extends SkullBlock> m_304657_() {
        return f_303836_;
    }

    protected SkullBlock(SkullBlock.Type p_56318_, BlockBehaviour.Properties p_56319_) {
        super(p_56318_, p_56319_);
        this.m_49959_(this.m_49966_().m_61124_(f_56314_, Integer.valueOf(0)));
    }

    @Override
    protected VoxelShape m_5940_(BlockState p_56331_, BlockGetter p_56332_, BlockPos p_56333_, CollisionContext p_56334_) {
        return this.m_48754_() == SkullBlock.Types.PIGLIN ? f_260503_ : f_56315_;
    }

    @Override
    protected VoxelShape m_7952_(BlockState p_56336_) {
        return Shapes.m_83040_();
    }

    @Override
    public BlockState m_5573_(BlockPlaceContext p_56321_) {
        return super.m_5573_(p_56321_).m_61124_(f_56314_, Integer.valueOf(RotationSegment.m_246374_(p_56321_.m_7074_())));
    }

    @Override
    protected BlockState m_6843_(BlockState p_56326_, Rotation p_56327_) {
        return p_56326_.m_61124_(f_56314_, Integer.valueOf(p_56327_.m_55949_(p_56326_.m_61143_(f_56314_), f_154564_)));
    }

    @Override
    protected BlockState m_6943_(BlockState p_56323_, Mirror p_56324_) {
        return p_56323_.m_61124_(f_56314_, Integer.valueOf(p_56324_.m_54843_(p_56323_.m_61143_(f_56314_), f_154564_)));
    }

    @Override
    protected void m_7926_(StateDefinition.Builder<Block, BlockState> p_56329_) {
        super.m_7926_(p_56329_);
        p_56329_.m_61104_(f_56314_);
    }

    public interface Type extends StringRepresentable {
        Map<String, SkullBlock.Type> f_303019_ = new Object2ObjectArrayMap<>();
        Codec<SkullBlock.Type> f_302410_ = Codec.stringResolver(StringRepresentable::m_7912_, f_303019_::get);
    }

    public static enum Types implements SkullBlock.Type {
        SKELETON("skeleton"),
        WITHER_SKELETON("wither_skeleton"),
        PLAYER("player"),
        ZOMBIE("zombie"),
        CREEPER("creeper"),
        PIGLIN("piglin"),
        DRAGON("dragon");

        private final String f_303610_;

        private Types(final String p_310892_) {
            this.f_303610_ = p_310892_;
            f_303019_.put(p_310892_, this);
        }

        @Override
        public String m_7912_() {
            return this.f_303610_;
        }
    }
}