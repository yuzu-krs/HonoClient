package net.minecraft.world.level.block.entity;

import net.minecraft.world.Container;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;

public interface Hopper extends Container {
    AABB f_315244_ = Block.m_49796_(0.0, 11.0, 0.0, 16.0, 32.0, 16.0).m_83299_().get(0);

    default AABB m_319170_() {
        return f_315244_;
    }

    double m_6343_();

    double m_6358_();

    double m_6446_();

    boolean m_320496_();
}