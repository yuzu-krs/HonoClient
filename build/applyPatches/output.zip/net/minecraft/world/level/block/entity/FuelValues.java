package net.minecraft.world.level.block.entity;

import it.unimi.dsi.fastutil.objects.Object2IntLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2IntSortedMap;
import java.util.Collections;
import java.util.SequencedSet;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Blocks;

public class FuelValues {
    private final Object2IntSortedMap<Item> f_347950_;

    FuelValues(Object2IntSortedMap<Item> p_367283_) {
        this.f_347950_ = p_367283_;
    }

    public boolean m_354988_(ItemStack p_369912_) {
        return this.f_347950_.containsKey(p_369912_.m_41720_());
    }

    public SequencedSet<Item> m_356845_() {
        return Collections.unmodifiableSequencedSet(this.f_347950_.keySet());
    }

    public int m_354069_(ItemStack p_368393_) {
        return p_368393_.m_41619_() ? 0 : this.f_347950_.getInt(p_368393_.m_41720_());
    }

    public static FuelValues m_353682_(HolderLookup.Provider p_363816_, FeatureFlagSet p_367705_) {
        return m_352590_(p_363816_, p_367705_, 200);
    }

    public static FuelValues m_352590_(HolderLookup.Provider p_370014_, FeatureFlagSet p_364680_, int p_363278_) {
        return new FuelValues.Builder(p_370014_, p_364680_)
            .m_352369_(Items.f_42448_, p_363278_ * 100)
            .m_352369_(Blocks.f_50353_, p_363278_ * 8 * 10)
            .m_352369_(Items.f_42585_, p_363278_ * 12)
            .m_352369_(Items.f_42413_, p_363278_ * 8)
            .m_352369_(Items.f_42414_, p_363278_ * 8)
            .m_354083_(ItemTags.f_13182_, p_363278_ * 3 / 2)
            .m_354083_(ItemTags.f_256904_, p_363278_ * 3 / 2)
            .m_354083_(ItemTags.f_13168_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_244489_, p_363278_ * 3 / 2)
            .m_354083_(ItemTags.f_13174_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_244193_, p_363278_ * 3 / 2)
            .m_354083_(ItemTags.f_13175_, p_363278_ * 3 / 4)
            .m_352369_(Blocks.f_244230_, p_363278_ * 3 / 4)
            .m_354083_(ItemTags.f_13178_, p_363278_ * 3 / 2)
            .m_354083_(ItemTags.f_13177_, p_363278_ * 3 / 2)
            .m_354083_(ItemTags.f_13176_, p_363278_ * 3 / 2)
            .m_354083_(ItemTags.f_254662_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50065_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50078_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_244299_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50624_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50131_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50087_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50325_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50091_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50329_, p_363278_ * 3 / 2)
            .m_354083_(ItemTags.f_13191_, p_363278_ * 3 / 2)
            .m_352369_(Items.f_42411_, p_363278_ * 3 / 2)
            .m_352369_(Items.f_42523_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50155_, p_363278_ * 3 / 2)
            .m_354083_(ItemTags.f_13157_, p_363278_)
            .m_354083_(ItemTags.f_244389_, p_363278_ * 4)
            .m_352369_(Items.f_42421_, p_363278_)
            .m_352369_(Items.f_42420_, p_363278_)
            .m_352369_(Items.f_42424_, p_363278_)
            .m_352369_(Items.f_42423_, p_363278_)
            .m_352369_(Items.f_42422_, p_363278_)
            .m_354083_(ItemTags.f_13173_, p_363278_)
            .m_354083_(ItemTags.f_13155_, p_363278_ * 6)
            .m_354083_(ItemTags.f_13167_, p_363278_ / 2)
            .m_354083_(ItemTags.f_13170_, p_363278_ / 2)
            .m_352369_(Items.f_42398_, p_363278_ / 2)
            .m_354083_(ItemTags.f_13180_, p_363278_ / 2)
            .m_352369_(Items.f_42399_, p_363278_ / 2)
            .m_354083_(ItemTags.f_215867_, 1 + p_363278_ / 3)
            .m_352369_(Blocks.f_50577_, 1 + p_363278_ * 20)
            .m_352369_(Items.f_42717_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50571_, p_363278_ / 4)
            .m_352369_(Blocks.f_50036_, p_363278_ / 2)
            .m_352369_(Blocks.f_50616_, p_363278_ / 4)
            .m_352369_(Blocks.f_50617_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50618_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50621_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50622_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50625_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_50715_, p_363278_ * 3 / 2)
            .m_352369_(Blocks.f_152541_, p_363278_ / 2)
            .m_352369_(Blocks.f_152542_, p_363278_ / 2)
            .m_352369_(Blocks.f_220833_, p_363278_ * 3 / 2)
            .m_353375_(ItemTags.f_13153_)
            .m_356255_();
    }

    public static class Builder {
        private final HolderLookup<Item> f_348725_;
        private final FeatureFlagSet f_348879_;
        private final Object2IntSortedMap<Item> f_349400_ = new Object2IntLinkedOpenHashMap<>();

        public Builder(HolderLookup.Provider p_369440_, FeatureFlagSet p_369101_) {
            this.f_348725_ = p_369440_.m_254974_(Registries.f_256913_);
            this.f_348879_ = p_369101_;
        }

        public FuelValues m_356255_() {
            return new FuelValues(this.f_349400_);
        }

        public FuelValues.Builder m_353375_(TagKey<Item> p_369702_) {
            this.f_349400_.keySet().removeIf(p_361506_ -> p_361506_.m_204114_().m_203656_(p_369702_));
            return this;
        }

        public FuelValues.Builder m_354083_(TagKey<Item> p_367371_, int p_368360_) {
            this.f_348725_.m_255050_(p_367371_).ifPresent(p_361860_ -> {
                for (Holder<Item> holder : p_361860_) {
                    this.m_356160_(p_368360_, holder.m_203334_());
                }
            });
            return this;
        }

        public FuelValues.Builder m_352369_(ItemLike p_365111_, int p_364289_) {
            Item item = p_365111_.m_5456_();
            this.m_356160_(p_364289_, item);
            return this;
        }

        private void m_356160_(int p_361402_, Item p_366165_) {
            if (p_366165_.m_245993_(this.f_348879_)) {
                this.f_349400_.put(p_366165_, p_361402_);
            }
        }
    }
}