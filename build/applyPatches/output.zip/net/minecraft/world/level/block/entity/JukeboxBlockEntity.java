package net.minecraft.world.level.block.entity;

import com.google.common.annotations.VisibleForTesting;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.Container;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.JukeboxSong;
import net.minecraft.world.item.JukeboxSongPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.JukeboxBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.ticks.ContainerSingleItem;

public class JukeboxBlockEntity extends BlockEntity implements ContainerSingleItem.BlockContainerSingleItem {
    public static final String f_337261_ = "RecordItem";
    public static final String f_336741_ = "ticks_since_song_started";
    private ItemStack f_303331_ = ItemStack.f_41583_;
    private final JukeboxSongPlayer f_337052_ = new JukeboxSongPlayer(this::m_338418_, this.m_58899_());

    public JukeboxBlockEntity(BlockPos p_155613_, BlockState p_155614_) {
        super(BlockEntityType.f_58921_, p_155613_, p_155614_);
    }

    public JukeboxSongPlayer m_338555_() {
        return this.f_337052_;
    }

    public void m_338418_() {
        this.f_58857_.m_46672_(this.m_58899_(), this.m_58900_().m_60734_());
        this.m_6596_();
    }

    private void m_269320_(boolean p_342785_) {
        if (this.f_58857_ != null && this.f_58857_.m_8055_(this.m_58899_()) == this.m_58900_()) {
            this.f_58857_.m_7731_(this.m_58899_(), this.m_58900_().m_61124_(JukeboxBlock.f_54254_, Boolean.valueOf(p_342785_)), 2);
            this.f_58857_.m_322719_(GameEvent.f_157792_, this.m_58899_(), GameEvent.Context.m_223722_(this.m_58900_()));
        }
    }

    public void m_272252_() {
        if (this.f_58857_ != null && !this.f_58857_.f_46443_) {
            BlockPos blockpos = this.m_58899_();
            ItemStack itemstack = this.m_306082_();
            if (!itemstack.m_41619_()) {
                this.m_306595_();
                Vec3 vec3 = Vec3.m_272021_(blockpos, 0.5, 1.01, 0.5).m_272010_(this.f_58857_.f_46441_, 0.7F);
                ItemStack itemstack1 = itemstack.m_41777_();
                ItemEntity itementity = new ItemEntity(this.f_58857_, vec3.m_7096_(), vec3.m_7098_(), vec3.m_7094_(), itemstack1);
                itementity.m_32060_();
                this.f_58857_.m_7967_(itementity);
            }
        }
    }

    public static void m_272276_(Level p_273615_, BlockPos p_273143_, BlockState p_273372_, JukeboxBlockEntity p_343932_) {
        p_343932_.f_337052_.m_339352_(p_273615_, p_273372_);
    }

    public int m_340269_() {
        return JukeboxSong.m_340276_(this.f_58857_.m_9598_(), this.f_303331_).map(Holder::m_203334_).map(JukeboxSong::f_337038_).orElse(0);
    }

    @Override
    protected void m_318667_(CompoundTag p_329712_, HolderLookup.Provider p_330255_) {
        super.m_318667_(p_329712_, p_330255_);
        if (p_329712_.m_128425_("RecordItem", 10)) {
            this.f_303331_ = ItemStack.m_323951_(p_330255_, p_329712_.m_128469_("RecordItem")).orElse(ItemStack.f_41583_);
        } else {
            this.f_303331_ = ItemStack.f_41583_;
        }

        if (p_329712_.m_128425_("ticks_since_song_started", 4)) {
            JukeboxSong.m_340276_(p_330255_, this.f_303331_)
                .ifPresent(p_342562_ -> this.f_337052_.m_339068_((Holder<JukeboxSong>)p_342562_, p_329712_.m_128454_("ticks_since_song_started")));
        }
    }

    @Override
    protected void m_183515_(CompoundTag p_187507_, HolderLookup.Provider p_332390_) {
        super.m_183515_(p_187507_, p_332390_);
        if (!this.m_306082_().m_41619_()) {
            p_187507_.m_128365_("RecordItem", this.m_306082_().m_41739_(p_332390_));
        }

        if (this.f_337052_.m_339544_() != null) {
            p_187507_.m_128356_("ticks_since_song_started", this.f_337052_.m_338357_());
        }
    }

    @Override
    public ItemStack m_306082_() {
        return this.f_303331_;
    }

    @Override
    public ItemStack m_305214_(int p_309876_) {
        ItemStack itemstack = this.f_303331_;
        this.m_305072_(ItemStack.f_41583_);
        return itemstack;
    }

    @Override
    public void m_305072_(ItemStack p_309430_) {
        this.f_303331_ = p_309430_;
        boolean flag = !this.f_303331_.m_41619_();
        Optional<Holder<JukeboxSong>> optional = JukeboxSong.m_340276_(this.f_58857_.m_9598_(), this.f_303331_);
        this.m_269320_(flag);
        if (flag && optional.isPresent()) {
            this.f_337052_.m_340018_(this.f_58857_, optional.get());
        } else {
            this.f_337052_.m_339700_(this.f_58857_, this.m_58900_());
        }
    }

    @Override
    public int m_6893_() {
        return 1;
    }

    @Override
    public BlockEntity m_304707_() {
        return this;
    }

    @Override
    public boolean m_7013_(int p_273369_, ItemStack p_273689_) {
        return p_273689_.m_319951_(DataComponents.f_336668_) && this.m_8020_(p_273369_).m_41619_();
    }

    @Override
    public boolean m_271862_(Container p_273497_, int p_273168_, ItemStack p_273785_) {
        return p_273497_.m_216874_(ItemStack::m_41619_);
    }

    @VisibleForTesting
    public void m_339691_(ItemStack p_343692_) {
        this.f_303331_ = p_343692_;
        JukeboxSong.m_340276_(this.f_58857_.m_9598_(), p_343692_).ifPresent(p_343857_ -> this.f_337052_.m_339068_((Holder<JukeboxSong>)p_343857_, 0L));
        this.f_58857_.m_46672_(this.m_58899_(), this.m_58900_().m_60734_());
        this.m_6596_();
    }

    @VisibleForTesting
    public void m_340133_() {
        JukeboxSong.m_340276_(this.f_58857_.m_9598_(), this.m_306082_())
            .ifPresent(p_343793_ -> this.f_337052_.m_340018_(this.f_58857_, (Holder<JukeboxSong>)p_343793_));
    }
}