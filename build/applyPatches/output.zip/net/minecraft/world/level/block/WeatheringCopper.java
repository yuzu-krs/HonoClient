package net.minecraft.world.level.block;

import com.google.common.base.Suppliers;
import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.mojang.serialization.Codec;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.block.state.BlockState;

public interface WeatheringCopper extends ChangeOverTimeBlock<WeatheringCopper.WeatherState> {
    Supplier<BiMap<Block, Block>> f_154886_ = Suppliers.memoize(
        () -> ImmutableBiMap.<Block, Block>builder()
                .put(Blocks.f_152504_, Blocks.f_152503_)
                .put(Blocks.f_152503_, Blocks.f_152502_)
                .put(Blocks.f_152502_, Blocks.f_152501_)
                .put(Blocks.f_152510_, Blocks.f_152509_)
                .put(Blocks.f_152509_, Blocks.f_152508_)
                .put(Blocks.f_152508_, Blocks.f_152507_)
                .put(Blocks.f_302689_, Blocks.f_303448_)
                .put(Blocks.f_303448_, Blocks.f_302507_)
                .put(Blocks.f_302507_, Blocks.f_303811_)
                .put(Blocks.f_152570_, Blocks.f_152569_)
                .put(Blocks.f_152569_, Blocks.f_152568_)
                .put(Blocks.f_152568_, Blocks.f_152567_)
                .put(Blocks.f_152566_, Blocks.f_152565_)
                .put(Blocks.f_152565_, Blocks.f_152564_)
                .put(Blocks.f_152564_, Blocks.f_152563_)
                .put(Blocks.f_302565_, Blocks.f_303201_)
                .put(Blocks.f_303201_, Blocks.f_303010_)
                .put(Blocks.f_303010_, Blocks.f_303016_)
                .put(Blocks.f_303635_, Blocks.f_303609_)
                .put(Blocks.f_303609_, Blocks.f_302627_)
                .put(Blocks.f_302627_, Blocks.f_302247_)
                .put(Blocks.f_303215_, Blocks.f_302995_)
                .put(Blocks.f_302995_, Blocks.f_303236_)
                .put(Blocks.f_303236_, Blocks.f_303549_)
                .put(Blocks.f_302358_, Blocks.f_303271_)
                .put(Blocks.f_303271_, Blocks.f_303674_)
                .put(Blocks.f_303674_, Blocks.f_302668_)
                .build()
    );
    Supplier<BiMap<Block, Block>> f_154887_ = Suppliers.memoize(() -> f_154886_.get().inverse());

    static Optional<Block> m_154890_(Block p_154891_) {
        return Optional.ofNullable(f_154887_.get().get(p_154891_));
    }

    static Block m_154897_(Block p_154898_) {
        Block block = p_154898_;

        for (Block block1 = f_154887_.get().get(p_154898_); block1 != null; block1 = f_154887_.get().get(block1)) {
            block = block1;
        }

        return block;
    }

    static Optional<BlockState> m_154899_(BlockState p_154900_) {
        return m_154890_(p_154900_.m_60734_()).map(p_154903_ -> p_154903_.m_152465_(p_154900_));
    }

    static Optional<Block> m_154904_(Block p_154905_) {
        return Optional.ofNullable(f_154886_.get().get(p_154905_));
    }

    static BlockState m_154906_(BlockState p_154907_) {
        return m_154897_(p_154907_.m_60734_()).m_152465_(p_154907_);
    }

    @Override
    default Optional<BlockState> m_142123_(BlockState p_154893_) {
        return m_154904_(p_154893_.m_60734_()).map(p_154896_ -> p_154896_.m_152465_(p_154893_));
    }

    @Override
    default float m_142377_() {
        return this.m_142297_() == WeatheringCopper.WeatherState.UNAFFECTED ? 0.75F : 1.0F;
    }

    public static enum WeatherState implements StringRepresentable {
        UNAFFECTED("unaffected"),
        EXPOSED("exposed"),
        WEATHERED("weathered"),
        OXIDIZED("oxidized");

        public static final Codec<WeatheringCopper.WeatherState> f_302372_ = StringRepresentable.m_216439_(WeatheringCopper.WeatherState::values);
        private final String f_303684_;

        private WeatherState(final String p_309663_) {
            this.f_303684_ = p_309663_;
        }

        @Override
        public String m_7912_() {
            return this.f_303684_;
        }
    }
}