package net.minecraft.world.level.storage.loot.functions;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.List;
import java.util.Set;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.level.storage.loot.providers.number.NumberProvider;
import net.minecraft.world.level.storage.loot.providers.number.NumberProviders;

public class SetItemCountFunction extends LootItemConditionalFunction {
    public static final MapCodec<SetItemCountFunction> f_290727_ = RecordCodecBuilder.mapCodec(
        p_297145_ -> m_294820_(p_297145_)
                .and(
                    p_297145_.group(
                        NumberProviders.f_291751_.fieldOf("count").forGetter(p_297138_ -> p_297138_.f_80997_),
                        Codec.BOOL.fieldOf("add").orElse(false).forGetter(p_297139_ -> p_297139_.f_165407_)
                    )
                )
                .apply(p_297145_, SetItemCountFunction::new)
    );
    private final NumberProvider f_80997_;
    private final boolean f_165407_;

    private SetItemCountFunction(List<LootItemCondition> p_298181_, NumberProvider p_165410_, boolean p_165411_) {
        super(p_298181_);
        this.f_80997_ = p_165410_;
        this.f_165407_ = p_165411_;
    }

    @Override
    public LootItemFunctionType<SetItemCountFunction> m_7162_() {
        return LootItemFunctions.f_80736_;
    }

    @Override
    public Set<ContextKey<?>> m_6231_() {
        return this.f_80997_.m_6231_();
    }

    @Override
    public ItemStack m_7372_(ItemStack p_81006_, LootContext p_81007_) {
        int i = this.f_165407_ ? p_81006_.m_41613_() : 0;
        p_81006_.m_41764_(i + this.f_80997_.m_142683_(p_81007_));
        return p_81006_;
    }

    public static LootItemConditionalFunction.Builder<?> m_165412_(NumberProvider p_165413_) {
        return m_80683_(p_297144_ -> new SetItemCountFunction(p_297144_, p_165413_, false));
    }

    public static LootItemConditionalFunction.Builder<?> m_165414_(NumberProvider p_165415_, boolean p_165416_) {
        return m_80683_(p_297142_ -> new SetItemCountFunction(p_297142_, p_165415_, p_165416_));
    }
}