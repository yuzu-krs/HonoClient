package net.minecraft.world.level.storage.loot.predicates;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.level.storage.loot.providers.number.NumberProvider;
import net.minecraft.world.level.storage.loot.providers.number.NumberProviders;

public record LootItemRandomChanceCondition(NumberProvider f_337409_) implements LootItemCondition {
    public static final MapCodec<LootItemRandomChanceCondition> f_290849_ = RecordCodecBuilder.mapCodec(
        p_342030_ -> p_342030_.group(NumberProviders.f_291751_.fieldOf("chance").forGetter(LootItemRandomChanceCondition::f_337409_))
                .apply(p_342030_, LootItemRandomChanceCondition::new)
    );

    @Override
    public LootItemConditionType m_7940_() {
        return LootItemConditions.f_81813_;
    }

    public boolean test(LootContext p_81930_) {
        float f = this.f_337409_.m_142688_(p_81930_);
        return p_81930_.m_230907_().m_188501_() < f;
    }

    public static LootItemCondition.Builder m_81927_(float p_81928_) {
        return () -> new LootItemRandomChanceCondition(ConstantValue.m_165692_(p_81928_));
    }

    public static LootItemCondition.Builder m_340206_(NumberProvider p_344007_) {
        return () -> new LootItemRandomChanceCondition(p_344007_);
    }
}