package net.minecraft.world.level.storage.loot.providers.score;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.scores.ScoreHolder;

public record ContextScoreboardNameProvider(LootContext.EntityTarget f_165803_) implements ScoreboardNameProvider {
    public static final MapCodec<ContextScoreboardNameProvider> f_290593_ = RecordCodecBuilder.mapCodec(
        p_297529_ -> p_297529_.group(LootContext.EntityTarget.f_291271_.fieldOf("target").forGetter(ContextScoreboardNameProvider::f_165803_))
                .apply(p_297529_, ContextScoreboardNameProvider::new)
    );
    public static final Codec<ContextScoreboardNameProvider> f_291014_ = LootContext.EntityTarget.f_291271_
        .xmap(ContextScoreboardNameProvider::new, ContextScoreboardNameProvider::f_165803_);

    public static ScoreboardNameProvider m_165807_(LootContext.EntityTarget p_165808_) {
        return new ContextScoreboardNameProvider(p_165808_);
    }

    @Override
    public LootScoreProviderType m_142680_() {
        return ScoreboardNameProviders.f_165869_;
    }

    @Nullable
    @Override
    public ScoreHolder m_142600_(LootContext p_312221_) {
        return p_312221_.m_352997_(this.f_165803_.m_79003_());
    }

    @Override
    public Set<ContextKey<?>> m_142636_() {
        return Set.of(this.f_165803_.m_79003_());
    }
}