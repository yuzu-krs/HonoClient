package net.minecraft.world.level.storage.loot.predicates;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.core.Holder;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;

public record BonusLevelTableCondition(Holder<Enchantment> f_81507_, List<Float> f_81508_) implements LootItemCondition {
    public static final MapCodec<BonusLevelTableCondition> f_291274_ = RecordCodecBuilder.mapCodec(
        p_342021_ -> p_342021_.group(
                    Enchantment.f_337121_.fieldOf("enchantment").forGetter(BonusLevelTableCondition::f_81507_),
                    ExtraCodecs.m_144637_(Codec.FLOAT.listOf()).fieldOf("chances").forGetter(BonusLevelTableCondition::f_81508_)
                )
                .apply(p_342021_, BonusLevelTableCondition::new)
    );

    @Override
    public LootItemConditionType m_7940_() {
        return LootItemConditions.f_81820_;
    }

    @Override
    public Set<ContextKey<?>> m_6231_() {
        return Set.of(LootContextParams.f_81463_);
    }

    public boolean test(LootContext p_81521_) {
        ItemStack itemstack = p_81521_.m_352997_(LootContextParams.f_81463_);
        int i = itemstack != null ? EnchantmentHelper.m_44843_(this.f_81507_, itemstack) : 0;
        float f = this.f_81508_.get(Math.min(i, this.f_81508_.size() - 1));
        return p_81521_.m_230907_().m_188501_() < f;
    }

    public static LootItemCondition.Builder m_81517_(Holder<Enchantment> p_342391_, float... p_81519_) {
        List<Float> list = new ArrayList<>(p_81519_.length);

        for (float f : p_81519_) {
            list.add(f);
        }

        return () -> new BonusLevelTableCondition(p_342391_, list);
    }
}