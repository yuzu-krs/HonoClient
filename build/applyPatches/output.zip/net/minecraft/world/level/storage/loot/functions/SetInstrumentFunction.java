package net.minecraft.world.level.storage.loot.functions;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Instrument;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;

public class SetInstrumentFunction extends LootItemConditionalFunction {
    public static final MapCodec<SetInstrumentFunction> f_290736_ = RecordCodecBuilder.mapCodec(
        p_297135_ -> m_294820_(p_297135_)
                .and(TagKey.m_203886_(Registries.f_257010_).fieldOf("options").forGetter(p_297134_ -> p_297134_.f_231006_))
                .apply(p_297135_, SetInstrumentFunction::new)
    );
    private final TagKey<Instrument> f_231006_;

    private SetInstrumentFunction(List<LootItemCondition> p_297631_, TagKey<Instrument> p_231009_) {
        super(p_297631_);
        this.f_231006_ = p_231009_;
    }

    @Override
    public LootItemFunctionType<SetInstrumentFunction> m_7162_() {
        return LootItemFunctions.f_230994_;
    }

    @Override
    public ItemStack m_7372_(ItemStack p_231017_, LootContext p_231018_) {
        Registry<Instrument> registry = p_231018_.m_78952_().m_9598_().m_254974_(Registries.f_257010_);
        Optional<Holder<Instrument>> optional = registry.m_321004_(this.f_231006_, p_231018_.m_230907_());
        if (optional.isPresent()) {
            p_231017_.m_322496_(DataComponents.f_316614_, optional.get());
        }

        return p_231017_;
    }

    public static LootItemConditionalFunction.Builder<?> m_231011_(TagKey<Instrument> p_231012_) {
        return m_80683_(p_297137_ -> new SetInstrumentFunction(p_297137_, p_231012_));
    }
}