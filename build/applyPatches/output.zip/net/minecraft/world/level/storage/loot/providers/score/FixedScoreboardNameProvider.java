package net.minecraft.world.level.storage.loot.providers.score;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.Set;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.scores.ScoreHolder;

public record FixedScoreboardNameProvider(String f_165840_) implements ScoreboardNameProvider {
    public static final MapCodec<FixedScoreboardNameProvider> f_290562_ = RecordCodecBuilder.mapCodec(
        p_300953_ -> p_300953_.group(Codec.STRING.fieldOf("name").forGetter(FixedScoreboardNameProvider::f_165840_))
                .apply(p_300953_, FixedScoreboardNameProvider::new)
    );

    public static ScoreboardNameProvider m_165846_(String p_165847_) {
        return new FixedScoreboardNameProvider(p_165847_);
    }

    @Override
    public LootScoreProviderType m_142680_() {
        return ScoreboardNameProviders.f_165868_;
    }

    @Override
    public ScoreHolder m_142600_(LootContext p_309765_) {
        return ScoreHolder.m_306660_(this.f_165840_);
    }

    @Override
    public Set<ContextKey<?>> m_142636_() {
        return Set.of();
    }
}