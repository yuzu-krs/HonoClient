package net.minecraft.world.level.storage.loot.functions;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.Util;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.HolderSet;
import net.minecraft.core.RegistryCodecs;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.EnchantmentTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import org.slf4j.Logger;

public class EnchantRandomlyFunction extends LootItemConditionalFunction {
    private static final Logger f_80414_ = LogUtils.getLogger();
    public static final MapCodec<EnchantRandomlyFunction> f_291046_ = RecordCodecBuilder.mapCodec(
        p_341996_ -> m_294820_(p_341996_)
                .and(
                    p_341996_.group(
                        RegistryCodecs.m_206277_(Registries.f_256762_).optionalFieldOf("options").forGetter(p_341991_ -> p_341991_.f_336941_),
                        Codec.BOOL.optionalFieldOf("only_compatible", Boolean.valueOf(true)).forGetter(p_341992_ -> p_341992_.f_336641_)
                    )
                )
                .apply(p_341996_, EnchantRandomlyFunction::new)
    );
    private final Optional<HolderSet<Enchantment>> f_336941_;
    private final boolean f_336641_;

    EnchantRandomlyFunction(List<LootItemCondition> p_298352_, Optional<HolderSet<Enchantment>> p_297532_, boolean p_344714_) {
        super(p_298352_);
        this.f_336941_ = p_297532_;
        this.f_336641_ = p_344714_;
    }

    @Override
    public LootItemFunctionType<EnchantRandomlyFunction> m_7162_() {
        return LootItemFunctions.f_80738_;
    }

    @Override
    public ItemStack m_7372_(ItemStack p_80429_, LootContext p_80430_) {
        RandomSource randomsource = p_80430_.m_230907_();
        boolean flag = p_80429_.m_150930_(Items.f_42517_);
        boolean flag1 = !flag && this.f_336641_;
        Stream<Holder<Enchantment>> stream = this.f_336941_
            .map(HolderSet::m_203614_)
            .orElseGet(() -> p_80430_.m_78952_().m_9598_().m_254974_(Registries.f_256762_).m_205916_().map(Function.identity()))
            .filter(p_341995_ -> !flag1 || p_341995_.m_203334_().m_6081_(p_80429_));
        List<Holder<Enchantment>> list = stream.toList();
        Optional<Holder<Enchantment>> optional = Util.m_214676_(list, randomsource);
        if (optional.isEmpty()) {
            f_80414_.warn("Couldn't find a compatible enchantment for {}", p_80429_);
            return p_80429_;
        } else {
            return m_230979_(p_80429_, optional.get(), randomsource);
        }
    }

    private static ItemStack m_230979_(ItemStack p_230980_, Holder<Enchantment> p_343939_, RandomSource p_230982_) {
        int i = Mth.m_216271_(p_230982_, p_343939_.m_203334_().m_44702_(), p_343939_.m_203334_().m_6586_());
        if (p_230980_.m_150930_(Items.f_42517_)) {
            p_230980_ = new ItemStack(Items.f_42690_);
        }

        p_230980_.m_41663_(p_343939_, i);
        return p_230980_;
    }

    public static EnchantRandomlyFunction.Builder m_165191_() {
        return new EnchantRandomlyFunction.Builder();
    }

    public static EnchantRandomlyFunction.Builder m_80440_(HolderLookup.Provider p_343847_) {
        return m_165191_().m_338501_(p_343847_.m_254974_(Registries.f_256762_).m_254956_(EnchantmentTags.f_337721_));
    }

    public static class Builder extends LootItemConditionalFunction.Builder<EnchantRandomlyFunction.Builder> {
        private Optional<HolderSet<Enchantment>> f_337221_ = Optional.empty();
        private boolean f_337327_ = true;

        protected EnchantRandomlyFunction.Builder m_6477_() {
            return this;
        }

        public EnchantRandomlyFunction.Builder m_80444_(Holder<Enchantment> p_342993_) {
            this.f_337221_ = Optional.of(HolderSet.m_205809_(p_342993_));
            return this;
        }

        public EnchantRandomlyFunction.Builder m_338501_(HolderSet<Enchantment> p_344102_) {
            this.f_337221_ = Optional.of(p_344102_);
            return this;
        }

        public EnchantRandomlyFunction.Builder m_338955_() {
            this.f_337327_ = false;
            return this;
        }

        @Override
        public LootItemFunction m_7453_() {
            return new EnchantRandomlyFunction(this.m_80699_(), this.f_337221_, this.f_337327_);
        }
    }
}