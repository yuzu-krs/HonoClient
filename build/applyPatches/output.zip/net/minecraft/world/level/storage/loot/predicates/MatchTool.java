package net.minecraft.world.level.storage.loot.predicates;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.Optional;
import java.util.Set;
import net.minecraft.advancements.critereon.ItemPredicate;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;

public record MatchTool(Optional<ItemPredicate> f_81993_) implements LootItemCondition {
    public static final MapCodec<MatchTool> f_290941_ = RecordCodecBuilder.mapCodec(
        p_327654_ -> p_327654_.group(ItemPredicate.f_291722_.optionalFieldOf("predicate").forGetter(MatchTool::f_81993_)).apply(p_327654_, MatchTool::new)
    );

    @Override
    public LootItemConditionType m_7940_() {
        return LootItemConditions.f_81819_;
    }

    @Override
    public Set<ContextKey<?>> m_6231_() {
        return Set.of(LootContextParams.f_81463_);
    }

    public boolean test(LootContext p_82000_) {
        ItemStack itemstack = p_82000_.m_352997_(LootContextParams.f_81463_);
        return itemstack != null && (this.f_81993_.isEmpty() || this.f_81993_.get().test(itemstack));
    }

    public static LootItemCondition.Builder m_81997_(ItemPredicate.Builder p_81998_) {
        return () -> new MatchTool(Optional.of(p_81998_.m_45077_()));
    }
}