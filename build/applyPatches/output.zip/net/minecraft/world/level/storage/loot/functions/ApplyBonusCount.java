package net.minecraft.world.level.storage.loot.functions;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.util.RandomSource;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;

public class ApplyBonusCount extends LootItemConditionalFunction {
    private static final Map<ResourceLocation, ApplyBonusCount.FormulaType> f_79898_ = Stream.of(
            ApplyBonusCount.BinomialWithBonusCount.f_79947_, ApplyBonusCount.OreDrops.f_79973_, ApplyBonusCount.UniformBonusCount.f_80012_
        )
        .collect(Collectors.toMap(ApplyBonusCount.FormulaType::f_291058_, Function.identity()));
    private static final Codec<ApplyBonusCount.FormulaType> f_291576_ = ResourceLocation.f_135803_
        .comapFlatMap(
            p_297073_ -> {
                ApplyBonusCount.FormulaType applybonuscount$formulatype = f_79898_.get(p_297073_);
                return applybonuscount$formulatype != null
                    ? DataResult.success(applybonuscount$formulatype)
                    : DataResult.error(() -> "No formula type with id: '" + p_297073_ + "'");
            },
            ApplyBonusCount.FormulaType::f_291058_
        );
    private static final MapCodec<ApplyBonusCount.Formula> f_290648_ = ExtraCodecs.m_306181_(
        "formula", "parameters", f_291576_, ApplyBonusCount.Formula::m_5713_, ApplyBonusCount.FormulaType::f_291691_
    );
    public static final MapCodec<ApplyBonusCount> f_291250_ = RecordCodecBuilder.mapCodec(
        p_341977_ -> m_294820_(p_341977_)
                .and(
                    p_341977_.group(
                        Enchantment.f_337121_.fieldOf("enchantment").forGetter(p_297072_ -> p_297072_.f_79899_),
                        f_290648_.forGetter(p_297058_ -> p_297058_.f_79900_)
                    )
                )
                .apply(p_341977_, ApplyBonusCount::new)
    );
    private final Holder<Enchantment> f_79899_;
    private final ApplyBonusCount.Formula f_79900_;

    private ApplyBonusCount(List<LootItemCondition> p_298095_, Holder<Enchantment> p_298508_, ApplyBonusCount.Formula p_79905_) {
        super(p_298095_);
        this.f_79899_ = p_298508_;
        this.f_79900_ = p_79905_;
    }

    @Override
    public LootItemFunctionType<ApplyBonusCount> m_7162_() {
        return LootItemFunctions.f_80750_;
    }

    @Override
    public Set<ContextKey<?>> m_6231_() {
        return Set.of(LootContextParams.f_81463_);
    }

    @Override
    public ItemStack m_7372_(ItemStack p_79913_, LootContext p_79914_) {
        ItemStack itemstack = p_79914_.m_352997_(LootContextParams.f_81463_);
        if (itemstack != null) {
            int i = EnchantmentHelper.m_44843_(this.f_79899_, itemstack);
            int j = this.f_79900_.m_213779_(p_79914_.m_230907_(), p_79913_.m_41613_(), i);
            p_79913_.m_41764_(j);
        }

        return p_79913_;
    }

    public static LootItemConditionalFunction.Builder<?> m_79917_(Holder<Enchantment> p_345010_, float p_79919_, int p_79920_) {
        return m_80683_(p_341983_ -> new ApplyBonusCount(p_341983_, p_345010_, new ApplyBonusCount.BinomialWithBonusCount(p_79920_, p_79919_)));
    }

    public static LootItemConditionalFunction.Builder<?> m_79915_(Holder<Enchantment> p_344898_) {
        return m_80683_(p_341979_ -> new ApplyBonusCount(p_341979_, p_344898_, new ApplyBonusCount.OreDrops()));
    }

    public static LootItemConditionalFunction.Builder<?> m_79939_(Holder<Enchantment> p_344489_) {
        return m_80683_(p_341988_ -> new ApplyBonusCount(p_341988_, p_344489_, new ApplyBonusCount.UniformBonusCount(1)));
    }

    public static LootItemConditionalFunction.Builder<?> m_79921_(Holder<Enchantment> p_344963_, int p_79923_) {
        return m_80683_(p_341986_ -> new ApplyBonusCount(p_341986_, p_344963_, new ApplyBonusCount.UniformBonusCount(p_79923_)));
    }

    static record BinomialWithBonusCount(int f_79948_, float f_79949_) implements ApplyBonusCount.Formula {
        private static final Codec<ApplyBonusCount.BinomialWithBonusCount> f_290700_ = RecordCodecBuilder.create(
            p_299643_ -> p_299643_.group(
                        Codec.INT.fieldOf("extra").forGetter(ApplyBonusCount.BinomialWithBonusCount::f_79948_),
                        Codec.FLOAT.fieldOf("probability").forGetter(ApplyBonusCount.BinomialWithBonusCount::f_79949_)
                    )
                    .apply(p_299643_, ApplyBonusCount.BinomialWithBonusCount::new)
        );
        public static final ApplyBonusCount.FormulaType f_79947_ = new ApplyBonusCount.FormulaType(
            ResourceLocation.m_340282_("binomial_with_bonus_count"), f_290700_
        );

        @Override
        public int m_213779_(RandomSource p_230965_, int p_230966_, int p_230967_) {
            for (int i = 0; i < p_230967_ + this.f_79948_; i++) {
                if (p_230965_.m_188501_() < this.f_79949_) {
                    p_230966_++;
                }
            }

            return p_230966_;
        }

        @Override
        public ApplyBonusCount.FormulaType m_5713_() {
            return f_79947_;
        }
    }

    interface Formula {
        int m_213779_(RandomSource p_230968_, int p_230969_, int p_230970_);

        ApplyBonusCount.FormulaType m_5713_();
    }

    static record FormulaType(ResourceLocation f_291058_, Codec<? extends ApplyBonusCount.Formula> f_291691_) {
    }

    static record OreDrops() implements ApplyBonusCount.Formula {
        public static final Codec<ApplyBonusCount.OreDrops> f_291282_ = Codec.unit(ApplyBonusCount.OreDrops::new);
        public static final ApplyBonusCount.FormulaType f_79973_ = new ApplyBonusCount.FormulaType(ResourceLocation.m_340282_("ore_drops"), f_291282_);

        @Override
        public int m_213779_(RandomSource p_230972_, int p_230973_, int p_230974_) {
            if (p_230974_ > 0) {
                int i = p_230972_.m_188503_(p_230974_ + 2) - 1;
                if (i < 0) {
                    i = 0;
                }

                return p_230973_ * (i + 1);
            } else {
                return p_230973_;
            }
        }

        @Override
        public ApplyBonusCount.FormulaType m_5713_() {
            return f_79973_;
        }
    }

    static record UniformBonusCount(int f_80013_) implements ApplyBonusCount.Formula {
        public static final Codec<ApplyBonusCount.UniformBonusCount> f_290477_ = RecordCodecBuilder.create(
            p_297464_ -> p_297464_.group(Codec.INT.fieldOf("bonusMultiplier").forGetter(ApplyBonusCount.UniformBonusCount::f_80013_))
                    .apply(p_297464_, ApplyBonusCount.UniformBonusCount::new)
        );
        public static final ApplyBonusCount.FormulaType f_80012_ = new ApplyBonusCount.FormulaType(ResourceLocation.m_340282_("uniform_bonus_count"), f_290477_);

        @Override
        public int m_213779_(RandomSource p_230976_, int p_230977_, int p_230978_) {
            return p_230977_ + p_230976_.m_188503_(this.f_80013_ * p_230978_ + 1);
        }

        @Override
        public ApplyBonusCount.FormulaType m_5713_() {
            return f_80012_;
        }
    }
}