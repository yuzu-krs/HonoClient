package net.minecraft.world.level.storage.loot.providers.nbt;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;

public class NbtProviders {
    private static final Codec<NbtProvider> f_290422_ = BuiltInRegistries.f_256736_
        .m_194605_()
        .dispatch(NbtProvider::m_142624_, LootNbtProviderType::f_290507_);
    public static final Codec<NbtProvider> f_290907_ = Codec.lazyInitialized(
        () -> Codec.either(ContextNbtProvider.f_290817_, f_290422_)
                .xmap(
                    Either::unwrap,
                    p_298663_ -> p_298663_ instanceof ContextNbtProvider contextnbtprovider ? Either.left(contextnbtprovider) : Either.right(p_298663_)
                )
    );
    public static final LootNbtProviderType f_165623_ = m_165628_("storage", StorageNbtProvider.f_290459_);
    public static final LootNbtProviderType f_165624_ = m_165628_("context", ContextNbtProvider.f_291532_);

    private static LootNbtProviderType m_165628_(String p_165629_, MapCodec<? extends NbtProvider> p_335713_) {
        return Registry.m_122965_(BuiltInRegistries.f_256736_, ResourceLocation.m_340282_(p_165629_), new LootNbtProviderType(p_335713_));
    }
}