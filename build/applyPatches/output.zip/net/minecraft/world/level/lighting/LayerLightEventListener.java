package net.minecraft.world.level.lighting;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.DataLayer;

public interface LayerLightEventListener extends LightEventListener {
    @Nullable
    DataLayer m_8079_(SectionPos p_75709_);

    int m_7768_(BlockPos p_75710_);

    public static enum DummyLightLayerEventListener implements LayerLightEventListener {
        INSTANCE;

        @Nullable
        @Override
        public DataLayer m_8079_(SectionPos p_75718_) {
            return null;
        }

        @Override
        public int m_7768_(BlockPos p_75723_) {
            return 0;
        }

        @Override
        public void m_7174_(BlockPos p_164434_) {
        }

        @Override
        public boolean m_75808_() {
            return false;
        }

        @Override
        public int m_9323_() {
            return 0;
        }

        @Override
        public void m_6191_(SectionPos p_75720_, boolean p_75721_) {
        }

        @Override
        public void m_9335_(ChunkPos p_164431_, boolean p_164432_) {
        }

        @Override
        public void m_142519_(ChunkPos p_285209_) {
        }
    }
}