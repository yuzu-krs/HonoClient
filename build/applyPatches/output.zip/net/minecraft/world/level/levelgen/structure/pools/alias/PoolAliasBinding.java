package net.minecraft.world.level.levelgen.structure.pools.alias;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.worldgen.Pools;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.RandomSource;
import net.minecraft.util.random.SimpleWeightedRandomList;
import net.minecraft.util.random.WeightedEntry;
import net.minecraft.world.level.levelgen.structure.pools.StructureTemplatePool;

public interface PoolAliasBinding {
    Codec<PoolAliasBinding> f_303072_ = BuiltInRegistries.f_302795_.m_194605_().dispatch(PoolAliasBinding::m_304964_, Function.identity());

    void m_305333_(RandomSource p_309848_, BiConsumer<ResourceKey<StructureTemplatePool>, ResourceKey<StructureTemplatePool>> p_311325_);

    Stream<ResourceKey<StructureTemplatePool>> m_304920_();

    static Direct m_305746_(String p_310882_, String p_311396_) {
        return m_304861_(Pools.m_254871_(p_310882_), Pools.m_254871_(p_311396_));
    }

    static Direct m_304861_(ResourceKey<StructureTemplatePool> p_311763_, ResourceKey<StructureTemplatePool> p_312427_) {
        return new Direct(p_311763_, p_312427_);
    }

    static Random m_305102_(String p_311792_, SimpleWeightedRandomList<String> p_310543_) {
        SimpleWeightedRandomList.Builder<ResourceKey<StructureTemplatePool>> builder = SimpleWeightedRandomList.m_146263_();
        p_310543_.m_146338_().forEach(p_327480_ -> builder.m_146271_(Pools.m_254871_(p_327480_.f_146299_()), p_327480_.m_142631_().m_146281_()));
        return m_308009_(Pools.m_254871_(p_311792_), builder.m_146270_());
    }

    static Random m_308009_(ResourceKey<StructureTemplatePool> p_311453_, SimpleWeightedRandomList<ResourceKey<StructureTemplatePool>> p_311769_) {
        return new Random(p_311453_, p_311769_);
    }

    static RandomGroup m_307343_(SimpleWeightedRandomList<List<PoolAliasBinding>> p_310479_) {
        return new RandomGroup(p_310479_);
    }

    MapCodec<? extends PoolAliasBinding> m_304964_();
}