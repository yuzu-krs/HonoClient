package net.minecraft.world.level.levelgen.blockpredicates;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.phys.shapes.Shapes;

record UnobstructedPredicate(Vec3i f_337722_) implements BlockPredicate {
    public static MapCodec<UnobstructedPredicate> f_337201_ = RecordCodecBuilder.mapCodec(
        p_344628_ -> p_344628_.group(Vec3i.f_123287_.optionalFieldOf("offset", Vec3i.f_123288_).forGetter(UnobstructedPredicate::f_337722_))
                .apply(p_344628_, UnobstructedPredicate::new)
    );

    @Override
    public BlockPredicateType<?> m_183575_() {
        return BlockPredicateType.f_337691_;
    }

    public boolean test(WorldGenLevel p_343967_, BlockPos p_344792_) {
        return p_343967_.m_5450_(null, Shapes.m_83144_().m_83216_((double)p_344792_.m_123341_(), (double)p_344792_.m_123342_(), (double)p_344792_.m_123343_()));
    }
}