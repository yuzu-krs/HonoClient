package net.minecraft.world.level.levelgen.synth;

import com.google.common.annotations.VisibleForTesting;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.codecs.RecordCodecBuilder.Instance;
import java.util.Locale;
import java.util.stream.IntStream;
import net.minecraft.util.KeyDispatchDataCodec;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.DensityFunction;
import net.minecraft.world.level.levelgen.XoroshiroRandomSource;

public class BlendedNoise implements DensityFunction.SimpleFunction {
    private static final Codec<Double> f_230454_ = Codec.doubleRange(0.001, 1000.0);
    private static final MapCodec<BlendedNoise> f_230455_ = RecordCodecBuilder.mapCodec(
        p_230486_ -> p_230486_.group(
                    f_230454_.fieldOf("xz_scale").forGetter(p_230497_ -> p_230497_.f_192799_),
                    f_230454_.fieldOf("y_scale").forGetter(p_230495_ -> p_230495_.f_192800_),
                    f_230454_.fieldOf("xz_factor").forGetter(p_230493_ -> p_230493_.f_230458_),
                    f_230454_.fieldOf("y_factor").forGetter(p_230490_ -> p_230490_.f_230459_),
                    Codec.doubleRange(1.0, 8.0).fieldOf("smear_scale_multiplier").forGetter(p_230488_ -> p_230488_.f_230460_)
                )
                .apply(p_230486_, BlendedNoise::m_230477_)
    );
    public static final KeyDispatchDataCodec<BlendedNoise> f_210616_ = KeyDispatchDataCodec.m_216238_(f_230455_);
    private final PerlinNoise f_164288_;
    private final PerlinNoise f_164289_;
    private final PerlinNoise f_164290_;
    private final double f_230456_;
    private final double f_230457_;
    private final double f_230458_;
    private final double f_230459_;
    private final double f_230460_;
    private final double f_210617_;
    private final double f_192799_;
    private final double f_192800_;

    public static BlendedNoise m_230477_(double p_230478_, double p_230479_, double p_230480_, double p_230481_, double p_230482_) {
        return new BlendedNoise(new XoroshiroRandomSource(0L), p_230478_, p_230479_, p_230480_, p_230481_, p_230482_);
    }

    private BlendedNoise(
        PerlinNoise p_230469_,
        PerlinNoise p_230470_,
        PerlinNoise p_230471_,
        double p_230472_,
        double p_230473_,
        double p_230474_,
        double p_230475_,
        double p_230476_
    ) {
        this.f_164288_ = p_230469_;
        this.f_164289_ = p_230470_;
        this.f_164290_ = p_230471_;
        this.f_192799_ = p_230472_;
        this.f_192800_ = p_230473_;
        this.f_230458_ = p_230474_;
        this.f_230459_ = p_230475_;
        this.f_230460_ = p_230476_;
        this.f_230456_ = 684.412 * this.f_192799_;
        this.f_230457_ = 684.412 * this.f_192800_;
        this.f_210617_ = p_230469_.m_210643_(this.f_230457_);
    }

    @VisibleForTesting
    public BlendedNoise(RandomSource p_230462_, double p_230463_, double p_230464_, double p_230465_, double p_230466_, double p_230467_) {
        this(
            PerlinNoise.m_230532_(p_230462_, IntStream.rangeClosed(-15, 0)),
            PerlinNoise.m_230532_(p_230462_, IntStream.rangeClosed(-15, 0)),
            PerlinNoise.m_230532_(p_230462_, IntStream.rangeClosed(-7, 0)),
            p_230463_,
            p_230464_,
            p_230465_,
            p_230466_,
            p_230467_
        );
    }

    public BlendedNoise m_230483_(RandomSource p_230484_) {
        return new BlendedNoise(p_230484_, this.f_192799_, this.f_192800_, this.f_230458_, this.f_230459_, this.f_230460_);
    }

    @Override
    public double m_207386_(DensityFunction.FunctionContext p_210621_) {
        double d0 = (double)p_210621_.m_207115_() * this.f_230456_;
        double d1 = (double)p_210621_.m_207114_() * this.f_230457_;
        double d2 = (double)p_210621_.m_207113_() * this.f_230456_;
        double d3 = d0 / this.f_230458_;
        double d4 = d1 / this.f_230459_;
        double d5 = d2 / this.f_230458_;
        double d6 = this.f_230457_ * this.f_230460_;
        double d7 = d6 / this.f_230459_;
        double d8 = 0.0;
        double d9 = 0.0;
        double d10 = 0.0;
        boolean flag = true;
        double d11 = 1.0;

        for (int i = 0; i < 8; i++) {
            ImprovedNoise improvednoise = this.f_164290_.m_75424_(i);
            if (improvednoise != null) {
                d10 += improvednoise.m_75327_(
                        PerlinNoise.m_75406_(d3 * d11), PerlinNoise.m_75406_(d4 * d11), PerlinNoise.m_75406_(d5 * d11), d7 * d11, d4 * d11
                    )
                    / d11;
            }

            d11 /= 2.0;
        }

        double d16 = (d10 / 10.0 + 1.0) / 2.0;
        boolean flag1 = d16 >= 1.0;
        boolean flag2 = d16 <= 0.0;
        d11 = 1.0;

        for (int j = 0; j < 16; j++) {
            double d12 = PerlinNoise.m_75406_(d0 * d11);
            double d13 = PerlinNoise.m_75406_(d1 * d11);
            double d14 = PerlinNoise.m_75406_(d2 * d11);
            double d15 = d6 * d11;
            if (!flag1) {
                ImprovedNoise improvednoise1 = this.f_164288_.m_75424_(j);
                if (improvednoise1 != null) {
                    d8 += improvednoise1.m_75327_(d12, d13, d14, d15, d1 * d11) / d11;
                }
            }

            if (!flag2) {
                ImprovedNoise improvednoise2 = this.f_164289_.m_75424_(j);
                if (improvednoise2 != null) {
                    d9 += improvednoise2.m_75327_(d12, d13, d14, d15, d1 * d11) / d11;
                }
            }

            d11 /= 2.0;
        }

        return Mth.m_14085_(d8 / 512.0, d9 / 512.0, d16) / 128.0;
    }

    @Override
    public double m_207402_() {
        return -this.m_207401_();
    }

    @Override
    public double m_207401_() {
        return this.f_210617_;
    }

    @VisibleForTesting
    public void m_192817_(StringBuilder p_192818_) {
        p_192818_.append("BlendedNoise{minLimitNoise=");
        this.f_164288_.m_192890_(p_192818_);
        p_192818_.append(", maxLimitNoise=");
        this.f_164289_.m_192890_(p_192818_);
        p_192818_.append(", mainNoise=");
        this.f_164290_.m_192890_(p_192818_);
        p_192818_.append(
                String.format(
                    Locale.ROOT,
                    ", xzScale=%.3f, yScale=%.3f, xzMainScale=%.3f, yMainScale=%.3f, cellWidth=4, cellHeight=8",
                    684.412,
                    684.412,
                    8.555150000000001,
                    4.277575000000001
                )
            )
            .append('}');
    }

    @Override
    public KeyDispatchDataCodec<? extends DensityFunction> m_214023_() {
        return f_210616_;
    }
}