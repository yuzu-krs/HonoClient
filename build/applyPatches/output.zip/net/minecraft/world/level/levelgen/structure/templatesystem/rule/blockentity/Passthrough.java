package net.minecraft.world.level.levelgen.structure.templatesystem.rule.blockentity;

import com.mojang.serialization.MapCodec;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;

public class Passthrough implements RuleBlockEntityModifier {
    public static final Passthrough f_276645_ = new Passthrough();
    public static final MapCodec<Passthrough> f_276690_ = MapCodec.unit(f_276645_);

    @Nullable
    @Override
    public CompoundTag m_276854_(RandomSource p_277737_, @Nullable CompoundTag p_277665_) {
        return p_277665_;
    }

    @Override
    public RuleBlockEntityModifierType<?> m_276855_() {
        return RuleBlockEntityModifierType.f_276528_;
    }
}