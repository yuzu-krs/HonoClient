package net.minecraft.util.profiling.jfr.parse;

import com.mojang.datafixers.util.Pair;
import java.time.Duration;
import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import net.minecraft.util.profiling.jfr.serialize.JfrResultJsonSerializer;
import net.minecraft.util.profiling.jfr.stats.ChunkGenStat;
import net.minecraft.util.profiling.jfr.stats.ChunkIdentification;
import net.minecraft.util.profiling.jfr.stats.CpuLoadStat;
import net.minecraft.util.profiling.jfr.stats.FileIOStat;
import net.minecraft.util.profiling.jfr.stats.GcHeapStat;
import net.minecraft.util.profiling.jfr.stats.IoSummary;
import net.minecraft.util.profiling.jfr.stats.PacketIdentification;
import net.minecraft.util.profiling.jfr.stats.ThreadAllocationStat;
import net.minecraft.util.profiling.jfr.stats.TickTimeStat;
import net.minecraft.util.profiling.jfr.stats.TimedStatSummary;
import net.minecraft.world.level.chunk.status.ChunkStatus;

public record JfrStatsResult(
    Instant f_185478_,
    Instant f_185479_,
    Duration f_185480_,
    @Nullable Duration f_185481_,
    List<TickTimeStat> f_185482_,
    List<CpuLoadStat> f_185483_,
    GcHeapStat.Summary f_185484_,
    ThreadAllocationStat.Summary f_185485_,
    IoSummary<PacketIdentification> f_185486_,
    IoSummary<PacketIdentification> f_185487_,
    IoSummary<ChunkIdentification> f_314724_,
    IoSummary<ChunkIdentification> f_316428_,
    FileIOStat.Summary f_185488_,
    FileIOStat.Summary f_185489_,
    List<ChunkGenStat> f_185490_
) {
    public List<Pair<ChunkStatus, TimedStatSummary<ChunkGenStat>>> m_185505_() {
        Map<ChunkStatus, List<ChunkGenStat>> map = this.f_185490_.stream().collect(Collectors.groupingBy(ChunkGenStat::f_185595_));
        return map.entrySet()
            .stream()
            .map(p_326730_ -> Pair.of(p_326730_.getKey(), TimedStatSummary.m_185849_(p_326730_.getValue())))
            .sorted(
                Comparator.<Pair<ChunkStatus, TimedStatSummary<ChunkGenStat>>, Duration>comparing(p_185507_ -> p_185507_.getSecond().f_185838_()).reversed()
            )
            .toList();
    }

    public String m_185510_() {
        return new JfrResultJsonSerializer().m_185535_(this);
    }
}