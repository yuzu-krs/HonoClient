package net.minecraft.util.profiling;

import com.mojang.jtracy.Plot;
import com.mojang.jtracy.TracyClient;
import com.mojang.logging.LogUtils;
import java.lang.StackWalker.Option;
import java.lang.StackWalker.StackFrame;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.SharedConstants;
import net.minecraft.util.profiling.metrics.MetricCategory;
import org.slf4j.Logger;

public class TracyZoneFiller implements ProfilerFiller {
    private static final Logger f_348062_ = LogUtils.getLogger();
    private static final StackWalker f_346699_ = StackWalker.getInstance(Set.of(Option.RETAIN_CLASS_REFERENCE), 5);
    private final List<com.mojang.jtracy.Zone> f_347692_ = new ArrayList<>();
    private final Map<String, TracyZoneFiller.PlotAndValue> f_346220_ = new HashMap<>();
    private final String f_348798_ = Thread.currentThread().getName();

    @Override
    public void m_7242_() {
    }

    @Override
    public void m_7241_() {
        for (TracyZoneFiller.PlotAndValue tracyzonefiller$plotandvalue : this.f_346220_.values()) {
            tracyzonefiller$plotandvalue.m_355116_(0);
        }
    }

    @Override
    public void m_6180_(String p_364548_) {
        String s = "";
        String s1 = "";
        int i = 0;
        if (SharedConstants.f_136183_) {
            Optional<StackFrame> optional = f_346699_.walk(
                p_361443_ -> p_361443_.filter(
                            p_366989_ -> p_366989_.getDeclaringClass() != TracyZoneFiller.class
                                    && p_366989_.getDeclaringClass() != ProfilerFiller.CombinedProfileFiller.class
                        )
                        .findFirst()
            );
            if (optional.isPresent()) {
                StackFrame stackframe = optional.get();
                s = stackframe.getMethodName();
                s1 = stackframe.getFileName();
                i = stackframe.getLineNumber();
            }
        }

        com.mojang.jtracy.Zone zone = TracyClient.beginZone(p_364548_, s, s1, i);
        this.f_347692_.add(zone);
    }

    @Override
    public void m_6521_(Supplier<String> p_367014_) {
        this.m_6180_(p_367014_.get());
    }

    @Override
    public void m_7238_() {
        if (this.f_347692_.isEmpty()) {
            f_348062_.error("Tried to pop one too many times! Mismatched push() and pop()?");
        } else {
            com.mojang.jtracy.Zone zone = this.f_347692_.removeLast();
            zone.close();
        }
    }

    @Override
    public void m_6182_(String p_362480_) {
        this.m_7238_();
        this.m_6180_(p_362480_);
    }

    @Override
    public void m_6523_(Supplier<String> p_368969_) {
        this.m_7238_();
        this.m_6180_(p_368969_.get());
    }

    @Override
    public void m_142259_(MetricCategory p_360953_) {
    }

    @Override
    public void m_183275_(String p_362137_, int p_362577_) {
        this.f_346220_.computeIfAbsent(p_362137_, p_367016_ -> new TracyZoneFiller.PlotAndValue(this.f_348798_ + " " + p_362137_)).m_354693_(p_362577_);
    }

    @Override
    public void m_183536_(Supplier<String> p_362628_, int p_368047_) {
        this.m_183275_(p_362628_.get(), p_368047_);
    }

    private com.mojang.jtracy.Zone m_353814_() {
        return this.f_347692_.getLast();
    }

    @Override
    public void m_353011_(String p_362912_) {
        this.m_353814_().addText(p_362912_);
    }

    @Override
    public void m_351925_(long p_366154_) {
        this.m_353814_().addValue(p_366154_);
    }

    @Override
    public void m_353054_(int p_363144_) {
        this.m_353814_().setColor(p_363144_);
    }

    static final class PlotAndValue {
        private final Plot f_348137_;
        private int f_349360_;

        PlotAndValue(String p_366532_) {
            this.f_348137_ = TracyClient.createPlot(p_366532_);
            this.f_349360_ = 0;
        }

        void m_355116_(int p_362550_) {
            this.f_349360_ = p_362550_;
            this.f_348137_.setValue((double)p_362550_);
        }

        void m_354693_(int p_365380_) {
            this.m_355116_(this.f_349360_ + p_365380_);
        }
    }
}