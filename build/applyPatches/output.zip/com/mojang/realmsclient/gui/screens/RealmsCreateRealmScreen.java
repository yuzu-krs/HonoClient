package com.mojang.realmsclient.gui.screens;

import com.mojang.realmsclient.RealmsMainScreen;
import com.mojang.realmsclient.client.RealmsClient;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.exception.RealmsServiceException;
import com.mojang.realmsclient.util.task.RealmCreationTask;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.Util;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.layouts.CommonLayouts;
import net.minecraft.client.gui.layouts.HeaderAndFooterLayout;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.AlertScreen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.realms.RealmsScreen;
import net.minecraft.util.StringUtil;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class RealmsCreateRealmScreen extends RealmsScreen {
    private static final Component f_303231_ = Component.m_237115_("mco.selectServer.create");
    private static final Component f_88564_ = Component.m_237115_("mco.configure.world.name");
    private static final Component f_88565_ = Component.m_237115_("mco.configure.world.description");
    private static final int f_291883_ = 10;
    private static final int f_291606_ = 210;
    private final RealmsMainScreen f_88567_;
    private final HeaderAndFooterLayout f_290596_ = new HeaderAndFooterLayout(this);
    private EditBox f_88568_;
    private EditBox f_88569_;
    private final Runnable f_302202_;

    public RealmsCreateRealmScreen(RealmsMainScreen p_88575_, RealmsServer p_366584_, boolean p_369519_) {
        super(f_303231_);
        this.f_88567_ = p_88575_;
        this.f_302202_ = () -> this.m_356218_(p_366584_, p_369519_);
    }

    @Override
    public void m_7856_() {
        this.f_290596_.m_324480_(this.f_96539_, this.f_96547_);
        LinearLayout linearlayout = this.f_290596_.m_268999_(LinearLayout.m_293633_()).m_294554_(10);
        Button button = Button.m_253074_(CommonComponents.f_263736_, p_308057_ -> this.f_302202_.run()).m_253136_();
        button.f_93623_ = false;
        this.f_88568_ = new EditBox(this.f_96547_, 210, 20, f_88564_);
        this.f_88568_.m_94151_(p_325123_ -> button.f_93623_ = !StringUtil.m_320314_(p_325123_));
        this.f_88569_ = new EditBox(this.f_96547_, 210, 20, f_88565_);
        linearlayout.m_264406_(CommonLayouts.m_294456_(this.f_96547_, this.f_88568_, f_88564_));
        linearlayout.m_264406_(CommonLayouts.m_294456_(this.f_96547_, this.f_88569_, f_88565_));
        LinearLayout linearlayout1 = this.f_290596_.m_269281_(LinearLayout.m_295847_().m_294554_(10));
        linearlayout1.m_264406_(button);
        linearlayout1.m_264406_(Button.m_253074_(CommonComponents.f_130660_, p_296056_ -> this.m_7379_()).m_253136_());
        this.f_290596_.m_264134_(p_325125_ -> {
            AbstractWidget abstractwidget = this.m_142416_(p_325125_);
        });
        this.m_267719_();
    }

    @Override
    protected void m_318615_() {
        this.m_264313_(this.f_88568_);
    }

    @Override
    protected void m_267719_() {
        this.f_290596_.m_264036_();
    }

    private void m_356218_(RealmsServer p_367400_, boolean p_365842_) {
        if (!p_367400_.m_307276_() && p_365842_) {
            AtomicBoolean atomicboolean = new AtomicBoolean();
            this.f_96541_.m_91152_(new AlertScreen(() -> {
                atomicboolean.set(true);
                this.f_88567_.m_193498_();
                this.f_96541_.m_91152_(this.f_88567_);
            }, Component.m_237115_("mco.upload.preparing"), Component.m_237119_()));
            CompletableFuture.<RealmsServer>supplyAsync(() -> m_353578_(p_367400_), Util.m_183991_()).thenAcceptAsync(p_357557_ -> {
                if (!atomicboolean.get()) {
                    this.m_88595_(p_357557_);
                }
            }, this.f_96541_).exceptionallyAsync(p_357560_ -> {
                this.f_88567_.m_193498_();
                Component component;
                if (p_357560_.getCause() instanceof RealmsServiceException realmsserviceexception) {
                    component = realmsserviceexception.f_200941_.m_292809_();
                } else {
                    component = Component.m_237115_("mco.errorMessage.initialize.failed");
                }

                this.f_96541_.m_91152_(new RealmsGenericErrorScreen(component, this.f_88567_));
                return null;
            }, this.f_96541_);
        } else {
            this.m_88595_(p_367400_);
        }
    }

    private static RealmsServer m_353578_(RealmsServer p_362204_) {
        RealmsClient realmsclient = RealmsClient.m_87169_();

        try {
            return realmsclient.m_305378_(p_362204_.f_87473_);
        } catch (RealmsServiceException realmsserviceexception) {
            throw new RuntimeException(realmsserviceexception);
        }
    }

    private void m_88595_(RealmsServer p_310274_) {
        RealmCreationTask realmcreationtask = new RealmCreationTask(p_310274_.f_87473_, this.f_88568_.m_94155_(), this.f_88569_.m_94155_());
        RealmsResetWorldScreen realmsresetworldscreen = RealmsResetWorldScreen.m_294089_(
            this, p_310274_, realmcreationtask, () -> this.f_96541_.execute(() -> {
                    RealmsMainScreen.m_294350_();
                    this.f_96541_.m_91152_(this.f_88567_);
                })
        );
        this.f_96541_.m_91152_(realmsresetworldscreen);
    }

    @Override
    public void m_7379_() {
        this.f_96541_.m_91152_(this.f_88567_);
    }
}