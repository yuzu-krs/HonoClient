package com.mojang.realmsclient.dto;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.yggdrasil.ProfileResult;
import com.mojang.logging.LogUtils;
import com.mojang.realmsclient.util.JsonUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.util.GsonHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public class RealmsServerPlayerLists extends ValueObject {
    private static final Logger f_87593_ = LogUtils.getLogger();
    public Map<Long, List<ProfileResult>> f_87592_ = Map.of();

    public static RealmsServerPlayerLists m_87596_(String p_87597_) {
        RealmsServerPlayerLists realmsserverplayerlists = new RealmsServerPlayerLists();
        Builder<Long, List<ProfileResult>> builder = ImmutableMap.builder();

        try {
            JsonObject jsonobject = GsonHelper.m_13864_(p_87597_);
            if (GsonHelper.m_13885_(jsonobject, "lists")) {
                for (JsonElement jsonelement : jsonobject.getAsJsonArray("lists")) {
                    JsonObject jsonobject1 = jsonelement.getAsJsonObject();
                    String s = JsonUtils.m_90161_("playerList", jsonobject1, null);
                    List<ProfileResult> list;
                    if (s != null) {
                        JsonElement jsonelement1 = JsonParser.parseString(s);
                        if (jsonelement1.isJsonArray()) {
                            list = m_340350_(jsonelement1.getAsJsonArray());
                        } else {
                            list = Lists.newArrayList();
                        }
                    } else {
                        list = Lists.newArrayList();
                    }

                    builder.put(JsonUtils.m_90157_("serverId", jsonobject1, -1L), list);
                }
            }
        } catch (Exception exception) {
            f_87593_.error("Could not parse RealmsServerPlayerLists: {}", exception.getMessage());
        }

        realmsserverplayerlists.f_87592_ = builder.build();
        return realmsserverplayerlists;
    }

    private static List<ProfileResult> m_340350_(JsonArray p_342185_) {
        List<ProfileResult> list = new ArrayList<>(p_342185_.size());
        MinecraftSessionService minecraftsessionservice = Minecraft.m_91087_().m_91108_();

        for (JsonElement jsonelement : p_342185_) {
            if (jsonelement.isJsonObject()) {
                UUID uuid = JsonUtils.m_274562_("playerId", jsonelement.getAsJsonObject(), null);
                if (uuid != null && !Minecraft.m_91087_().m_292661_(uuid)) {
                    try {
                        ProfileResult profileresult = minecraftsessionservice.fetchProfile(uuid, false);
                        if (profileresult != null) {
                            list.add(profileresult);
                        }
                    } catch (Exception exception) {
                        f_87593_.error("Could not get name for {}", uuid, exception);
                    }
                }
            }
        }

        return list;
    }

    public List<ProfileResult> m_339524_(long p_343284_) {
        List<ProfileResult> list = this.f_87592_.get(p_343284_);
        return list != null ? list : List.of();
    }
}