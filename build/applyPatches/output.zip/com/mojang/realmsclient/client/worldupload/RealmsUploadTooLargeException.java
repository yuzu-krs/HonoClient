package com.mojang.realmsclient.client.worldupload;

import com.mojang.realmsclient.Unit;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class RealmsUploadTooLargeException extends RealmsUploadException {
    final long f_348692_;

    public RealmsUploadTooLargeException(long p_361069_) {
        this.f_348692_ = p_361069_;
    }

    @Override
    public Component[] m_353163_() {
        return new Component[]{
            Component.m_237115_("mco.upload.failed.too_big.title"),
            Component.m_237110_("mco.upload.failed.too_big.description", Unit.m_86947_(this.f_348692_, Unit.m_86940_(this.f_348692_)))
        };
    }
}