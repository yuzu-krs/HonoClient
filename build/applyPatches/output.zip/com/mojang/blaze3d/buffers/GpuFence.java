package com.mojang.blaze3d.buffers;

import com.mojang.blaze3d.platform.GlStateManager;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GpuFence implements AutoCloseable {
    private long f_349046_ = GlStateManager._glFenceSync(37143, 0);

    @Override
    public void close() {
        if (this.f_349046_ != 0L) {
            GlStateManager._glDeleteSync(this.f_349046_);
            this.f_349046_ = 0L;
        }
    }

    public boolean m_351938_(long p_368162_) {
        if (this.f_349046_ == 0L) {
            return true;
        } else {
            int i = GlStateManager._glClientWaitSync(this.f_349046_, 0, p_368162_);
            if (i == 37147) {
                return false;
            } else if (i == 37149) {
                throw new IllegalStateException("Failed to complete gpu fence");
            } else {
                return true;
            }
        }
    }
}