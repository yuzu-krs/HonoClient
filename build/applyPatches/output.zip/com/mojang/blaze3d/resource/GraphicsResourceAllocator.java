package com.mojang.blaze3d.resource;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface GraphicsResourceAllocator {
    GraphicsResourceAllocator f_347426_ = new GraphicsResourceAllocator() {
        @Override
        public <T> T m_353367_(ResourceDescriptor<T> p_369530_) {
            return p_369530_.m_354097_();
        }

        @Override
        public <T> void m_352189_(ResourceDescriptor<T> p_367442_, T p_361994_) {
            p_367442_.m_351945_(p_361994_);
        }
    };

    <T> T m_353367_(ResourceDescriptor<T> p_362950_);

    <T> void m_352189_(ResourceDescriptor<T> p_368482_, T p_369841_);
}