package com.mojang.blaze3d.vertex;

import com.mojang.blaze3d.systems.RenderSystem;
import javax.annotation.Nullable;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class BufferUploader {
    @Nullable
    private static VertexBuffer f_231201_;

    public static void m_166835_() {
        if (f_231201_ != null) {
            m_231208_();
            VertexBuffer.m_85931_();
        }
    }

    public static void m_231208_() {
        f_231201_ = null;
    }

    public static void m_231202_(MeshData p_344650_) {
        RenderSystem.assertOnRenderThread();
        VertexBuffer vertexbuffer = m_231213_(p_344650_);
        vertexbuffer.m_253207_(RenderSystem.getModelViewMatrix(), RenderSystem.getProjectionMatrix(), RenderSystem.getShader());
    }

    public static void m_231209_(MeshData p_342146_) {
        RenderSystem.assertOnRenderThread();
        VertexBuffer vertexbuffer = m_231213_(p_342146_);
        vertexbuffer.m_166882_();
    }

    private static VertexBuffer m_231213_(MeshData p_342083_) {
        VertexBuffer vertexbuffer = m_231206_(p_342083_.m_339246_().f_336748_());
        vertexbuffer.m_231221_(p_342083_);
        return vertexbuffer;
    }

    private static VertexBuffer m_231206_(VertexFormat p_231207_) {
        VertexBuffer vertexbuffer = p_231207_.m_231233_();
        m_231204_(vertexbuffer);
        return vertexbuffer;
    }

    private static void m_231204_(VertexBuffer p_231205_) {
        if (p_231205_ != f_231201_) {
            p_231205_.m_85921_();
            f_231201_ = p_231205_;
        }
    }
}