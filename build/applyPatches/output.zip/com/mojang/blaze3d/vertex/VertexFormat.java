package com.mojang.blaze3d.vertex;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.mojang.blaze3d.buffers.BufferUsage;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class VertexFormat {
    public static final int f_337347_ = -1;
    private final List<VertexFormatElement> f_86012_;
    private final List<String> f_337579_;
    private final int f_86014_;
    private final int f_337518_;
    private final int[] f_337288_ = new int[32];
    @Nullable
    private VertexBuffer f_231232_;

    VertexFormat(List<VertexFormatElement> p_343616_, List<String> p_345241_, IntList p_345522_, int p_344162_) {
        this.f_86012_ = p_343616_;
        this.f_337579_ = p_345241_;
        this.f_86014_ = p_344162_;
        this.f_337518_ = p_343616_.stream().mapToInt(VertexFormatElement::m_339950_).reduce(0, (p_344142_, p_345074_) -> p_344142_ | p_345074_);

        for (int i = 0; i < this.f_337288_.length; i++) {
            VertexFormatElement vertexformatelement = VertexFormatElement.m_340524_(i);
            int j = vertexformatelement != null ? p_343616_.indexOf(vertexformatelement) : -1;
            this.f_337288_[i] = j != -1 ? p_345522_.getInt(j) : -1;
        }
    }

    public static VertexFormat.Builder m_339703_() {
        return new VertexFormat.Builder();
    }

    public void m_355961_(int p_361973_) {
        int i = 0;

        for (String s : this.m_166911_()) {
            GlStateManager._glBindAttribLocation(p_361973_, i, s);
            i++;
        }
    }

    @Override
    public String toString() {
        return "VertexFormat" + this.f_337579_;
    }

    public int m_86020_() {
        return this.f_86014_;
    }

    public List<VertexFormatElement> m_86023_() {
        return this.f_86012_;
    }

    public List<String> m_166911_() {
        return this.f_337579_;
    }

    public int[] m_338562_() {
        return this.f_337288_;
    }

    public int m_338798_(VertexFormatElement p_342517_) {
        return this.f_337288_[p_342517_.f_337730_()];
    }

    public boolean m_339292_(VertexFormatElement p_345196_) {
        return (this.f_337518_ & p_345196_.m_339950_()) != 0;
    }

    public int m_340128_() {
        return this.f_337518_;
    }

    public String m_340604_(VertexFormatElement p_345336_) {
        int i = this.f_86012_.indexOf(p_345336_);
        if (i == -1) {
            throw new IllegalArgumentException(p_345336_ + " is not contained in format");
        } else {
            return this.f_337579_.get(i);
        }
    }

    @Override
    public boolean equals(Object p_86026_) {
        if (this == p_86026_) {
            return true;
        } else {
            if (p_86026_ instanceof VertexFormat vertexformat
                && this.f_337518_ == vertexformat.f_337518_
                && this.f_86014_ == vertexformat.f_86014_
                && this.f_337579_.equals(vertexformat.f_337579_)
                && Arrays.equals(this.f_337288_, vertexformat.f_337288_)) {
                return true;
            }

            return false;
        }
    }

    @Override
    public int hashCode() {
        return this.f_337518_ * 31 + Arrays.hashCode(this.f_337288_);
    }

    public void m_166912_() {
        RenderSystem.assertOnRenderThread();
        int i = this.m_86020_();

        for (int j = 0; j < this.f_86012_.size(); j++) {
            GlStateManager._enableVertexAttribArray(j);
            VertexFormatElement vertexformatelement = this.f_86012_.get(j);
            vertexformatelement.m_166965_(j, (long)this.m_338798_(vertexformatelement), i);
        }
    }

    public void m_86024_() {
        RenderSystem.assertOnRenderThread();

        for (int i = 0; i < this.f_86012_.size(); i++) {
            GlStateManager._disableVertexAttribArray(i);
        }
    }

    public VertexBuffer m_231233_() {
        VertexBuffer vertexbuffer = this.f_231232_;
        if (vertexbuffer == null) {
            this.f_231232_ = vertexbuffer = new VertexBuffer(BufferUsage.DYNAMIC_WRITE);
        }

        return vertexbuffer;
    }

    @OnlyIn(Dist.CLIENT)
    public static class Builder {
        private final ImmutableMap.Builder<String, VertexFormatElement> f_337231_ = ImmutableMap.builder();
        private final IntList f_337307_ = new IntArrayList();
        private int f_336835_;

        Builder() {
        }

        public VertexFormat.Builder m_339091_(String p_343401_, VertexFormatElement p_345244_) {
            this.f_337231_.put(p_343401_, p_345244_);
            this.f_337307_.add(this.f_336835_);
            this.f_336835_ = this.f_336835_ + p_345244_.m_339527_();
            return this;
        }

        public VertexFormat.Builder m_339010_(int p_345477_) {
            this.f_336835_ += p_345477_;
            return this;
        }

        public VertexFormat m_339368_() {
            ImmutableMap<String, VertexFormatElement> immutablemap = this.f_337231_.buildOrThrow();
            ImmutableList<VertexFormatElement> immutablelist = immutablemap.values().asList();
            ImmutableList<String> immutablelist1 = immutablemap.keySet().asList();
            return new VertexFormat(immutablelist, immutablelist1, this.f_337307_, this.f_336835_);
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static enum IndexType {
        SHORT(5123, 2),
        INT(5125, 4);

        public final int f_166923_;
        public final int f_166924_;

        private IndexType(final int p_166930_, final int p_166931_) {
            this.f_166923_ = p_166930_;
            this.f_166924_ = p_166931_;
        }

        public static VertexFormat.IndexType m_166933_(int p_166934_) {
            return (p_166934_ & -65536) != 0 ? INT : SHORT;
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static enum Mode {
        LINES(4, 2, 2, false),
        LINE_STRIP(5, 2, 1, true),
        DEBUG_LINES(1, 2, 2, false),
        DEBUG_LINE_STRIP(3, 2, 1, true),
        TRIANGLES(4, 3, 3, false),
        TRIANGLE_STRIP(5, 3, 1, true),
        TRIANGLE_FAN(6, 3, 1, true),
        QUADS(4, 4, 4, false);

        public final int f_166946_;
        public final int f_166947_;
        public final int f_166948_;
        public final boolean f_231234_;

        private Mode(final int p_231238_, final int p_231239_, final int p_231240_, final boolean p_231241_) {
            this.f_166946_ = p_231238_;
            this.f_166947_ = p_231239_;
            this.f_166948_ = p_231240_;
            this.f_231234_ = p_231241_;
        }

        public int m_166958_(int p_166959_) {
            return switch (this) {
                case LINES, QUADS -> p_166959_ / 4 * 6;
                case LINE_STRIP, DEBUG_LINES, DEBUG_LINE_STRIP, TRIANGLES, TRIANGLE_STRIP, TRIANGLE_FAN -> p_166959_;
                default -> 0;
            };
        }
    }
}